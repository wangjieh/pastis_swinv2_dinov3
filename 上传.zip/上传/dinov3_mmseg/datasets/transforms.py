"""Rasterio based segmentation loading transforms."""

from __future__ import annotations

from typing import Iterable, Optional, Sequence

import numpy as np
from mmcv.transforms import BaseTransform
from mmseg.registry import TRANSFORMS


def _require_rasterio():
    try:
        import rasterio  # noqa: WPS433
    except ImportError as exc:
        raise ImportError(
            'Ningbo-2m tif loading requires rasterio. Install rasterio in '
            'the training environment before using LoadRasterio* transforms.'
        ) from exc
    return rasterio


def _as_hw_or_hwc(array: np.ndarray) -> np.ndarray:
    if array.ndim == 2:
        return array
    if array.ndim != 3:
        raise ValueError(f'Expected a 2D or 3D raster array, got {array.shape}.')

    if array.shape[0] in (1, 3, 4):
        array = np.transpose(array, (1, 2, 0))
    if array.shape[-1] == 1:
        array = array[..., 0]
    return array


@TRANSFORMS.register_module()
class LoadRasterioImageFromFile(BaseTransform):
    """Load a tif image with rasterio and keep channel order as RGB."""

    def __init__(
        self,
        to_float32: bool = False,
        num_channels: int = 3,
    ) -> None:
        self.to_float32 = to_float32
        self.num_channels = num_channels

    def transform(self, results: dict) -> dict:
        rasterio = _require_rasterio()
        filename = results['img_path']
        with rasterio.open(filename) as dataset:
            img = _as_hw_or_hwc(dataset.read())

        if img.ndim != 3:
            raise ValueError(
                f'Expected RGB image with shape H x W x C, got {img.shape}.')
        if img.shape[2] < self.num_channels:
            raise ValueError(
                f'Expected at least {self.num_channels} channels, got '
                f'{img.shape[2]} in {filename}.')
        img = img[..., :self.num_channels]
        if self.to_float32:
            img = img.astype(np.float32)

        results['img'] = np.ascontiguousarray(img)
        results['img_shape'] = img.shape[:2]
        results['ori_shape'] = img.shape[:2]
        return results


@TRANSFORMS.register_module()
class LoadRasterioAnnotations(BaseTransform):
    """Load a tif mask and map configured labels to ``ignore_index``."""

    def __init__(
        self,
        ignore_index: int = 255,
        no_train_labels: Optional[Sequence[int]] = None,
        white_ignore_value: Sequence[int] = (255, 255, 255),
        label_min: int = 0,
        label_max: int = 72,
        validate_labels: bool = True,
    ) -> None:
        self.ignore_index = int(ignore_index)
        self.no_train_labels = tuple(int(label) for label in (no_train_labels or ()))
        self.white_ignore_value = tuple(int(value) for value in white_ignore_value)
        self.label_min = int(label_min)
        self.label_max = int(label_max)
        self.validate_labels = validate_labels
        self._validate_no_train_labels()

    def _validate_no_train_labels(self) -> None:
        if self.ignore_index in self.no_train_labels:
            raise ValueError('no_train_labels must not contain ignore_index.')
        invalid = [
            label for label in self.no_train_labels
            if label < self.label_min or label > self.label_max
        ]
        if invalid:
            raise ValueError(
                'no_train_labels values must be within '
                f'[{self.label_min}, {self.label_max}], got {invalid}.')

    def _validate_mask_values(self, mask: np.ndarray, filename: str) -> None:
        if not self.validate_labels:
            return
        valid = (
            ((mask >= self.label_min) & (mask <= self.label_max))
            | (mask == self.ignore_index)
        )
        if not np.all(valid):
            bad_values = np.unique(mask[~valid])
            raise ValueError(
                f'{filename} contains labels outside '
                f'[{self.label_min}, {self.label_max}] and '
                f'{self.ignore_index}: {bad_values[:20].tolist()}.')

    def _white_ignore_mask(self, img: np.ndarray) -> np.ndarray:
        if img.ndim != 3 or img.shape[2] < len(self.white_ignore_value):
            return np.zeros(img.shape[:2], dtype=bool)
        white = np.asarray(self.white_ignore_value, dtype=img.dtype)
        return np.all(img[..., :len(self.white_ignore_value)] == white, axis=-1)

    @staticmethod
    def _label_mask(mask: np.ndarray, labels: Iterable[int]) -> np.ndarray:
        labels = tuple(labels)
        if not labels:
            return np.zeros(mask.shape, dtype=bool)
        return np.isin(mask, np.asarray(labels, dtype=mask.dtype))

    def transform(self, results: dict) -> dict:
        rasterio = _require_rasterio()
        filename = results['seg_map_path']
        with rasterio.open(filename) as dataset:
            mask = _as_hw_or_hwc(dataset.read(1))

        if mask.ndim != 2:
            raise ValueError(
                f'Expected 1-channel mask with shape H x W, got {mask.shape}.')
        self._validate_mask_values(mask, filename)

        ignore_mask = mask == self.ignore_index
        if 'img' in results:
            ignore_mask |= self._white_ignore_mask(results['img'])
        ignore_mask |= self._label_mask(mask, self.no_train_labels)

        mask = mask.astype(np.int64, copy=True)
        mask[ignore_mask] = self.ignore_index

        results['gt_seg_map'] = np.ascontiguousarray(mask)
        results.setdefault('seg_fields', []).append('gt_seg_map')
        return results
