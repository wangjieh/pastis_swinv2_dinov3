"""Dual Swin concat-fusion UPerNet semantic segmentor."""

from __future__ import annotations

from ..._registry import MODELS

_IMPORT_ERROR = None

try:
    import torch
    import torch.nn as nn
    from mmseg.models.segmentors import EncoderDecoder
except ImportError as exc:  # pragma: no cover - local machines may lack deps.
    _IMPORT_ERROR = exc
    EncoderDecoder = object


def _missing_dependency_message() -> str:
    return (
        "DualSwinConcatUPerNet requires PyTorch and MMSegmentation to be "
        f"installed and importable. The current import error was: "
        f"{_IMPORT_ERROR!r}")


if _IMPORT_ERROR is not None:

    @MODELS.register_module()
    class DualSwinConcatUPerNet(EncoderDecoder):
        """Placeholder used when MMSeg dependencies are unavailable."""

        def __init__(self, *args, **kwargs):
            raise ImportError(_missing_dependency_message())

else:

    @MODELS.register_module()
    class DualSwinConcatUPerNet(EncoderDecoder):
        """Two Swin branches fused by concat plus 1x1 convolution."""

        def __init__(self,
                     opt_backbone,
                     sar_backbone,
                     feature_channels,
                     input_split=(3, 1),
                     freeze_backbones=False,
                     **kwargs):
            super().__init__(backbone=opt_backbone, **kwargs)
            self.sar_backbone = MODELS.build(sar_backbone)
            self.input_split = tuple(int(value) for value in input_split)
            if self.input_split != (3, 1):
                raise ValueError(
                    "DualSwinConcatUPerNet expects input_split=(3, 1): "
                    "RGB optical plus single-channel SAR.")
            self.fusion_convs = nn.ModuleList([
                nn.Conv2d(
                    in_channels=int(channel) * 2,
                    out_channels=int(channel),
                    kernel_size=1)
                for channel in feature_channels
            ])
            self.freeze_backbones = bool(freeze_backbones)
            if self.freeze_backbones:
                self._set_backbones_trainable(False)

        def _set_backbones_trainable(self, trainable):
            for module in (self.backbone, self.sar_backbone):
                for param in module.parameters():
                    param.requires_grad = trainable
                if not trainable:
                    module.eval()

        def train(self, mode=True):
            super().train(mode)
            if self.freeze_backbones:
                self.backbone.eval()
                self.sar_backbone.eval()
            return self

        def extract_feat(self, inputs):
            """Extract RGB/SAR features and fuse each stage with Conv1x1."""
            opt_channels, sar_channels = self.input_split
            expected_channels = opt_channels + sar_channels
            if inputs.shape[1] != expected_channels:
                raise ValueError(
                    f"Expected {expected_channels} input channels, got "
                    f"{inputs.shape[1]}.")

            opt_x = inputs[:, :opt_channels, :, :]
            sar_x = inputs[:, opt_channels:, :, :]
            sar_x = sar_x.repeat(1, 3, 1, 1)

            opt_feats = self.backbone(opt_x)
            sar_feats = self.sar_backbone(sar_x)
            if len(opt_feats) != len(sar_feats):
                raise ValueError(
                    "OPT and SAR backbones must return the same number of "
                    f"feature maps, got {len(opt_feats)} and "
                    f"{len(sar_feats)}.")
            if len(opt_feats) != len(self.fusion_convs):
                raise ValueError(
                    "feature_channels must match the number of backbone "
                    f"outputs, got {len(self.fusion_convs)} fusion layers "
                    f"for {len(opt_feats)} feature maps.")

            fused_feats = []
            for opt_feat, sar_feat, fusion_conv in zip(
                    opt_feats, sar_feats, self.fusion_convs):
                if opt_feat.shape != sar_feat.shape:
                    raise ValueError(
                        "OPT and SAR feature maps must have identical shapes, "
                        f"got {tuple(opt_feat.shape)} and "
                        f"{tuple(sar_feat.shape)}.")
                fused = torch.cat([opt_feat, sar_feat], dim=1)
                fused_feats.append(fusion_conv(fused))

            fused_feats = tuple(fused_feats)
            if self.with_neck:
                return self.neck(fused_feats)
            return fused_feats


__all__ = ["DualSwinConcatUPerNet"]
