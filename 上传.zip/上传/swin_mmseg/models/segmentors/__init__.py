"""Segmentor registrations."""

from .dual_swin_concat_upernet import DualSwinConcatUPerNet

__all__ = ["DualSwinConcatUPerNet"]
