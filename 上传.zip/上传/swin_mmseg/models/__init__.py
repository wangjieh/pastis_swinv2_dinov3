"""Model registrations for the Swin MMSeg plugin."""

from .segmentors import *  # noqa: F401,F403
