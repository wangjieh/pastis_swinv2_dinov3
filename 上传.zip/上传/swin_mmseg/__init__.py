"""Swin OpenMMLab plugin for MMSegmentation."""

from .datasets import *  # noqa: F401,F403
from .models import *  # noqa: F401,F403
