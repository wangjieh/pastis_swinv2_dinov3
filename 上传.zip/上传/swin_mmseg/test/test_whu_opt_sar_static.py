"""Static checks for the WHU-OPT-SAR MMSeg plugin files."""

from __future__ import annotations

import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / "configs" / "WHU-OPT-SAR"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


class TestWHUOptSARStatic(unittest.TestCase):

    def test_plugin_files_exist(self):
        required = [
            ROOT / "__init__.py",
            ROOT / "_registry.py",
            ROOT / "datasets" / "__init__.py",
            ROOT / "datasets" / "whu_opt_sar_dataset.py",
            ROOT / "datasets" / "transforms" / "__init__.py",
            ROOT / "datasets" / "transforms" / "whu_opt_sar_transforms.py",
            ROOT / "models" / "__init__.py",
            ROOT / "models" / "segmentors" / "__init__.py",
            ROOT / "models" / "segmentors" /
            "dual_swin_concat_upernet.py",
            CONFIG_DIR /
            "whu_opt_sar_dual_swin_huge_upernet_frozen_50e_128x128.py",
            CONFIG_DIR /
            "whu_opt_sar_dual_swin_huge_upernet_ft_backbone_lr_mult_0p1_50e_128x128.py",
        ]
        for path in required:
            self.assertTrue(path.exists(), msg=str(path))

    def test_configs_do_not_use_python_import_statements(self):
        for path in CONFIG_DIR.glob("*.py"):
            tree = ast.parse(_read(path), filename=str(path))
            imports = (ast.Import, ast.ImportFrom)
            self.assertFalse(
                any(isinstance(node, imports) for node in ast.walk(tree)),
                msg=str(path))

    def test_configs_encode_requested_training_settings(self):
        for path in CONFIG_DIR.glob("*.py"):
            text = _read(path)
            self.assertIn(
                "evaluation=dict(tmpdir='/mnt/htzzb2/EO_test/wj1/tmp')",
                text)
            self.assertIn("find_unused_parameters=True", text)
            self.assertIn('work_dir=""', text)
            self.assertIn('custom_imports = dict(imports=["swin_mmseg"]', text)
            self.assertIn("input_size = (128, 128)", text)
            self.assertIn("batch_size = 16", text)
            self.assertIn("max_epochs = 50", text)
            self.assertIn("base_lr = 1e-4", text)
            self.assertIn("weight_decay = 0.01", text)
            self.assertIn(
                "mean=[88.674, 85.027, 76.558, 56.630]",
                text)
            self.assertIn(
                "std=[67.434, 58.458, 53.972, 45.191]",
                text)
            self.assertIn('type="EpochBasedTrainLoop"', text)
            self.assertIn("by_epoch=True", text)

    def test_configs_use_whu_folders_and_no_rotation_aug(self):
        for path in CONFIG_DIR.glob("*.py"):
            text = _read(path)
            self.assertIn('opt_path="train_128/opt"', text)
            self.assertIn('sar_path="train_128/sar"', text)
            self.assertIn('seg_map_path="train_128/lbl"', text)
            self.assertIn('opt_path="val_128/opt"', text)
            self.assertIn('sar_path="val_128/sar"', text)
            self.assertIn('seg_map_path="val_128/lbl"', text)
            self.assertIn('type="RandomFlip"', text)
            self.assertNotIn("Rotate", text)
            self.assertNotIn("RandomRot", text)

    def test_config_variants_encode_freeze_and_backbone_lr_mult(self):
        frozen = _read(
            CONFIG_DIR /
            "whu_opt_sar_dual_swin_huge_upernet_frozen_50e_128x128.py")
        finetune = _read(
            CONFIG_DIR /
            "whu_opt_sar_dual_swin_huge_upernet_ft_backbone_lr_mult_0p1_50e_128x128.py"
        )
        self.assertIn("freeze_backbones=True", frozen)
        self.assertIn("freeze_backbones=False", finetune)
        self.assertIn('"backbone": dict(lr_mult=0.1)', finetune)
        self.assertIn('"sar_backbone": dict(lr_mult=0.1)', finetune)

    def test_transform_uses_rasterio_rgb_sar_and_eight_class_remap(self):
        text = _read(ROOT / "datasets" / "transforms" /
                     "whu_opt_sar_transforms.py")
        self.assertIn("import rasterio", text)
        self.assertIn("dataset.read()", text)
        self.assertIn("opt[[2, 1, 0]]", text)
        self.assertIn("sar[0].astype", text)
        self.assertIn("DEFAULT_LABEL_MAP", text)
        for old_value, new_value in (
                (0, 0), (10, 1), (20, 2), (30, 3),
                (40, 4), (50, 5), (60, 6), (70, 7)):
            self.assertIn(f"{old_value}: {new_value}", text)
        self.assertNotIn("reproject", text)
        self.assertNotIn("warp", text)
        self.assertNotIn("rotate", text.lower())

    def test_model_uses_two_swin_branches_concat_and_conv1x1(self):
        text = _read(ROOT / "models" / "segmentors" /
                     "dual_swin_concat_upernet.py")
        self.assertIn("class DualSwinConcatUPerNet", text)
        self.assertIn("sar_x = sar_x.repeat(1, 3, 1, 1)", text)
        self.assertIn("torch.cat([opt_feat, sar_feat], dim=1)", text)
        self.assertIn("kernel_size=1", text)
        self.assertIn("freeze_backbones", text)


if __name__ == "__main__":
    unittest.main()
