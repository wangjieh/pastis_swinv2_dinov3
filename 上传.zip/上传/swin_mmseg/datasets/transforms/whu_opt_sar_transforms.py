"""WHU-OPT-SAR rasterio loading and label mapping transform."""

from __future__ import annotations

from ..._registry import TRANSFORMS

try:
    import numpy as np
except ImportError as exc:  # pragma: no cover
    np = None
    _NUMPY_IMPORT_ERROR = exc
else:
    _NUMPY_IMPORT_ERROR = None

try:
    import rasterio
except ImportError as exc:  # pragma: no cover
    rasterio = None
    _RASTERIO_IMPORT_ERROR = exc
else:
    _RASTERIO_IMPORT_ERROR = None

try:
    from mmcv.transforms import BaseTransform
except ImportError:  # pragma: no cover - local machines may lack MMCV.

    class BaseTransform:
        """Fallback base class with MMEngine-like call behavior."""

        def __call__(self, results):
            return self.transform(results)


DEFAULT_LABEL_MAP = {
    0: 0,
    10: 1,
    20: 2,
    30: 3,
    40: 4,
    50: 5,
    60: 6,
    70: 7,
}


def _require_numpy():
    if np is None:
        raise ImportError(
            "WHU-OPT-SAR transforms require numpy. The import error was: "
            f"{_NUMPY_IMPORT_ERROR!r}")


def _require_rasterio():
    if rasterio is None:
        raise ImportError(
            "WHU-OPT-SAR transforms require rasterio. The import error was: "
            f"{_RASTERIO_IMPORT_ERROR!r}")


def _read_raster(path):
    _require_rasterio()
    with rasterio.open(path) as dataset:
        return dataset.read()


def _as_hwc(array):
    return np.moveaxis(array, 0, -1)


@TRANSFORMS.register_module()
class WHUOptSARLoadRasterio(BaseTransform):
    """Load WHU optical/SAR TIFFs and remap semantic labels."""

    def __init__(self, label_map=DEFAULT_LABEL_MAP, ignore_index=255):
        self.label_map = {int(k): int(v) for k, v in dict(label_map).items()}
        self.ignore_index = int(ignore_index)

    def transform(self, results):
        _require_numpy()

        opt = _read_raster(results["opt_path"])
        sar = _read_raster(results["sar_path"])
        if opt.shape[0] < 3:
            raise ValueError(
                f"Expected at least 3 optical bands, got {opt.shape[0]}.")
        if sar.shape[0] < 1:
            raise ValueError(f"Expected at least 1 SAR band, got {sar.shape[0]}.")

        rgb = opt[[2, 1, 0]].astype(np.float32)
        sar_band = sar[0].astype(np.float32)
        image = np.concatenate(
            [_as_hwc(rgb), sar_band[..., None]], axis=-1)

        results["img"] = image
        results["img_shape"] = image.shape[:2]
        results["ori_shape"] = image.shape[:2]

        if "seg_map_path" in results:
            label = _read_raster(results["seg_map_path"])[0]
            mapped = np.full(label.shape, self.ignore_index, dtype=np.uint8)
            for old_value, new_value in self.label_map.items():
                mapped[label == old_value] = new_value
            results["gt_seg_map"] = mapped
            results.setdefault("seg_fields", []).append("gt_seg_map")

        return results


__all__ = ["WHUOptSARLoadRasterio"]
