"""WHU-OPT-SAR semantic segmentation dataset."""

from __future__ import annotations

from .._registry import DATASETS

_IMPORT_ERROR = None

try:
    import os.path as osp

    from mmengine import fileio, list_from_file
    from mmseg.datasets import BaseSegDataset
except ImportError as exc:  # pragma: no cover - local machines may lack deps.
    _IMPORT_ERROR = exc
    BaseSegDataset = object


CLASSES = (
    "background",
    "farmland",
    "city",
    "village",
    "water",
    "forest",
    "road",
    "others",
)

PALETTE = [
    [0, 0, 0],
    [255, 255, 0],
    [255, 0, 0],
    [255, 128, 0],
    [0, 0, 255],
    [0, 128, 0],
    [128, 128, 128],
    [255, 255, 255],
]


def _missing_dependency_message() -> str:
    return (
        "WHUOptSARDataset requires MMSegmentation and MMEngine to be "
        f"installed and importable. The current import error was: "
        f"{_IMPORT_ERROR!r}")


if _IMPORT_ERROR is not None:

    @DATASETS.register_module()
    class WHUOptSARDataset(BaseSegDataset):
        """Placeholder used when MMSeg dependencies are unavailable."""

        METAINFO = dict(classes=CLASSES, palette=PALETTE)

        def __init__(self, *args, **kwargs):
            raise ImportError(_missing_dependency_message())

else:

    @DATASETS.register_module()
    class WHUOptSARDataset(BaseSegDataset):
        """WHU-OPT-SAR dataset with opt/sar/lbl folders per split."""

        METAINFO = dict(classes=CLASSES, palette=PALETTE)

        def __init__(self,
                     opt_suffix=".tif",
                     sar_suffix=".tif",
                     seg_map_suffix=".tif",
                     reduce_zero_label=False,
                     **kwargs):
            self.opt_suffix = opt_suffix
            self.sar_suffix = sar_suffix
            super().__init__(
                img_suffix=opt_suffix,
                seg_map_suffix=seg_map_suffix,
                reduce_zero_label=reduce_zero_label,
                **kwargs)

        def load_data_list(self):
            """Load OPT/SAR/LBL triplets."""
            data_list = []
            opt_dir = self.data_prefix.get("opt_path", None)
            sar_dir = self.data_prefix.get("sar_path", None)
            ann_dir = self.data_prefix.get("seg_map_path", None)
            if opt_dir is None or sar_dir is None or ann_dir is None:
                raise ValueError(
                    "WHUOptSARDataset requires data_prefix keys: opt_path, "
                    "sar_path, and seg_map_path.")

            if self.ann_file:
                opt_names = self._list_ann_file()
            else:
                opt_names = self._list_files(opt_dir, self.opt_suffix)

            for opt_name in opt_names:
                data_list.append(
                    self._build_data_info(opt_dir, sar_dir, ann_dir, opt_name))

            return sorted(data_list, key=lambda item: item["opt_path"])

        def _list_ann_file(self):
            opt_names = []
            for line in list_from_file(
                    self.ann_file, backend_args=self.backend_args):
                opt_name = line.strip()
                if not opt_name:
                    continue
                if not opt_name.endswith(self.opt_suffix):
                    opt_name = f"{opt_name}{self.opt_suffix}"
                opt_names.append(opt_name)
            return opt_names

        def _build_data_info(self, opt_dir, sar_dir, ann_dir, opt_name):
            stem = self._stem(opt_name)
            sar_name = f"{stem}{self.sar_suffix}"
            seg_name = f"{stem}{self.seg_map_suffix}"
            opt_path = osp.join(opt_dir, opt_name)
            return dict(
                img_path=opt_path,
                opt_path=opt_path,
                sar_path=osp.join(sar_dir, sar_name),
                seg_map_path=osp.join(ann_dir, seg_name),
                label_map=self.label_map,
                reduce_zero_label=self.reduce_zero_label,
                seg_fields=[],
            )

        def _stem(self, opt_name):
            if self.opt_suffix and opt_name.endswith(self.opt_suffix):
                return opt_name[:-len(self.opt_suffix)]
            return opt_name

        def _list_files(self, directory, suffix):
            return sorted(
                fileio.list_dir_or_file(
                    dir_path=directory,
                    list_dir=False,
                    suffix=suffix,
                    recursive=False,
                    backend_args=self.backend_args))


__all__ = ["WHUOptSARDataset"]
