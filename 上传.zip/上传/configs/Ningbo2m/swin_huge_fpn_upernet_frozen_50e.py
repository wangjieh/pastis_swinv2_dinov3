import os

custom_imports = dict(
    imports=[
        'dinov3_mmseg.datasets.ningbo2m_dataset',
        'dinov3_mmseg.datasets.transforms',
    ],
    allow_failed_imports=False)


default_scope = 'mmseg'



data_root = os.getenv('NINGBO2M_DATA_ROOT', '')
swin_pretrained = os.getenv('SWIN_PRETRAINED', '')
no_train_labels = []
work_dir = './work_dirs/Ningbo2m/swin_huge_fpn_upernet_frozen_50e'

num_classes = 73
ignore_index = 255
crop_size = (512, 512)
max_epochs = 50
train_batch_size = 8
val_batch_size = 8
num_workers = 4
base_learning_rate = 5e-4
weight_decay = 0.01
warmup_iters = 1500
warmup_ratio = 1e-6

norm_cfg = dict(type='SyncBN', requires_grad=True)
backbone_norm_cfg = dict(type='LN', requires_grad=True)

data_preprocessor = dict(
    type='SegDataPreProcessor',
    mean=[123.675, 116.28, 103.53],
    std=[58.395, 57.12, 57.375],
    bgr_to_rgb=False,
    pad_val=0,
    seg_pad_val=ignore_index,
    size=crop_size)

train_pipeline = [
    dict(type='LoadRasterioImageFromFile', to_float32=False),
    dict(
        type='LoadRasterioAnnotations',
        ignore_index=ignore_index,
        no_train_labels=no_train_labels,
        white_ignore_value=(255, 255, 255),
        label_min=0,
        label_max=72),
    dict(type='RandomCrop', crop_size=crop_size, cat_max_ratio=1.0),
    dict(type='RandomFlip', prob=0.5, direction='horizontal'),
    dict(type='PackSegInputs'),
]

test_pipeline = [
    dict(type='LoadRasterioImageFromFile', to_float32=False),
    dict(
        type='LoadRasterioAnnotations',
        ignore_index=ignore_index,
        no_train_labels=no_train_labels,
        white_ignore_value=(255, 255, 255),
        label_min=0,
        label_max=72),
    dict(type='PackSegInputs'),
]

train_dataloader = dict(
    batch_size=train_batch_size,
    num_workers=num_workers,
    persistent_workers=num_workers > 0,
    sampler=dict(type='DefaultSampler', shuffle=True),
    dataset=dict(
        type='Ningbo2mDataset',
        data_root=data_root,
        data_prefix=dict(img_path='train/images', seg_map_path='train/masks'),
        pipeline=train_pipeline))

val_dataloader = dict(
    batch_size=val_batch_size,
    num_workers=num_workers,
    persistent_workers=num_workers > 0,
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(
        type='Ningbo2mDataset',
        data_root=data_root,
        data_prefix=dict(img_path='val/images', seg_map_path='val/masks'),
        pipeline=test_pipeline))

test_dataloader = val_dataloader
val_evaluator = dict(
    type='IoUMetric', iou_metrics=['mIoU'], ignore_index=ignore_index)
test_evaluator = val_evaluator

model = dict(
    type='EncoderDecoder',
    data_preprocessor=data_preprocessor,
    backbone=dict(
        type='SwinTransformer',
        pretrain_img_size=224,
        in_channels=3,
        embed_dims=352,
        patch_size=4,
        window_size=7,
        mlp_ratio=4,
        depths=[2, 2, 18, 2],
        num_heads=[11, 22, 44, 88],
        strides=(4, 2, 2, 2),
        out_indices=(0, 1, 2, 3),
        qkv_bias=True,
        qk_scale=None,
        patch_norm=True,
        drop_rate=0.0,
        attn_drop_rate=0.0,
        drop_path_rate=0.3,
        use_abs_pos_embed=False,
        act_cfg=dict(type='GELU'),
        norm_cfg=backbone_norm_cfg,
        with_cp=True,
        frozen_stages=4,
        init_cfg=dict(
            type='Pretrained',
            checkpoint=swin_pretrained) if swin_pretrained else None),
    neck=dict(
        type='FPN',
        in_channels=[352, 704, 1408, 2816],
        out_channels=256,
        num_outs=4,
        norm_cfg=norm_cfg),
    decode_head=dict(
        type='UPerHead',
        in_channels=[256, 256, 256, 256],
        in_index=[0, 1, 2, 3],
        pool_scales=(1, 2, 3, 6),
        channels=512,
        dropout_ratio=0.1,
        num_classes=num_classes,
        norm_cfg=norm_cfg,
        align_corners=False,
        ignore_index=ignore_index,
        loss_decode=dict(
            type='CrossEntropyLoss',
            use_sigmoid=False,
            loss_weight=1.0)),
    train_cfg=dict(),
    test_cfg=dict(mode='whole'))

optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(
        type='AdamW', lr=base_learning_rate, weight_decay=weight_decay))

param_scheduler = [
    dict(
        type='LinearLR',
        start_factor=warmup_ratio,
        by_epoch=False,
        begin=0,
        end=warmup_iters),
    dict(
        type='PolyLR',
        eta_min=0.0,
        power=1.0,
        begin=0,
        end=max_epochs,
        by_epoch=True,
        convert_to_iter_based=True),
]

train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=max_epochs, val_interval=1)
val_cfg = dict(type='ValLoop')
test_cfg = dict(type='TestLoop')

custom_hooks = []

default_hooks = dict(
    timer=dict(type='IterTimerHook'),
    logger=dict(type='LoggerHook', interval=50, log_metric_by_epoch=True),
    param_scheduler=dict(type='ParamSchedulerHook'),
    checkpoint=dict(
        type='CheckpointHook',
        by_epoch=True,
        interval=1,
        save_best='mIoU',
        rule='greater',
        max_keep_ckpts=3),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    visualization=dict(type='SegVisualizationHook'))

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0),
    dist_cfg=dict(backend='nccl'))

vis_backends = [dict(type='LocalVisBackend')]
visualizer = dict(
    type='SegLocalVisualizer', vis_backends=vis_backends, name='visualizer')
log_processor = dict(by_epoch=True)
log_level = 'INFO'
load_from = None
resume = False
