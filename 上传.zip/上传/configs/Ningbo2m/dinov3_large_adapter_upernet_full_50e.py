import os

custom_imports = dict(imports=['dinov3_mmseg'], allow_failed_imports=False)
default_scope = 'mmseg'



data_root = os.getenv('NINGBO2M_DATA_ROOT', '')
dinov3_pretrained = os.getenv('DINOV3_PRETRAINED', '')
no_train_labels = []
work_dir = './work_dirs/Ningbo2m/dinov3_large_adapter_upernet_full_50e'

num_classes = 73
ignore_index = 255
crop_size = (512, 512)
max_epochs = 50
train_batch_size = 8
val_batch_size = 8
num_workers = 4
base_learning_rate = 5e-4
weight_decay = 0.01
warmup_iters = 1500
warmup_ratio = 1e-6

norm_cfg = dict(type='SyncBN', requires_grad=True)

data_preprocessor = dict(
    type='SegDataPreProcessor',
    mean=[123.675, 116.28, 103.53],
    std=[58.395, 57.12, 57.375],
    bgr_to_rgb=False,
    pad_val=0,
    seg_pad_val=ignore_index,
    size=crop_size)

train_pipeline = [
    dict(type='LoadRasterioImageFromFile', to_float32=False),
    dict(
        type='LoadRasterioAnnotations',
        ignore_index=ignore_index,
        no_train_labels=no_train_labels,
        white_ignore_value=(255, 255, 255),
        label_min=0,
        label_max=72),
    dict(type='RandomCrop', crop_size=crop_size, cat_max_ratio=1.0),
    dict(type='RandomFlip', prob=0.5, direction='horizontal'),
    dict(type='PackSegInputs'),
]

test_pipeline = [
    dict(type='LoadRasterioImageFromFile', to_float32=False),
    dict(
        type='LoadRasterioAnnotations',
        ignore_index=ignore_index,
        no_train_labels=no_train_labels,
        white_ignore_value=(255, 255, 255),
        label_min=0,
        label_max=72),
    dict(type='PackSegInputs'),
]

train_dataloader = dict(
    batch_size=train_batch_size,
    num_workers=num_workers,
    persistent_workers=num_workers > 0,
    sampler=dict(type='DefaultSampler', shuffle=True),
    dataset=dict(
        type='Ningbo2mDataset',
        data_root=data_root,
        data_prefix=dict(img_path='train/images', seg_map_path='train/masks'),
        pipeline=train_pipeline))

val_dataloader = dict(
    batch_size=val_batch_size,
    num_workers=num_workers,
    persistent_workers=num_workers > 0,
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(
        type='Ningbo2mDataset',
        data_root=data_root,
        data_prefix=dict(img_path='val/images', seg_map_path='val/masks'),
        pipeline=test_pipeline))

test_dataloader = val_dataloader
val_evaluator = dict(
    type='IoUMetric', iou_metrics=['mIoU'], ignore_index=ignore_index)
test_evaluator = val_evaluator

model = dict(
    type='EncoderDecoder',
    data_preprocessor=data_preprocessor,
    backbone=dict(
        type='DINOv3ViTAdapter',
        arch='vitl16',
        img_size=crop_size[0],
        patch_size=16,
        in_channels=3,
        interaction_indexes=(5, 11, 17, 23),
        pretrain_size=crop_size[0],
        conv_inplane=64,
        n_points=4,
        deform_num_heads=16,
        drop_path_rate=0.3,
        with_cffn=True,
        cffn_ratio=0.25,
        deform_ratio=0.5,
        add_vit_feature=True,
        use_extra_extractor=True,
        with_cp=True,
        frozen_backbone=False,
        norm=True,
        norm_eval=True,
        untie_global_and_local_cls_norm=True,
        backbone_init_cfg=dict(
            type='Pretrained',
            checkpoint=dinov3_pretrained,
            strict=False) if dinov3_pretrained else None),
    decode_head=dict(
        type='UPerHead',
        in_channels=[1024, 1024, 1024, 1024],
        in_index=[0, 1, 2, 3],
        pool_scales=(1, 2, 3, 6),
        channels=512,
        dropout_ratio=0.1,
        num_classes=num_classes,
        norm_cfg=norm_cfg,
        align_corners=False,
        ignore_index=ignore_index,
        loss_decode=dict(
            type='CrossEntropyLoss',
            use_sigmoid=False,
            loss_weight=1.0)),
    train_cfg=dict(),
    test_cfg=dict(mode='whole'))

optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(
        type='AdamW', lr=base_learning_rate, weight_decay=weight_decay))

param_scheduler = [
    dict(
        type='LinearLR',
        start_factor=warmup_ratio,
        by_epoch=False,
        begin=0,
        end=warmup_iters),
    dict(
        type='PolyLR',
        eta_min=0.0,
        power=1.0,
        begin=0,
        end=max_epochs,
        by_epoch=True,
        convert_to_iter_based=True),
]

train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=max_epochs, val_interval=1)
val_cfg = dict(type='ValLoop')
test_cfg = dict(type='TestLoop')

custom_hooks = []

default_hooks = dict(
    timer=dict(type='IterTimerHook'),
    logger=dict(type='LoggerHook', interval=50, log_metric_by_epoch=True),
    param_scheduler=dict(type='ParamSchedulerHook'),
    checkpoint=dict(
        type='CheckpointHook',
        by_epoch=True,
        interval=1,
        save_best='mIoU',
        rule='greater',
        max_keep_ckpts=3),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    visualization=dict(type='SegVisualizationHook'))

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0),
    dist_cfg=dict(backend='nccl'))

vis_backends = [dict(type='LocalVisBackend')]
visualizer = dict(
    type='SegLocalVisualizer', vis_backends=vis_backends, name='visualizer')
log_processor = dict(by_epoch=True)
log_level = 'INFO'
load_from = None
resume = False
