"""Static checks for the four-class BRIGHT OpenCD plugin files."""

from __future__ import annotations

import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / "configs" / "BRIGHT"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


class TestBRIGHT4ClassesStatic(unittest.TestCase):

    def test_bright_4classes_files_exist(self):
        required = [
            ROOT / "datasets" / "bright_4classes_dataset.py",
            ROOT / "datasets" / "transforms" /
            "bright_4classes_transforms.py",
            CONFIG_DIR /
            "bright_4classes_dual_swin_huge_upernet_frozen_50e_128x128.py",
            CONFIG_DIR /
            "bright_4classes_dual_swin_huge_upernet_ft_backbone_lr_mult_0p1_50e_128x128.py",
        ]
        for path in required:
            self.assertTrue(path.exists(), msg=str(path))

    def test_configs_do_not_use_python_import_statements(self):
        for path in CONFIG_DIR.glob("bright_4classes_*.py"):
            tree = ast.parse(_read(path), filename=str(path))
            imports = (ast.Import, ast.ImportFrom)
            self.assertFalse(
                any(isinstance(node, imports) for node in ast.walk(tree)),
                msg=str(path))

    def test_configs_match_bright_training_strategy_but_use_four_classes(self):
        for path in CONFIG_DIR.glob("bright_4classes_*.py"):
            text = _read(path)
            self.assertIn(
                "evaluation=dict(tmpdir='/mnt/htzzb2/EO_test/wj1/tmp')",
                text)
            self.assertIn("find_unused_parameters=True", text)
            self.assertIn('work_dir=""', text)
            self.assertIn('custom_imports = dict(imports=["swin_opencd"]', text)
            self.assertIn("input_size = (128, 128)", text)
            self.assertIn("num_classes = 4", text)
            self.assertIn("batch_size = 16", text)
            self.assertIn("max_epochs = 50", text)
            self.assertIn("base_lr = 1e-4", text)
            self.assertIn("weight_decay = 0.01", text)
            self.assertIn(
                "mean=[88.674, 85.027, 76.558, 56.630]",
                text)
            self.assertIn(
                "std=[67.434, 58.458, 53.972, 45.191]",
                text)
            self.assertIn('ann_file="train.txt"', text)
            self.assertIn('ann_file="val.txt"', text)
            self.assertIn('type="EpochBasedTrainLoop"', text)
            self.assertIn("by_epoch=True", text)
            self.assertIn('dataset_type = "BRIGHT4ClassesDataset"', text)
            self.assertIn('type="BRIGHT4ClassesLoadRasterio"', text)

    def test_configs_use_bright_folders_and_no_rotation_aug(self):
        for path in CONFIG_DIR.glob("bright_4classes_*.py"):
            text = _read(path)
            self.assertIn('img_path_from="train/pre-event"', text)
            self.assertIn('img_path_to="train/post-event"', text)
            self.assertIn('seg_map_path="train/target"', text)
            self.assertIn('img_path_from="val/pre-event"', text)
            self.assertIn('img_path_to="val/post-event"', text)
            self.assertIn('seg_map_path="val/target"', text)
            self.assertIn('type="MultiImgRandomFlip"', text)
            self.assertNotIn("Rotate", text)
            self.assertNotIn("RandomRot", text)

    def test_config_variants_encode_freeze_and_backbone_lr_mult(self):
        frozen = _read(
            CONFIG_DIR /
            "bright_4classes_dual_swin_huge_upernet_frozen_50e_128x128.py")
        finetune = _read(
            CONFIG_DIR /
            "bright_4classes_dual_swin_huge_upernet_ft_backbone_lr_mult_0p1_50e_128x128.py"
        )
        self.assertIn("freeze_backbones=True", frozen)
        self.assertIn("freeze_backbones=False", finetune)
        self.assertIn('"backbone": dict(lr_mult=0.1)', finetune)
        self.assertIn('"sar_backbone": dict(lr_mult=0.1)', finetune)

    def test_dataset_uses_four_class_metainfo_and_ann_file_fast_path(self):
        text = _read(ROOT / "datasets" / "bright_4classes_dataset.py")
        for class_name in ("background", "intact", "damaged", "destroyed"):
            self.assertIn(class_name, text)
        self.assertIn("if self.ann_file:", text)
        self.assertIn("list_from_file(", text)
        self.assertIn("recursive=False", text)
        self.assertNotIn("BRIGHTDataset", text)

    def test_transform_keeps_four_label_values_without_binary_mapping(self):
        text = _read(ROOT / "datasets" / "transforms" /
                     "bright_4classes_transforms.py")
        self.assertIn("import rasterio", text)
        self.assertIn("dataset.read()", text)
        self.assertIn("np.isin(label[0], (0, 1, 2, 3))", text)
        self.assertIn("gt_seg_map[valid] = label[0][valid]", text)
        self.assertNotIn("np.where(label[0] > 0, 1, 0)", text)
        self.assertNotIn("reproject", text)
        self.assertNotIn("warp", text)
        self.assertNotIn("rotate", text.lower())

    def test_shared_exports_preserve_old_bright_and_add_four_classes(self):
        datasets_init = _read(ROOT / "datasets" / "__init__.py")
        transforms_init = _read(ROOT / "datasets" / "transforms" / "__init__.py")
        self.assertIn("from .bright_dataset import BRIGHTDataset",
                      datasets_init)
        self.assertIn("from .bright_4classes_dataset import BRIGHT4ClassesDataset",
                      datasets_init)
        self.assertIn("BRIGHTDataset", datasets_init)
        self.assertIn("BRIGHT4ClassesDataset", datasets_init)
        self.assertIn("from .bright_transforms import BRIGHTLoadRasterio",
                      transforms_init)
        self.assertIn(
            "from .bright_4classes_transforms import BRIGHT4ClassesLoadRasterio",
            transforms_init)
        self.assertIn("BRIGHTLoadRasterio", transforms_init)
        self.assertIn("BRIGHT4ClassesLoadRasterio", transforms_init)


if __name__ == "__main__":
    unittest.main()
