"""Static checks for the LEVIR-CD OpenCD plugin files."""

from __future__ import annotations

import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / "configs" / "LEVIR-CD"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


class TestLEVIRCDStatic(unittest.TestCase):

    def test_levir_cd_plugin_files_exist(self):
        required = [
            ROOT / "datasets" / "levir_cd_dataset.py",
            ROOT / "datasets" / "transforms" / "levir_cd_transforms.py",
            ROOT / "models" / "change_detectors" /
            "shared_swin_absdiff_upernet.py",
            CONFIG_DIR /
            "levir_cd_shared_swin_huge_upernet_frozen_50e_128x128.py",
            CONFIG_DIR /
            "levir_cd_shared_swin_huge_upernet_ft_backbone_lr_mult_0p1_50e_128x128.py",
        ]
        for path in required:
            self.assertTrue(path.exists(), msg=str(path))

    def test_configs_do_not_use_python_import_statements(self):
        for path in CONFIG_DIR.glob("*.py"):
            tree = ast.parse(_read(path), filename=str(path))
            imports = (ast.Import, ast.ImportFrom)
            self.assertFalse(
                any(isinstance(node, imports) for node in ast.walk(tree)),
                msg=str(path))

    def test_configs_encode_requested_training_settings(self):
        for path in CONFIG_DIR.glob("*.py"):
            text = _read(path)
            self.assertIn(
                "evaluation=dict(tmpdir='/mnt/htzzb2/EO_test/wj1/tmp')",
                text)
            self.assertIn("find_unused_parameters=True", text)
            self.assertIn('custom_imports = dict(imports=["swin_opencd"]', text)
            self.assertIn("input_size = (128, 128)", text)
            self.assertIn("batch_size = 4", text)
            self.assertIn("max_epochs = 50", text)
            self.assertIn("base_lr = 1e-4", text)
            self.assertIn("weight_decay = 0.01", text)
            self.assertIn('type="AdamW"', text)
            self.assertIn('type="PolyLR"', text)
            self.assertIn('type="LinearLR"', text)
            self.assertIn("start_factor=1e-6", text)
            self.assertIn("end=1500", text)
            self.assertIn('type="EpochBasedTrainLoop"', text)
            self.assertIn("by_epoch=True", text)
            self.assertIn('type="mmseg.UPerHead"', text)
            self.assertIn('type="mmseg.CrossEntropyLoss"', text)
            self.assertIn('type="MultiImgRandomFlip"', text)

    def test_configs_use_levir_cd_folders(self):
        for path in CONFIG_DIR.glob("*.py"):
            text = _read(path)
            self.assertIn('data_root = "data/LEVIR-CD"', text)
            self.assertIn('dataset_type = "LEVIRCDDataset"', text)
            self.assertIn('type="LEVIRCDLoadRasterio"', text)
            self.assertIn('img_path_from="train_sliced/A"', text)
            self.assertIn('img_path_to="train_sliced/B"', text)
            self.assertIn('seg_map_path="train_sliced/label"', text)
            self.assertIn('img_path_from="val_sliced/A"', text)
            self.assertIn('img_path_to="val_sliced/B"', text)
            self.assertIn('seg_map_path="val_sliced/label"', text)
            self.assertIn('img_path_from="test_sliced/A"', text)
            self.assertIn('img_path_to="test_sliced/B"', text)
            self.assertIn('seg_map_path="test_sliced/label"', text)

    def test_config_variants_encode_freeze_and_backbone_lr_mult(self):
        frozen = _read(
            CONFIG_DIR /
            "levir_cd_shared_swin_huge_upernet_frozen_50e_128x128.py")
        finetune = _read(
            CONFIG_DIR /
            "levir_cd_shared_swin_huge_upernet_ft_backbone_lr_mult_0p1_50e_128x128.py"
        )
        self.assertIn("freeze_backbone=True", frozen)
        self.assertNotIn("paramwise_cfg", frozen)
        self.assertIn("freeze_backbone=False", finetune)
        self.assertIn('"backbone": dict(lr_mult=0.1)', finetune)

    def test_shared_model_uses_one_backbone_and_abs_feature_diff(self):
        text = _read(
            ROOT / "models" / "change_detectors" /
            "shared_swin_absdiff_upernet.py")
        self.assertIn("class SharedSwinAbsDiffUPerNet", text)
        self.assertIn("super().__init__(backbone=backbone", text)
        self.assertIn("input_split=(3, 3)", text)
        self.assertIn("a_feats = self.backbone(a_x)", text)
        self.assertIn("b_feats = self.backbone(b_x)", text)
        self.assertIn("torch.abs(a_feat - b_feat)", text)
        self.assertNotIn("sar_backbone", text)

    def test_levir_transform_uses_rasterio_and_maps_binary_label(self):
        text = _read(
            ROOT / "datasets" / "transforms" / "levir_cd_transforms.py")
        self.assertIn("import rasterio", text)
        self.assertIn("dataset.read()", text)
        self.assertIn("results[\"img\"] = [a_image, b_image]", text)
        self.assertIn("np.where(label[0] > 0, 1, 0)", text)
        self.assertNotIn("reproject", text)
        self.assertNotIn("warp", text)
        self.assertNotIn("rotate", text.lower())

    def test_shared_exports_preserve_existing_names(self):
        datasets_init = _read(ROOT / "datasets" / "__init__.py")
        transforms_init = _read(ROOT / "datasets" / "transforms" / "__init__.py")
        detectors_init = _read(
            ROOT / "models" / "change_detectors" / "__init__.py")
        self.assertIn("CAUFLOODDataset", datasets_init)
        self.assertIn("BRIGHTDataset", datasets_init)
        self.assertIn("LEVIRCDDataset", datasets_init)
        self.assertIn("CAUFLOODLoadRasterio", transforms_init)
        self.assertIn("BRIGHTLoadRasterio", transforms_init)
        self.assertIn("LEVIRCDLoadRasterio", transforms_init)
        self.assertIn("DualSwinAbsDiffUPerNet", detectors_init)
        self.assertIn("SharedSwinAbsDiffUPerNet", detectors_init)


if __name__ == "__main__":
    unittest.main()
