"""Static checks for the CAU_FLOOD OpenCD plugin files."""

from __future__ import annotations

import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / "configs" / "CAU_FLOOD"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


class TestCAUFLOODStatic(unittest.TestCase):

    def test_configs_do_not_use_python_import_statements(self):
        for path in CONFIG_DIR.glob("*.py"):
            tree = ast.parse(_read(path), filename=str(path))
            imports = (ast.Import, ast.ImportFrom)
            self.assertFalse(
                any(isinstance(node, imports) for node in ast.walk(tree)),
                msg=str(path))

    def test_configs_use_root_importable_plugin_module(self):
        for path in CONFIG_DIR.glob("*.py"):
            text = _read(path)
            self.assertIn(
                'custom_imports = dict(imports=["swin_opencd"]',
                text)

    def test_configs_use_epoch_based_training_and_requested_tmpdir(self):
        for path in CONFIG_DIR.glob("*.py"):
            text = _read(path)
            self.assertIn(
                "evaluation=dict(tmpdir='/mnt/htzzb2/EO_test/wj1/tmp')",
                text)
            self.assertIn('type="EpochBasedTrainLoop"', text)
            self.assertIn("by_epoch=True", text)
            self.assertIn("max_epochs = 50", text)

    def test_config_variants_encode_freeze_and_backbone_lr_mult(self):
        frozen = _read(
            CONFIG_DIR /
            "cau_flood_dual_swin_huge_upernet_frozen_50e_256x256.py")
        finetune = _read(
            CONFIG_DIR /
            "cau_flood_dual_swin_huge_upernet_ft_backbone_lr_mult_0p1_50e_256x256.py"
        )
        self.assertIn("freeze_backbones=True", frozen)
        self.assertIn("freeze_backbones=False", finetune)
        self.assertIn('"backbone": dict(lr_mult=0.1)', finetune)
        self.assertIn('"sar_backbone": dict(lr_mult=0.1)', finetune)

    def test_plugin_uses_rasterio_and_sar_repeat_inside_model(self):
        transform = _read(
            ROOT / "datasets" / "transforms" /
            "cau_flood_transforms.py")
        model = _read(
            ROOT / "models" / "change_detectors" /
            "dual_swin_absdiff_upernet.py")
        self.assertIn("import rasterio", transform)
        self.assertIn("vv_valid = vv != 0", transform)
        self.assertIn("sar_x = sar_x.repeat(1, 3, 1, 1)", model)
        self.assertIn("torch.abs(sar_feat - opt_feat)", model)


if __name__ == "__main__":
    unittest.main()
