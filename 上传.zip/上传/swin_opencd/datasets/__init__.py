"""Dataset registrations for the Swin Open-CD plugin."""

from .bright_dataset import BRIGHTDataset
from .cau_flood_dataset import CAUFLOODDataset
from .levir_cd_dataset import LEVIRCDDataset
from .transforms import *  # noqa: F401,F403

__all__ = ["CAUFLOODDataset", "BRIGHTDataset", "LEVIRCDDataset"]
