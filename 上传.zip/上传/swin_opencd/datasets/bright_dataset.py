"""BRIGHT optical-SAR binary change detection dataset."""

from __future__ import annotations

from .._registry import DATASETS

_IMPORT_ERROR = None

try:
    import os.path as osp

    from mmengine import fileio
    from opencd.datasets.basecddataset import _BaseCDDataset
except ImportError as exc:  # pragma: no cover - local machines may lack deps.
    _IMPORT_ERROR = exc
    _BaseCDDataset = object


def _missing_dependency_message() -> str:
    return (
        "BRIGHTDataset requires Open-CD and MMEngine to be installed and "
        f"importable. The current import error was: {_IMPORT_ERROR!r}")


if _IMPORT_ERROR is not None:

    @DATASETS.register_module()
    class BRIGHTDataset(_BaseCDDataset):
        """Placeholder used when Open-CD is unavailable."""

        METAINFO = dict(
            classes=("unchanged", "changed"),
            palette=[[0, 0, 0], [255, 255, 255]],
        )

        def __init__(self, *args, **kwargs):
            raise ImportError(_missing_dependency_message())

else:

    @DATASETS.register_module()
    class BRIGHTDataset(_BaseCDDataset):
        """BRIGHT dataset with pre-event/post-event/target folders."""

        METAINFO = dict(
            classes=("unchanged", "changed"),
            palette=[[0, 0, 0], [255, 255, 255]],
        )

        def __init__(self,
                     img_suffix=".tif",
                     seg_map_suffix=".tif",
                     format_seg_map=None,
                     **kwargs):
            super().__init__(
                img_suffix=img_suffix,
                seg_map_suffix=seg_map_suffix,
                format_seg_map=format_seg_map,
                **kwargs)

        def load_data_list(self):
            """Load optical, SAR, and label triplets."""
            data_list = []
            opt_dir = self.data_prefix.get("img_path_from", None)
            sar_dir = self.data_prefix.get("img_path_to", None)
            ann_dir = self.data_prefix.get("seg_map_path", None)
            if opt_dir is None or sar_dir is None or ann_dir is None:
                raise ValueError(
                    "BRIGHTDataset requires data_prefix keys: "
                    "img_path_from, img_path_to, and seg_map_path.")

            opt_files = self._list_files(opt_dir, self.img_suffix)
            sar_names = set(self._list_files(sar_dir, self.img_suffix))
            ann_names = set(self._list_files(ann_dir, self.seg_map_suffix))

            for opt_name in opt_files:
                label_name = opt_name.replace(
                    self.img_suffix, self.seg_map_suffix)
                if opt_name not in sar_names:
                    raise FileNotFoundError(
                        "Cannot find BRIGHT post-event SAR counterpart for "
                        f"{opt_name}.")
                if label_name not in ann_names:
                    raise FileNotFoundError(
                        "Cannot find BRIGHT target counterpart for "
                        f"{label_name}.")
                data_info = dict(
                    img_path=[
                        osp.join(opt_dir, opt_name),
                        osp.join(sar_dir, opt_name),
                    ],
                    seg_map_path=osp.join(ann_dir, label_name),
                    label_map=self.label_map,
                    format_seg_map=self.format_seg_map,
                    reduce_zero_label=self.reduce_zero_label,
                    seg_fields=[],
                )
                data_list.append(data_info)

            return sorted(data_list, key=lambda item: item["img_path"][0])

        def _list_files(self, directory, suffix):
            return sorted(
                fileio.list_dir_or_file(
                    dir_path=directory,
                    list_dir=False,
                    suffix=suffix,
                    recursive=True,
                    backend_args=self.backend_args))


__all__ = ["BRIGHTDataset"]
