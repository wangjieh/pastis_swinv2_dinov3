"""Rasterio loading transform for LEVIR-CD."""

from __future__ import annotations

from ..._registry import TRANSFORMS

try:
    import numpy as np
except ImportError as exc:  # pragma: no cover
    np = None
    _NUMPY_IMPORT_ERROR = exc
else:
    _NUMPY_IMPORT_ERROR = None

try:
    import rasterio
except ImportError as exc:  # pragma: no cover
    rasterio = None
    _RASTERIO_IMPORT_ERROR = exc
else:
    _RASTERIO_IMPORT_ERROR = None

try:
    from mmcv.transforms import BaseTransform
except ImportError:  # pragma: no cover - local machines may lack MMCV.

    class BaseTransform:
        """Fallback base class with MMEngine-like call behavior."""

        def __call__(self, results):
            return self.transform(results)


def _require_numpy():
    if np is None:
        raise ImportError(
            "LEVIR-CD transforms require numpy. The import error was: "
            f"{_NUMPY_IMPORT_ERROR!r}")


def _require_rasterio():
    if rasterio is None:
        raise ImportError(
            "LEVIR-CD transforms require rasterio. The import error was: "
            f"{_RASTERIO_IMPORT_ERROR!r}")


def _read_raster(path):
    _require_rasterio()
    with rasterio.open(path) as dataset:
        return dataset.read()


def _as_hwc(array):
    return np.moveaxis(array, 0, -1)


@TRANSFORMS.register_module()
class LEVIRCDLoadRasterio(BaseTransform):
    """Load LEVIR-CD A/B RGB PNGs and a grayscale binary mask."""

    def __init__(self, rgb_channels=(0, 1, 2)):
        self.rgb_channels = tuple(int(index) for index in rgb_channels)
        if len(self.rgb_channels) != 3:
            raise ValueError("rgb_channels must contain three RGB indices.")

    def transform(self, results):
        _require_numpy()

        a_path, b_path = results["img_path"]
        a_image = _read_raster(a_path)
        b_image = _read_raster(b_path)
        if a_image.shape[0] < 3:
            raise ValueError(
                f"Expected at least 3 A-image bands, got {a_image.shape[0]}.")
        if b_image.shape[0] < 3:
            raise ValueError(
                f"Expected at least 3 B-image bands, got {b_image.shape[0]}.")

        a_image = a_image[list(self.rgb_channels)].astype(np.float32)
        b_image = b_image[list(self.rgb_channels)].astype(np.float32)
        a_image = _as_hwc(a_image)
        b_image = _as_hwc(b_image)

        results["img"] = [a_image, b_image]
        results["img_shape"] = a_image.shape[:2]
        results["ori_shape"] = a_image.shape[:2]

        if "seg_map_path" in results:
            label = _read_raster(results["seg_map_path"])
            results["gt_seg_map"] = np.where(label[0] > 0, 1, 0).astype(
                np.uint8)
            results.setdefault("seg_fields", []).append("gt_seg_map")

        return results


__all__ = ["LEVIRCDLoadRasterio"]
