"""Transform registrations for the Swin Open-CD plugin."""

from .cau_flood_transforms import CAUFLOODLoadRasterio

__all__ = ["CAUFLOODLoadRasterio"]
