"""Transform registrations for the Swin Open-CD plugin."""

from .bright_4classes_transforms import BRIGHT4ClassesLoadRasterio
from .bright_transforms import BRIGHTLoadRasterio
from .cau_flood_transforms import CAUFLOODLoadRasterio
from .levir_cd_transforms import LEVIRCDLoadRasterio

__all__ = [
    "CAUFLOODLoadRasterio",
    "BRIGHTLoadRasterio",
    "BRIGHT4ClassesLoadRasterio",
    "LEVIRCDLoadRasterio",
]
