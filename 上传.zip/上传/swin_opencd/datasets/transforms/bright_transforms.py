"""Rasterio loading transform for BRIGHT."""

from __future__ import annotations

from ..._registry import TRANSFORMS

try:
    import numpy as np
except ImportError as exc:  # pragma: no cover
    np = None
    _NUMPY_IMPORT_ERROR = exc
else:
    _NUMPY_IMPORT_ERROR = None

try:
    import rasterio
except ImportError as exc:  # pragma: no cover
    rasterio = None
    _RASTERIO_IMPORT_ERROR = exc
else:
    _RASTERIO_IMPORT_ERROR = None

try:
    from mmcv.transforms import BaseTransform
except ImportError:  # pragma: no cover - local machines may lack MMCV.

    class BaseTransform:
        """Fallback base class with MMEngine-like call behavior."""

        def __call__(self, results):
            return self.transform(results)


def _require_numpy():
    if np is None:
        raise ImportError(
            "BRIGHT transforms require numpy. The import error was: "
            f"{_NUMPY_IMPORT_ERROR!r}")


def _require_rasterio():
    if rasterio is None:
        raise ImportError(
            "BRIGHT transforms require rasterio. The import error was: "
            f"{_RASTERIO_IMPORT_ERROR!r}")


def _read_raster(path):
    _require_rasterio()
    with rasterio.open(path) as dataset:
        return dataset.read()


def _as_hwc(array):
    return np.moveaxis(array, 0, -1)


@TRANSFORMS.register_module()
class BRIGHTLoadRasterio(BaseTransform):
    """Load BRIGHT optical/SAR TIFF triplets."""

    def __init__(self, opt_channels=(0, 1, 2)):
        self.opt_channels = tuple(int(index) for index in opt_channels)
        if len(self.opt_channels) != 3:
            raise ValueError("opt_channels must contain three RGB indices.")

    def transform(self, results):
        _require_numpy()

        opt_path, sar_path = results["img_path"]
        opt = _read_raster(opt_path)
        sar = _read_raster(sar_path)
        if opt.shape[0] < 3:
            raise ValueError(
                f"Expected at least 3 optical bands, got {opt.shape[0]}.")
        if sar.shape[0] < 1:
            raise ValueError(
                f"Expected at least 1 SAR band, got {sar.shape[0]}.")

        opt = opt[list(self.opt_channels)].astype(np.float32)
        sar = sar[0].astype(np.float32)
        opt_image = _as_hwc(opt)
        sar_image = sar[..., None]

        results["img"] = [opt_image, sar_image]
        results["img_shape"] = opt_image.shape[:2]
        results["ori_shape"] = opt_image.shape[:2]

        if "seg_map_path" in results:
            label = _read_raster(results["seg_map_path"])
            results["gt_seg_map"] = np.where(label[0] > 0, 1, 0).astype(
                np.uint8)
            results.setdefault("seg_fields", []).append("gt_seg_map")

        return results


__all__ = ["BRIGHTLoadRasterio"]
