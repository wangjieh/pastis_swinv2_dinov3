"""Rasterio loading transform for CAU_FLOOD."""

from __future__ import annotations

from ..._registry import TRANSFORMS

try:
    import numpy as np
except ImportError as exc:  # pragma: no cover
    np = None
    _NUMPY_IMPORT_ERROR = exc
else:
    _NUMPY_IMPORT_ERROR = None

try:
    import rasterio
except ImportError as exc:  # pragma: no cover
    rasterio = None
    _RASTERIO_IMPORT_ERROR = exc
else:
    _RASTERIO_IMPORT_ERROR = None

try:
    from mmcv.transforms import BaseTransform
except ImportError:  # pragma: no cover - local machines may lack MMCV.

    class BaseTransform:
        """Fallback base class with MMEngine-like call behavior."""

        def __call__(self, results):
            return self.transform(results)


def _require_numpy():
    if np is None:
        raise ImportError(
            "CAU_FLOOD transforms require numpy. The import error was: "
            f"{_NUMPY_IMPORT_ERROR!r}")


def _require_rasterio():
    if rasterio is None:
        raise ImportError(
            "CAU_FLOOD transforms require rasterio. The import error was: "
            f"{_RASTERIO_IMPORT_ERROR!r}")


def _read_raster(path):
    _require_rasterio()
    with rasterio.open(path) as dataset:
        array = dataset.read()
        mask = dataset.dataset_mask()
    return array, mask


def _as_hwc(array):
    return np.moveaxis(array, 0, -1)


@TRANSFORMS.register_module()
class CAUFLOODLoadRasterio(BaseTransform):
    """Load CAU_FLOOD PNG triplets and build the ignore mask.

    Output ``results["img"]`` is ``[opt_rgb, vv]``. Open-CD's
    ``MultiImgPackSegInputs`` concatenates them into a 4-channel tensor; the
    model repeats the VV channel to 3 channels before the SAR Swin branch.
    """

    def __init__(self,
                 ignore_index=255,
                 opt_channels=(0, 1, 2),
                 use_opt_all_zero_as_nodata=True):
        self.ignore_index = int(ignore_index)
        self.opt_channels = tuple(int(index) for index in opt_channels)
        if len(self.opt_channels) != 3:
            raise ValueError("opt_channels must contain three RGB indices.")
        self.use_opt_all_zero_as_nodata = bool(use_opt_all_zero_as_nodata)

    def transform(self, results):
        _require_numpy()

        opt_path, vv_path = results["img_path"]
        opt, opt_mask = _read_raster(opt_path)
        vv, _ = _read_raster(vv_path)
        if opt.shape[0] < 3:
            raise ValueError(
                f"Expected at least 3 optical bands, got {opt.shape[0]}.")
        if vv.shape[0] < 1:
            raise ValueError(f"Expected at least 1 VV band, got {vv.shape[0]}.")

        opt = opt[list(self.opt_channels)].astype(np.float32)
        vv = vv[0].astype(np.float32)
        opt_image = _as_hwc(opt)
        vv_image = vv[..., None]

        opt_valid = opt_mask != 0
        if self.use_opt_all_zero_as_nodata:
            opt_valid = opt_valid & np.any(opt != 0, axis=0)
        vv_valid = vv != 0
        valid_mask = opt_valid & vv_valid

        results["img"] = [opt_image, vv_image]
        results["img_shape"] = opt_image.shape[:2]
        results["ori_shape"] = opt_image.shape[:2]
        results["cau_flood_valid_mask"] = valid_mask

        if "seg_map_path" in results:
            label, _ = _read_raster(results["seg_map_path"])
            gt_seg_map = np.where(label[0] > 0, 1, 0).astype(np.uint8)
            gt_seg_map[~valid_mask] = self.ignore_index
            results["gt_seg_map"] = gt_seg_map
            results.setdefault("seg_fields", []).append("gt_seg_map")

        return results


__all__ = ["CAUFLOODLoadRasterio"]
