"""LEVIR-CD binary change detection dataset."""

from __future__ import annotations

from .._registry import DATASETS

_IMPORT_ERROR = None

try:
    from opencd.datasets.basecddataset import _BaseCDDataset
except ImportError as exc:  # pragma: no cover - local machines may lack deps.
    _IMPORT_ERROR = exc
    _BaseCDDataset = object


def _missing_dependency_message() -> str:
    return (
        "LEVIRCDDataset requires Open-CD to be installed and importable. "
        f"The current import error was: {_IMPORT_ERROR!r}")


if _IMPORT_ERROR is not None:

    @DATASETS.register_module()
    class LEVIRCDDataset(_BaseCDDataset):
        """Placeholder used when Open-CD is unavailable."""

        METAINFO = dict(
            classes=("unchanged", "changed"),
            palette=[[0, 0, 0], [255, 255, 255]],
        )

        def __init__(self, *args, **kwargs):
            raise ImportError(_missing_dependency_message())

else:

    @DATASETS.register_module()
    class LEVIRCDDataset(_BaseCDDataset):
        """LEVIR-CD sliced RGB image pairs with binary change masks."""

        METAINFO = dict(
            classes=("unchanged", "changed"),
            palette=[[0, 0, 0], [255, 255, 255]],
        )

        def __init__(self,
                     img_suffix=".png",
                     seg_map_suffix=".png",
                     format_seg_map=None,
                     **kwargs):
            super().__init__(
                img_suffix=img_suffix,
                seg_map_suffix=seg_map_suffix,
                format_seg_map=format_seg_map,
                **kwargs)


__all__ = ["LEVIRCDDataset"]
