"""Shared Swin absolute-difference UPerNet change detector."""

from __future__ import annotations

from ..._registry import MODELS

_IMPORT_ERROR = None

try:
    import torch
    from opencd.models.change_detectors.siamencoder_decoder import (
        SiamEncoderDecoder,
    )
except ImportError as exc:  # pragma: no cover - local machines may lack deps.
    _IMPORT_ERROR = exc
    SiamEncoderDecoder = object


def _missing_dependency_message() -> str:
    return (
        "SharedSwinAbsDiffUPerNet requires PyTorch and Open-CD to be "
        "installed and importable. The current import error was: "
        f"{_IMPORT_ERROR!r}")


if _IMPORT_ERROR is not None:

    @MODELS.register_module()
    class SharedSwinAbsDiffUPerNet(SiamEncoderDecoder):
        """Placeholder used when Open-CD dependencies are unavailable."""

        def __init__(self, *args, **kwargs):
            raise ImportError(_missing_dependency_message())

else:

    @MODELS.register_module()
    class SharedSwinAbsDiffUPerNet(SiamEncoderDecoder):
        """Two RGB times share one Swin backbone and fuse abs feature diff."""

        def __init__(self,
                     backbone,
                     input_split=(3, 3),
                     freeze_backbone=False,
                     **kwargs):
            super().__init__(backbone=backbone, **kwargs)
            self.input_split = tuple(int(value) for value in input_split)
            if self.input_split != (3, 3):
                raise ValueError(
                    "SharedSwinAbsDiffUPerNet expects input_split=(3, 3): "
                    "RGB image A plus RGB image B.")
            self.freeze_backbone = bool(freeze_backbone)
            if self.freeze_backbone:
                self._set_backbone_trainable(False)

        def _set_backbone_trainable(self, trainable):
            for param in self.backbone.parameters():
                param.requires_grad = trainable
            if not trainable:
                self.backbone.eval()

        def train(self, mode=True):
            super().train(mode)
            if self.freeze_backbone:
                self.backbone.eval()
            return self

        def extract_feat(self, inputs):
            """Extract A/B RGB features and fuse each stage with abs(A - B)."""
            a_channels, b_channels = self.input_split
            expected_channels = a_channels + b_channels
            if inputs.shape[1] != expected_channels:
                raise ValueError(
                    f"Expected {expected_channels} input channels, got "
                    f"{inputs.shape[1]}.")

            a_x = inputs[:, :a_channels, :, :]
            b_x = inputs[:, a_channels:, :, :]

            a_feats = self.backbone(a_x)
            b_feats = self.backbone(b_x)
            if len(a_feats) != len(b_feats):
                raise ValueError(
                    "A and B backbone passes must return the same number of "
                    f"feature maps, got {len(a_feats)} and {len(b_feats)}.")

            diff_feats = []
            for a_feat, b_feat in zip(a_feats, b_feats):
                if a_feat.shape != b_feat.shape:
                    raise ValueError(
                        "A and B feature maps must have identical shapes, "
                        f"got {tuple(a_feat.shape)} and "
                        f"{tuple(b_feat.shape)}.")
                diff_feats.append(torch.abs(a_feat - b_feat))

            diff_feats = tuple(diff_feats)
            if self.with_neck:
                return self.neck(diff_feats)
            return diff_feats


__all__ = ["SharedSwinAbsDiffUPerNet"]
