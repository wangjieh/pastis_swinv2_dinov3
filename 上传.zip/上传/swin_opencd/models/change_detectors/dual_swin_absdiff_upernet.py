"""Dual Swin absolute-difference UPerNet change detector."""

from __future__ import annotations

from ..._registry import MODELS

_IMPORT_ERROR = None

try:
    import torch
    from opencd.models.change_detectors.siamencoder_decoder import (
        SiamEncoderDecoder,
    )
except ImportError as exc:  # pragma: no cover - local machines may lack deps.
    _IMPORT_ERROR = exc
    SiamEncoderDecoder = object


def _missing_dependency_message() -> str:
    return (
        "DualSwinAbsDiffUPerNet requires PyTorch and Open-CD to be installed "
        f"and importable. The current import error was: {_IMPORT_ERROR!r}")


if _IMPORT_ERROR is not None:

    @MODELS.register_module()
    class DualSwinAbsDiffUPerNet(SiamEncoderDecoder):
        """Placeholder used when Open-CD dependencies are unavailable."""

        def __init__(self, *args, **kwargs):
            raise ImportError(_missing_dependency_message())

else:

    @MODELS.register_module()
    class DualSwinAbsDiffUPerNet(SiamEncoderDecoder):
        """Two independent Swin branches fused with abs(SAR - OPT)."""

        def __init__(self,
                     opt_backbone,
                     sar_backbone,
                     input_split=(3, 1),
                     freeze_backbones=False,
                     **kwargs):
            super().__init__(backbone=opt_backbone, **kwargs)
            self.sar_backbone = MODELS.build(sar_backbone)
            self.input_split = tuple(int(value) for value in input_split)
            if self.input_split != (3, 1):
                raise ValueError(
                    "DualSwinAbsDiffUPerNet expects input_split=(3, 1): "
                    "RGB optical plus single-channel VV SAR.")
            self.freeze_backbones = bool(freeze_backbones)
            if self.freeze_backbones:
                self._set_backbones_trainable(False)

        def _set_backbones_trainable(self, trainable):
            for module in (self.backbone, self.sar_backbone):
                for param in module.parameters():
                    param.requires_grad = trainable
                if not trainable:
                    module.eval()

        def train(self, mode=True):
            super().train(mode)
            if self.freeze_backbones:
                self.backbone.eval()
                self.sar_backbone.eval()
            return self

        def extract_feat(self, inputs):
            """Extract RGB/VV features and fuse them by absolute difference."""
            opt_channels, sar_channels = self.input_split
            expected_channels = opt_channels + sar_channels
            if inputs.shape[1] != expected_channels:
                raise ValueError(
                    f"Expected {expected_channels} input channels, got "
                    f"{inputs.shape[1]}.")

            opt_x = inputs[:, :opt_channels, :, :]
            sar_x = inputs[:, opt_channels:, :, :]
            sar_x = sar_x.repeat(1, 3, 1, 1)

            opt_feats = self.backbone(opt_x)
            sar_feats = self.sar_backbone(sar_x)
            if len(opt_feats) != len(sar_feats):
                raise ValueError(
                    "OPT and SAR backbones must return the same number of "
                    f"feature maps, got {len(opt_feats)} and "
                    f"{len(sar_feats)}.")

            diff_feats = []
            for opt_feat, sar_feat in zip(opt_feats, sar_feats):
                if opt_feat.shape != sar_feat.shape:
                    raise ValueError(
                        "OPT and SAR feature maps must have identical shapes, "
                        f"got {tuple(opt_feat.shape)} and "
                        f"{tuple(sar_feat.shape)}.")
                diff_feats.append(torch.abs(sar_feat - opt_feat))

            diff_feats = tuple(diff_feats)
            if self.with_neck:
                return self.neck(diff_feats)
            return diff_feats


__all__ = ["DualSwinAbsDiffUPerNet"]
