"""Change detector registrations."""

from .dual_swin_absdiff_upernet import DualSwinAbsDiffUPerNet
from .shared_swin_absdiff_upernet import SharedSwinAbsDiffUPerNet

__all__ = ["DualSwinAbsDiffUPerNet", "SharedSwinAbsDiffUPerNet"]
