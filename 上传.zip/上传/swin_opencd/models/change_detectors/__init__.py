"""Change detector registrations."""

from .dual_swin_absdiff_upernet import DualSwinAbsDiffUPerNet

__all__ = ["DualSwinAbsDiffUPerNet"]
