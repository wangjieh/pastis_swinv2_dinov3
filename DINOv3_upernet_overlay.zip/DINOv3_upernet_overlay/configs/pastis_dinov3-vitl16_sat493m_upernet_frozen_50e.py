import sys
import os
from pathlib import Path

project_root = Path(__file__).resolve().parents[2]
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

custom_imports = dict(imports=['dinov3_mmseg'], allow_failed_imports=False)

default_scope = 'mmseg'

data_root = os.getenv('PASTIS_DATA_ROOT', '')
dinov3_pretrained = os.getenv('DINOV3_PRETRAINED', '')
work_dir = './work_dirs/pastis_dinov3-vitl16_sat493m_upernet_frozen_50e'

num_classes = 19
ignore_index = -1
image_size = 256
max_epochs = 50
train_batch_size = 1
val_batch_size = 1
num_workers = 2
backbone_frame_batch_size = 4
vit_channels = 1024
neck_channels = 256
norm_cfg = dict(type='GN', num_groups=32, requires_grad=True)

dataset_cfg = dict(
    type='PASTISPtDataset',
    data_root=data_root,
    image_size=image_size,
    rgb_indices=(3, 2, 1),
    ignore_index=ignore_index)

model = dict(
    type='PASTISDINOv3UPerNetSegmentor',
    data_preprocessor=dict(type='PASTISDataPreProcessor'),
    ignore_index=ignore_index,
    frozen_backbone=True,
    backbone_frame_batch_size=backbone_frame_batch_size,
    backbone=dict(
        type='DINOv3ViT',
        arch='vitl16',
        img_size=image_size,
        patch_size=16,
        in_channels=3,
        out_indices=(4, 11, 17, 23),
        norm=True,
        frozen_stages=-1,
        norm_eval=True,
        untie_global_and_local_cls_norm=True,
        init_cfg=dict(
            type='Pretrained',
            checkpoint=dinov3_pretrained,
            strict=True) if dinov3_pretrained else None),
    neck=dict(
        type='DINOv3ViTMultiScaleNeck',
        in_channels=[vit_channels] * 4,
        out_channels=neck_channels,
        scales=(4.0, 2.0, 1.0, 0.5),
        mode='bilinear',
        align_corners=False),
    decode_head=dict(
        type='UPerHead',
        in_channels=[neck_channels] * 4,
        in_index=[0, 1, 2, 3],
        pool_scales=(1, 2, 3, 6),
        channels=neck_channels,
        dropout_ratio=0.1,
        num_classes=num_classes,
        norm_cfg=norm_cfg,
        align_corners=False,
        ignore_index=ignore_index,
        loss_decode=dict(
            type='CrossEntropyLoss',
            use_sigmoid=False,
            loss_weight=1.0,
            ignore_index=ignore_index)))

train_dataloader = dict(
    batch_size=train_batch_size,
    num_workers=num_workers,
    persistent_workers=num_workers > 0,
    collate_fn=dict(type='pseudo_collate'),
    sampler=dict(type='DefaultSampler', shuffle=True),
    dataset=dict(**dataset_cfg, split='train'))

val_dataloader = dict(
    batch_size=val_batch_size,
    num_workers=num_workers,
    persistent_workers=num_workers > 0,
    collate_fn=dict(type='pseudo_collate'),
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(**dataset_cfg, split='valid'))

test_dataloader = dict(
    batch_size=val_batch_size,
    num_workers=num_workers,
    persistent_workers=num_workers > 0,
    collate_fn=dict(type='pseudo_collate'),
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(**dataset_cfg, split='test'))

val_evaluator = dict(type='IoUMetric', iou_metrics=['mIoU'], ignore_index=ignore_index)
test_evaluator = val_evaluator

optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(type='AdamW', lr=0.1, weight_decay=0.01))

param_scheduler = [
    dict(
        type='LinearLR',
        start_factor=1e-6,
        by_epoch=True,
        begin=0,
        end=5,
        convert_to_iter_based=True),
    dict(
        type='CosineAnnealingLR',
        eta_min=1e-5,
        by_epoch=True,
        begin=5,
        end=max_epochs,
        convert_to_iter_based=True)
]

train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=max_epochs, val_interval=1)
val_cfg = dict(type='ValLoop')
test_cfg = dict(type='TestLoop')

default_hooks = dict(
    timer=dict(type='IterTimerHook'),
    logger=dict(type='LoggerHook', interval=50, log_metric_by_epoch=True),
    param_scheduler=dict(type='ParamSchedulerHook'),
    checkpoint=dict(
        type='CheckpointHook',
        by_epoch=True,
        interval=1,
        save_best='mIoU',
        rule='greater',
        max_keep_ckpts=3),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    visualization=dict(type='SegVisualizationHook'))

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method='spawn', opencv_num_threads=0),
    dist_cfg=dict(backend='nccl'))

vis_backends = [dict(type='LocalVisBackend')]
visualizer = dict(type='SegLocalVisualizer', vis_backends=vis_backends, name='visualizer')
log_processor = dict(by_epoch=True)
log_level = 'INFO'
load_from = None
resume = False
