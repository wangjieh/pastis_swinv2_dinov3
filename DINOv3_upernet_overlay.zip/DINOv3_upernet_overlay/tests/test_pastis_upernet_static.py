from pathlib import Path
import unittest


PROJECT_ROOT = Path(__file__).resolve().parents[1]
MMSEG_MODELS = PROJECT_ROOT / "dinov3_mmseg" / "models"
CONFIGS = PROJECT_ROOT / "configs"


class TestPASTISUPerNetStaticConfig(unittest.TestCase):

    def test_new_model_components_are_registered(self):
        neck_path = MMSEG_MODELS / "dinov3_multiscale_neck.py"
        segmentor_path = MMSEG_MODELS / "pastis_upernet_segmentor.py"
        init_path = MMSEG_MODELS / "__init__.py"

        self.assertTrue(neck_path.is_file())
        self.assertTrue(segmentor_path.is_file())

        neck_text = neck_path.read_text(encoding="utf-8")
        segmentor_text = segmentor_path.read_text(encoding="utf-8")
        init_text = init_path.read_text(encoding="utf-8")

        self.assertIn("class DINOv3ViTMultiScaleNeck", neck_text)
        self.assertIn("class PASTISDINOv3UPerNetSegmentor", segmentor_text)
        self.assertIn("DINOv3ViTMultiScaleNeck", init_text)
        self.assertIn("PASTISDINOv3UPerNetSegmentor", init_text)

    def test_upernet_configs_keep_existing_training_strategies(self):
        frozen_path = CONFIGS / "pastis_dinov3-vitl16_sat493m_upernet_frozen_50e.py"
        finetune_path = CONFIGS / "pastis_dinov3-vitl16_sat493m_upernet_finetune_10frozen_40ft_50e.py"

        self.assertTrue(frozen_path.is_file())
        self.assertTrue(finetune_path.is_file())

        frozen_text = frozen_path.read_text(encoding="utf-8")
        finetune_text = finetune_path.read_text(encoding="utf-8")

        self.assertIn("type='PASTISDINOv3UPerNetSegmentor'", frozen_text)
        self.assertIn("type='PASTISDINOv3UPerNetSegmentor'", finetune_text)
        self.assertIn("type='DINOv3ViTMultiScaleNeck'", frozen_text)
        self.assertIn("type='DINOv3ViTMultiScaleNeck'", finetune_text)
        self.assertIn("type='UPerHead'", frozen_text)
        self.assertIn("type='UPerHead'", finetune_text)

        self.assertIn("frozen_backbone=True", frozen_text)
        self.assertIn("optimizer=dict(type='AdamW', lr=0.1", frozen_text)
        self.assertIn("type='CosineAnnealingLR'", frozen_text)

        self.assertIn("frozen_backbone=False", finetune_text)
        self.assertIn("optimizer=dict(type='AdamW', lr=1e-4", finetune_text)
        self.assertIn("type='ReduceOnPlateauLR'", finetune_text)
        self.assertIn("type='PASTISBackboneUnfreezeHook', unfreeze_epoch=10, lr_mult=0.1", finetune_text)

    def test_original_linear_probe_configs_are_unchanged(self):
        frozen_path = CONFIGS / "pastis_dinov3-vitl16_sat493m_linear-probe_frozen_50e.py"
        finetune_path = CONFIGS / "pastis_dinov3-vitl16_sat493m_linear-probe_finetune_10frozen_40ft_50e.py"

        frozen_text = frozen_path.read_text(encoding="utf-8")
        finetune_text = finetune_path.read_text(encoding="utf-8")

        self.assertIn("type='PASTISDINOv3Segmentor'", frozen_text)
        self.assertIn("type='PASTISLinearProbeHead'", frozen_text)
        self.assertIn("type='PASTISDINOv3Segmentor'", finetune_text)
        self.assertIn("type='PASTISLinearProbeHead'", finetune_text)
        self.assertNotIn("PASTISDINOv3UPerNetSegmentor", frozen_text)
        self.assertNotIn("PASTISDINOv3UPerNetSegmentor", finetune_text)


if __name__ == "__main__":
    unittest.main()
