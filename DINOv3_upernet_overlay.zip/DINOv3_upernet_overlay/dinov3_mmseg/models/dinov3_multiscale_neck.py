"""Multi-scale feature neck for DINOv3 ViT features."""

from __future__ import annotations

from typing import Sequence, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from mmengine.model import BaseModule
from mmseg.registry import MODELS


@MODELS.register_module()
class DINOv3ViTMultiScaleNeck(BaseModule):
    """Convert same-resolution ViT features into a UPerNet-style pyramid.

    DINOv3 ViT intermediate layers share the same patch-grid resolution.  This
    neck projects each level to a common channel count and resizes the levels to
    strides similar to ``[4, 8, 16, 32]`` for a ViT/16 backbone.
    """

    def __init__(
        self,
        in_channels: Union[int, Sequence[int]],
        out_channels: int = 256,
        scales: Sequence[float] = (4.0, 2.0, 1.0, 0.5),
        mode: str = 'bilinear',
        align_corners: bool = False,
        init_cfg: dict | None = None,
    ) -> None:
        super().__init__(init_cfg=init_cfg)
        if isinstance(in_channels, int):
            in_channels = [in_channels] * len(scales)
        self.in_channels = list(in_channels)
        self.out_channels = out_channels
        self.scales = tuple(float(scale) for scale in scales)
        self.mode = mode
        self.align_corners = align_corners

        if len(self.in_channels) != len(self.scales):
            raise ValueError(
                'in_channels and scales must have the same length, got '
                f'{len(self.in_channels)} and {len(self.scales)}.')
        if any(scale <= 0 for scale in self.scales):
            raise ValueError(f'scales must be positive, got {self.scales}.')

        self.projections = nn.ModuleList(
            nn.Conv2d(in_channel, out_channels, kernel_size=1)
            for in_channel in self.in_channels)

    def forward(self, inputs):
        if isinstance(inputs, torch.Tensor):
            inputs = (inputs, )
        if len(inputs) != len(self.projections):
            raise ValueError(
                f'Expected {len(self.projections)} input features, '
                f'got {len(inputs)}.')

        outputs = []
        for feature, projection, scale in zip(
                inputs, self.projections, self.scales):
            output = projection(feature)
            if scale != 1.0:
                if self.mode in ('linear', 'bilinear', 'bicubic', 'trilinear'):
                    output = F.interpolate(
                        output,
                        scale_factor=scale,
                        mode=self.mode,
                        align_corners=self.align_corners)
                else:
                    output = F.interpolate(
                        output,
                        scale_factor=scale,
                        mode=self.mode)
            outputs.append(output)
        return tuple(outputs)
