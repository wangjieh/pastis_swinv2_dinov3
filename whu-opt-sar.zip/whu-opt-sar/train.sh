#! /usr/bin/bash

function get_parent() {
    local n=$1
    local dir=$(pwd)
    while [ "$n" -gt 0 ]; do
        dir=$(dirname "$dir")
        n=$((n - 1))
    done
    echo "$dir"
}

cd "$(dirname "${BASH_SOURCE[0]}")" && pwd > /dev/null

# export MM_WORK_DIR_HOME="$(get_parent 7)"
export MM_WORK_DIR_HOME="/mnt/htzzb2/EO_test"

# 自动读取归档目录绝对路径，非必要不修改。  
export MM_ARCHIVE_HOME="$(get_parent 6)"

# 自动读取归档数据目录路径，非必要不修改。
export MM_ARCHIVE_DATA_HOME="$MM_ARCHIVE_HOME/dat"

# 自动读取归档预训练骨干网络权重目录路径，非必要不修改。
export MM_ARCHIVE_CKPT_HOME="$MM_ARCHIVE_HOME/pretrained"

# 启动配置名称。
export CONFIG_NAME="${1:-"whu-opt-sar_dinov3-swin_upernet_e50-finetune_lr1e4"}"

# 指定使用的 GPU 索引，格式：0, 1, 2..., N。
export CUDA_VISIBLE_DEVICES="${2:-0}"

# Miniconda3 虚拟环境名称，确保此环境可以正常运行你的项目。
export CONDA_ENV_NAME="${3:-"mmdinov3-cd"}"

TRAIN_MODE="${4:-"single"}"

IFS=',' read -ra GPU_ARRAY <<< "$CUDA_VISIBLE_DEVICES"
NUM_GPUS=${#GPU_ARRAY[@]}


SRCDIR=$PWD
cd "$(get_parent 3)"
export PYTHONPATH=".":"$PYTHONPATH"
WORK_DIR="${MM_WORK_DIR_HOME}/openmmlab_work_dirs/mmseg/$(basename "${SRCDIR}")/${CONFIG_NAME}"
mkdir -p "$WORK_DIR"


if [ "$NUM_GPUS" -le 1 ]; then
    conda run -n "$CONDA_ENV_NAME" \
        --no-capture-output \
        python3 \
        "$PWD/tools/train.py" \
        "$SRCDIR/configs/$CONFIG_NAME.py" \
        --work-dir "$WORK_DIR"
else
    conda run -n "$CONDA_ENV_NAME" \
        --no-capture-output \
        python3 -m torch.distributed.run \
        --nproc-per-node="auto" \
        --master-port=29500 \
        "$PWD/tools/train.py" \
        "$SRCDIR/configs/$CONFIG_NAME.py" \
        --work-dir "$WORK_DIR"
fi