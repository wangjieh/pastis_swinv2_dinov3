import os


_base_ = ["./whu-opt-sar.py"]

num_classes = 8
ignore_index = num_classes
crop_size = 256
patch_size = 4
swin_huge_channels = [704, 1408, 2816, 5632]
auxiliary_in_index = 2

# Accept either an extracted pure backbone state_dict or the merged DINOv3
# distillation checkpoint. The wrapper prefers model_ema.backbone weights.
swin_huge_checkpoint = os.path.join(os.environ.get('MM_ARCHIVE_CKPT_HOME'), 'swin-distill', '30999', 'swintransformer-huge.pt')

data_preprocessor = dict(
    type="SegDataPreProcessor",
    pad_val=0,
    seg_pad_val=ignore_index,
    size_divisor=32,
    test_cfg=dict(size_divisor=32)
)
norm_cfg = dict(type="SyncBN", requires_grad=True)
model = dict(
    type="EncoderDecoder",
    data_preprocessor=data_preprocessor,
    backbone=dict(
        type="DINOv3DistilledMultiSwinHuge",
        checkpoint=swin_huge_checkpoint,
        img_size=crop_size,
        modality_in_chans=[4, 1],
        patch_size=patch_size,
        window_size=8,
        out_indices=(0, 1, 2, 3),
        use_ema=True,
        frozen=True,
        freeze_entry_layer=False
    ),
    decode_head=dict(
        type="UPerHead",
        in_channels=swin_huge_channels,
        in_index=[0, 1, 2, 3],
        pool_scales=(1, 2, 3, 6),
        channels=512,
        dropout_ratio=0.1,
        num_classes=num_classes,
        ignore_index=ignore_index,
        align_corners=False,
        loss_decode=dict(
            type="CrossEntropyLoss",
            use_sigmoid=False,
            loss_weight=1.0,
        ),
        norm_cfg=norm_cfg
    ),
    auxiliary_head=dict(
        type="FCNHead",
        in_channels=swin_huge_channels[auxiliary_in_index],
        in_index=auxiliary_in_index,
        channels=512,
        num_convs=1,
        concat_input=False,
        dropout_ratio=0.1,
        num_classes=num_classes,
        ignore_index=ignore_index,
        align_corners=False,
        loss_decode=dict(
            type="CrossEntropyLoss",
            use_sigmoid=False,
            loss_weight=0.4,
        ),
        norm_cfg=norm_cfg
    ),
    test_cfg=dict(
        mode="slide",
        crop_size=(crop_size, crop_size),
        stride=(crop_size//2, crop_size//2)
    ),
    train_cfg=dict()
)

optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(
        type='AdamW',
        lr=1e-4,
        weight_decay=0.05),
    paramwise_cfg=dict(
        custom_keys={
            "backbone": dict(lr_mult=0.1, decay_mult=1.0)
        }
    ),
    clip_grad=dict(max_norm=35, norm_type=2))

param_scheduler = [
    dict(
        type='LinearLR',
        start_factor=1.0/3,
        by_epoch=True,
        begin=0,
        end=5),
    dict(
        type='MultiStepLR',
        begin=5,
        end=50,
        by_epoch=True,
        milestones=[60, 80],
        gamma=0.1)
]

train_cfg = dict(type="EpochBasedTrainLoop", max_epochs=50, val_interval=10)
val_cfg = dict(type="ValLoop")
test_cfg = dict(type="TestLoop")

default_hooks = dict(
    timer=dict(type="IterTimerHook"),
    logger=dict(type="LoggerHook", interval=50, log_metric_by_epoch=True),
    param_scheduler=dict(type="ParamSchedulerHook"),
    checkpoint=dict(
        type="CheckpointHook",
        by_epoch=True,
        interval=10,
        save_best="mIoU",
        rule="greater",
        max_keep_ckpts=3,
    ),
    sampler_seed=dict(type="DistSamplerSeedHook"),
    visualization=dict(type="OlmoEarthVisualizationHook"),
)

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method="fork", opencv_num_threads=0),
    dist_cfg=dict(backend="nccl"),
)

default_scope = "mmseg"
log_level = "INFO"
load_from = None
resume = False
auto_scale_lr = dict(enable=False, base_batch_size=4)
