import os


DATA_ROOT = os.path.join(os.environ.get('MM_ARCHIVE_DATA_HOME'), 'whu-opt-sar')

DATASET_TYPE = 'WHUOptSarDataset'

BANDS_MEAN = [
    104.69532538001903,
    96.718274418357340,
    79.112120969108160,
    100.77730656775370,
    54.002214388130120
]
BANDS_STD = [
    25.108956545480750,
    27.273439719781422,
    29.714041537672948,
    32.046266513918674,
    48.704276788725470
]

num_classes = 8
ignore_index = num_classes
crop_size = 256
batch_size = 4

custom_imports = dict(
    imports=[
        "projects.dinov3.whu-opt-sar.dinov3",
        "projects.olmoearth.m-cashew-plant.olmoearth"
    ],
    allow_failed_imports=False
)

train_pipeline = [
    dict(type="LoadOptSarImgFromTIF"),
    dict(type="LoadOptSarAnnFromTIF"),
    dict(type="NormalizeMultibandImage", mean=BANDS_MEAN, std=BANDS_STD),
    dict(
        type="RandomCrop",
        crop_size=(crop_size, crop_size),
        cat_max_ratio=0.75,
    ),
    dict(
        type="RandomRotate",
        prob=0.5,
        degree=90,
        pad_val=0,
        seg_pad_val=ignore_index,
    ),
    dict(type="RandomFlip", prob=0.5, direction=['horizontal', 'vertical']),
    dict(type="PackSegInputs")
]

test_pipeline = [
    dict(type="LoadOptSarImgFromTIF"),
    dict(type="LoadOptSarAnnFromTIF"),
    dict(type="NormalizeMultibandImage", mean=BANDS_MEAN, std=BANDS_STD),
    dict(type="PackSegInputs")
]

train_dataloader = dict(
    batch_size=batch_size,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=True),
    dataset=dict(
        type=DATASET_TYPE,
        data_root=os.path.join(DATA_ROOT, 'train_128'),
        opt_dir='opt',
        sar_dir='sar',
        lbl_dir='lbl',
        test_mode=False,
        pipeline=train_pipeline,
        reduce_zero_label=False
    ),
)

val_dataloader = dict(
    batch_size=batch_size,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=DATASET_TYPE,
        data_root=os.path.join(DATA_ROOT, 'val_128'),
        opt_dir='opt',
        sar_dir='sar',
        lbl_dir='lbl',
        test_mode=True,
        pipeline=test_pipeline,
        reduce_zero_label=False
    ),
)
test_dataloader = val_dataloader

val_evaluator = dict(
    type="OlmoEarthIoUMetric",
    num_classes=num_classes,
    use_valid_mask=False,
)
test_evaluator = val_evaluator
