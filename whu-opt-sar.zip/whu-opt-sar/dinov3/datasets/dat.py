import os

from mmseg.datasets import BaseSegDataset
from mmseg.registry import DATASETS


@DATASETS.register_module(force=True)
class WHUOptSarDataset(BaseSegDataset):
    METAINFO = {
        'classes': [
            'background',
            'farmland',
            'city',
            'village',
            'water',
            'forest',
            'road',
            'others'
        ],
        'palette': [
            [0, 0, 0], 
            [128, 0, 0], 
            [0, 128, 0], 
            [128, 128, 0],
            [0, 0, 128], 
            [128, 0, 128], 
            [0, 128, 128], 
            [128, 128, 128]
        ]
    }

    def __init__(self, data_root, opt_dir='opt', sar_dir='sar', lbl_dir='lbl', **kwargs):
        self.opt_dir = opt_dir
        self.sar_dir = sar_dir
        self.lbl_dir = lbl_dir
        super().__init__(data_root=data_root, **kwargs)

    def load_data_list(self):
        opt_root = os.path.join(self.data_root, self.opt_dir)
        sar_root = os.path.join(self.data_root, self.sar_dir)
        lbl_root = os.path.join(self.data_root, self.lbl_dir) if self.lbl_dir else ''
        data_list = []
        for filename in os.listdir(opt_root):
            data_info = dict(
                label_map=self.label_map,
                opt_path=os.path.join(opt_root, filename),
                sar_path=os.path.join(sar_root, filename),
                reduce_zero_label=self.reduce_zero_label,
                seg_map_path=os.path.join(lbl_root, filename) if lbl_root else '',
                seg_fields=[]
            )
            data_list.append(data_info)
        return data_list
