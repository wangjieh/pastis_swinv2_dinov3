import rasterio
import numpy as np
from mmcv.transforms import BaseTransform
from mmseg.registry import TRANSFORMS


@TRANSFORMS.register_module()
class NormalizeMultibandImage(BaseTransform):
    """Normalize a multi-band image before geometric augmentation."""

    def __init__(self, mean, std, bands=None):
        self.mean = np.array(mean, dtype=np.float32).reshape(1, 1, -1)
        self.std = np.array(std, dtype=np.float32).reshape(1, 1, -1)
        self.bands = bands

    def transform(self, results):
        img = results['img']
        if self.bands and img.shape[-1] > 12:
            img = img[..., self.bands]
        results['img'] = (img.astype(np.float32) - self.mean) / self.std
        return results
    

@TRANSFORMS.register_module(force=True)
class LoadOptSarImgFromTIF(BaseTransform):
    def transform(self, results):
        with rasterio.open(results['opt_path']) as f:
            opt = f.read()
        with rasterio.open(results['sar_path']) as f:
            sar = f.read()
        img = np.vstack([opt, sar])
        if img.ndim == 3:
            img = np.moveaxis(img, 0, 2)
        results['img'] = img
        results['img_shape'] = img.shape[: 2]
        results['ori_shape'] = img.shape[: 2]
        return results


@TRANSFORMS.register_module(force=True)
class LoadOptSarAnnFromTIF(BaseTransform):
    def transform(self, results):
        if 'seg_map_path' not in results:
            raise
        with rasterio.open(results['seg_map_path']) as f:
            gt_semantic_seg = f.read()
        if gt_semantic_seg.ndim > 2:
            gt_semantic_seg = gt_semantic_seg[0]
        ori_dtype = gt_semantic_seg.dtype
        gt_semantic_seg = np.asarray(gt_semantic_seg/10, dtype=ori_dtype)
        if results['reduce_zero_label']:
            # avoid using underflow conversion
            gt_semantic_seg[gt_semantic_seg == 0] = 255
            gt_semantic_seg = gt_semantic_seg - 1
            gt_semantic_seg[gt_semantic_seg == 254] = 255
        # modify if custom classes
        if results.get('label_map', None) is not None:
            # Add deep copy to solve bug of repeatedly
            # replace `gt_semantic_seg`, which is reported in
            # https://github.com/open-mmlab/mmsegmentation/pull/1445/
            gt_semantic_seg_copy = gt_semantic_seg.copy()
            for old_id, new_id in results['label_map'].items():
                gt_semantic_seg[gt_semantic_seg_copy == old_id] = new_id
        results['gt_seg_map'] = gt_semantic_seg
        results['seg_fields'].append('gt_seg_map')
        return results
