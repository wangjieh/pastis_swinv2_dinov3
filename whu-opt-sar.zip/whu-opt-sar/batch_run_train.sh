#! /usr/bin/bash

cd "$(dirname "${BASH_SOURCE[0]}")" && pwd > /dev/null

CONDA_ENV="mmdinov3-cd"

GPUS='0,1'

configfiles=(
    "whu-opt-sar_dinov3-swin_upernet_e50-finetune_lr1e4"
    # "whu-opt-sar_dinov3-swin_upernet_e50-frozen_lr1e4"
)

for configfile in "${configfiles[@]}"; do
    bash "./train.sh" "$configfile" "$GPUS" "$CONDA_ENV"
done