import torch

from dinov3 import WHUOptSarDataset
from dinov3 import LoadOptSarImgFromTIF
from dinov3 import LoadOptSarAnnFromTIF
from dinov3 import DINOv3DistilledMultiSwinHuge


if '__main__' == __name__:
    # dataset = WHUOptSarDataset(data_root='/mnt/ht2-nas2/EO_test/openmmlab-archive/dat/whu-opt-sar/train_128')
    # transform1 = LoadOptSarImgFromTIF()
    # transform2 = LoadOptSarAnnFromTIF()
    # for i in range(len(dataset)):
    #     results = dataset.prepare_data(i)
    #     results = transform1(results)
    #     results = transform2(results)
    #     print(results['gt_seg_map'])

    model = DINOv3DistilledMultiSwinHuge(
        img_size=256,
        checkpoint='/mnt/ht2-nas2/EO_test/openmmlab-archive/pretrained/swin-distill/30999/swintransformer-huge.pt'
    )
    model.init_weights()
    model.train()
    model.to(device=0)

    x = torch.rand((4, 5, 256, 256), device=0)
    for i, out in enumerate(model(x)):
        print(i, out.shape)