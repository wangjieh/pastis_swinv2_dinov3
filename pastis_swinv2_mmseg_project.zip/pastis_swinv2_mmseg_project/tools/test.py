import argparse

from mmengine.config import Config, DictAction
from mmengine.runner import Runner
from mmseg.utils import register_all_modules

import pastis_mmseg  # noqa: F401


def parse_args():
    parser = argparse.ArgumentParser(description='Test PASTIS SwinV2 MMSeg model')
    parser.add_argument('config', help='Path to config file')
    parser.add_argument('checkpoint', help='Path to checkpoint')
    parser.add_argument(
        '--launcher',
        choices=['none', 'pytorch', 'slurm', 'mpi'],
        default='none',
        help='Job launcher')
    parser.add_argument(
        '--cfg-options',
        nargs='+',
        action=DictAction,
        help='Override config options')
    return parser.parse_args()


def main():
    args = parse_args()
    register_all_modules(init_default_scope=True)

    cfg = Config.fromfile(args.config)
    cfg.launcher = args.launcher
    cfg.load_from = args.checkpoint
    if args.cfg_options is not None:
        cfg.merge_from_dict(args.cfg_options)

    runner = Runner.from_cfg(cfg)
    runner.test()


if __name__ == '__main__':
    main()
