import argparse
import os
import os.path as osp
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from mmseg.apis import init_model
from mmseg.structures import SegDataSample

import pastis_mmseg  # noqa: F401


PALETTE = [
    [(37 * i + 17) % 256, (67 * i + 29) % 256, (97 * i + 43) % 256]
    for i in range(19)
]


def parse_args():
    parser = argparse.ArgumentParser(description='Infer PASTIS .pt image(s)')
    parser.add_argument('config', help='Path to config')
    parser.add_argument('checkpoint', help='Path to checkpoint')
    parser.add_argument('input', help='A .pt file or a directory containing .pt files')
    parser.add_argument('--out-dir', default='outputs/infer', help='Output directory')
    parser.add_argument('--device', default='cuda:0', help='Device, e.g. cuda:0 or cpu')
    return parser.parse_args()


def numeric_key(path: Path):
    try:
        return int(path.stem)
    except ValueError:
        return path.stem


def collect_inputs(input_path: str):
    path = Path(input_path)
    if path.is_file():
        return [path]
    if path.is_dir():
        return sorted([p for p in path.iterdir() if p.suffix == '.pt'], key=numeric_key)
    raise FileNotFoundError(input_path)


def save_palette_png(pred: np.ndarray, out_path: str):
    h, w = pred.shape
    rgb = np.zeros((h, w, 3), dtype=np.uint8)
    for label, color in enumerate(PALETTE):
        rgb[pred == label] = np.array(color, dtype=np.uint8)
    Image.fromarray(rgb).save(out_path)


def load_image(path: Path) -> torch.Tensor:
    obj = torch.load(str(path), map_location='cpu')
    if isinstance(obj, dict):
        for key in ('image', 'img', 's2', 's2_image', 'data', 'x'):
            if key in obj:
                obj = obj[key]
                break
    if isinstance(obj, np.ndarray):
        obj = torch.from_numpy(obj)
    if not torch.is_tensor(obj):
        raise TypeError(f'{path} must contain Tensor or ndarray, got {type(obj)}')
    if obj.ndim != 4:
        raise ValueError(f'{path} must be [T, C, H, W], got {tuple(obj.shape)}')
    return obj.float().contiguous()


@torch.no_grad()
def infer_one(model, img: torch.Tensor, img_path: str):
    _, _, h, w = img.shape
    data_sample = SegDataSample()
    data_sample.set_metainfo(
        dict(
            img_path=img_path,
            ori_shape=(h, w),
            img_shape=(h, w),
            pad_shape=(h, w),
            scale_factor=1.0,
        ))
    data = dict(inputs=[img], data_samples=[data_sample])
    result = model.test_step(data)[0]
    pred = result.pred_sem_seg.data.squeeze(0).cpu().numpy().astype(np.uint8)
    return pred


def main():
    args = parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    model = init_model(args.config, args.checkpoint, device=args.device)
    model.eval()

    files = collect_inputs(args.input)
    if len(files) == 0:
        raise RuntimeError(f'No .pt files found in {args.input}')

    for file in files:
        img = load_image(file)
        pred = infer_one(model, img, str(file))

        stem = file.stem
        pt_path = osp.join(args.out_dir, f'{stem}_pred.pt')
        png_path = osp.join(args.out_dir, f'{stem}_pred.png')

        torch.save(torch.from_numpy(pred), pt_path)
        save_palette_png(pred, png_path)
        print(f'Saved: {pt_path} and {png_path}')


if __name__ == '__main__':
    main()
