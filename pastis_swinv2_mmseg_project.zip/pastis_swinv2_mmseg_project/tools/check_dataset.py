import argparse
from pathlib import Path

import torch


def parse_args():
    parser = argparse.ArgumentParser(description='Quick PASTIS .pt dataset checker')
    parser.add_argument('--data-root', required=True)
    parser.add_argument('--split', default='pastis_r_train')
    parser.add_argument('--index', type=int, default=0)
    return parser.parse_args()


def main():
    args = parse_args()
    root = Path(args.data_root) / args.split
    img_path = root / 's2_images' / f'{args.index}.pt'
    target_path = root / 'targets.pt'

    img = torch.load(img_path, map_location='cpu')
    if isinstance(img, dict):
        for key in ('image', 'img', 's2', 's2_image', 'data', 'x'):
            if key in img:
                img = img[key]
                break

    targets = torch.load(target_path, map_location='cpu')
    y = targets[args.index]

    print('image path:', img_path)
    print('image shape:', tuple(img.shape), 'dtype:', img.dtype)
    print('target path:', target_path)
    print('targets shape:', tuple(targets.shape), 'dtype:', targets.dtype)
    print('sample target shape:', tuple(y.shape))
    print('target unique min/max:', int(torch.min(y)), int(torch.max(y)))
    print('target unique values:', torch.unique(y).tolist())


if __name__ == '__main__':
    main()
