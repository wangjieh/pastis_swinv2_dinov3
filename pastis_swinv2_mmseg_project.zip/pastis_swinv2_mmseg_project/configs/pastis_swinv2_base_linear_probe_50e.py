import os

custom_imports = dict(imports=['pastis_mmseg'], allow_failed_imports=False)
default_scope = 'mmseg'

# -------------------------
# User-switchable variables
# -------------------------
data_root = os.getenv('PASTIS_DATA_ROOT', 'data/pastis_dataset')
swinv2_size = os.getenv('SWINV2_SIZE', 'base').lower()
hf_model_name_or_path = os.getenv(
    'SWINV2_PATH',
    'pretrained/swinv2-base-patch4-window8-256',
)

_default_embed_dims = dict(tiny=96, small=96, base=128, large=192)
if swinv2_size not in _default_embed_dims:
    raise ValueError(
        f'Unsupported SWINV2_SIZE={swinv2_size}. '
        f'Choose from {list(_default_embed_dims)} or set SWINV2_EMBED_DIMS.')

embed_dims = int(os.getenv('SWINV2_EMBED_DIMS',
                           str(_default_embed_dims[swinv2_size])))
stage_channels = [embed_dims, embed_dims * 2, embed_dims * 4, embed_dims * 8]

num_classes = 19
ignore_index = -1
max_epochs = 50
freeze_epochs = 10  # first 20% of 50 epochs

# If your .pt images are already normalized, keep identity mean/std.
data_preprocessor = dict(
    type='PastisSegDataPreProcessor',
    mean=[0.0] * 13,
    std=[1.0] * 13,
    seg_pad_val=ignore_index,
)

model = dict(
    type='EncoderDecoder',
    data_preprocessor=data_preprocessor,
    backbone=dict(
        type='HFSwinV2TemporalBackbone',
        hf_model_name_or_path=hf_model_name_or_path,
        num_channels=13,
        image_size=128,
        out_indices=(0, 1, 2, 3),
        pretrained=True,
        ignore_mismatched_sizes=True,
        temporal_fusion='attention',
        expected_embed_dim=embed_dims,
        gradient_checkpointing=False,
    ),
    decode_head=dict(
        type='LinearProbeHead',
        in_channels=stage_channels,
        in_index=(0, 1, 2, 3),
        channels=sum(stage_channels),
        dropout_ratio=0.0,
        num_classes=num_classes,
        align_corners=False,
        ignore_index=ignore_index,
        loss_decode=dict(
            type='CrossEntropyLoss',
            use_sigmoid=False,
            loss_weight=1.0,
        ),
    ),
    train_cfg=dict(),
    test_cfg=dict(mode='whole'),
)

train_pipeline = [
    dict(type='LoadPastisPtFromFile', to_float32=True, verify_shape=True),
    dict(type='PastisRandomFlip', prob=0.5, direction='horizontal'),
    dict(type='PastisRandomFlip', prob=0.5, direction='vertical'),
    dict(type='PackPastisSegInputs'),
]

test_pipeline = [
    dict(type='LoadPastisPtFromFile', to_float32=True, verify_shape=True),
    dict(type='PackPastisSegInputs'),
]

train_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=True),
    collate_fn=dict(type='pseudo_collate'),
    dataset=dict(
        type='PASTISPtDataset',
        data_root=data_root,
        split='pastis_r_train',
        pipeline=train_pipeline,
        expected_time_steps=12,
        expected_channels=13,
        expected_size=128,
    ),
)

val_dataloader = dict(
    batch_size=1,
    num_workers=2,
    persistent_workers=False,
    sampler=dict(type='DefaultSampler', shuffle=False),
    collate_fn=dict(type='pseudo_collate'),
    dataset=dict(
        type='PASTISPtDataset',
        data_root=data_root,
        split='pastis_r_val',
        pipeline=test_pipeline,
        test_mode=True,
        expected_time_steps=12,
        expected_channels=13,
        expected_size=128,
    ),
)

test_dataloader = dict(
    batch_size=1,
    num_workers=2,
    persistent_workers=False,
    sampler=dict(type='DefaultSampler', shuffle=False),
    collate_fn=dict(type='pseudo_collate'),
    dataset=dict(
        type='PASTISPtDataset',
        data_root=data_root,
        split='pastis_r_test',
        pipeline=test_pipeline,
        test_mode=True,
        expected_time_steps=12,
        expected_channels=13,
        expected_size=128,
    ),
)

val_evaluator = dict(
    type='IoUMetric',
    iou_metrics=['mIoU'],
    ignore_index=ignore_index,
)

test_evaluator = val_evaluator

optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(
        type='AdamW',
        lr=6e-5,
        betas=(0.9, 0.999),
        weight_decay=0.01,
    ),
    clip_grad=dict(max_norm=1.0, norm_type=2),
)

param_scheduler = [
    dict(
        type='LinearLR',
        start_factor=1e-3,
        by_epoch=True,
        begin=0,
        end=5,
    ),
    dict(
        type='CosineAnnealingLR',
        by_epoch=True,
        begin=5,
        end=max_epochs,
        T_max=max_epochs - 5,
        eta_min=1e-6,
    ),
]

train_cfg = dict(
    type='EpochBasedTrainLoop',
    max_epochs=max_epochs,
    val_interval=1,
)
val_cfg = dict(type='ValLoop')
test_cfg = dict(type='TestLoop')

custom_hooks = [
    # Default: freeze only HuggingFace SwinV2 spatial encoder.
    # Temporal fusion and decode head remain trainable.
    dict(
        type='FreezeBackboneByEpochHook',
        freeze_epochs=freeze_epochs,
        target='spatial_encoder',
        verbose=True,
    )
]

default_hooks = dict(
    timer=dict(type='IterTimerHook'),
    logger=dict(type='LoggerHook', interval=20, log_metric_by_epoch=True),
    param_scheduler=dict(type='ParamSchedulerHook'),
    checkpoint=dict(
        type='CheckpointHook',
        by_epoch=True,
        interval=5,
        save_best='mIoU',
        rule='greater',
        max_keep_ckpts=3,
    ),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    visualization=dict(type='SegVisualizationHook', draw=False, interval=50),
)

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0),
    dist_cfg=dict(backend='nccl'),
)

vis_backends = [dict(type='LocalVisBackend')]
visualizer = dict(
    type='SegLocalVisualizer',
    vis_backends=vis_backends,
    name='visualizer',
)

log_processor = dict(by_epoch=True)
log_level = 'INFO'
load_from = None
resume = False
work_dir = './work_dirs/pastis_swinv2_base_linear_probe_50e'

randomness = dict(seed=42, deterministic=False)
