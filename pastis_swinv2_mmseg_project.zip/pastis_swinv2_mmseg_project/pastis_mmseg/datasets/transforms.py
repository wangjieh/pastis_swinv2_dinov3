import os.path as osp
from typing import Dict, Optional

import numpy as np
import torch
from mmengine.structures import PixelData
from mmseg.registry import TRANSFORMS
from mmseg.structures import SegDataSample


@TRANSFORMS.register_module()
class LoadPastisPtFromFile:
    """Load one PASTIS `.pt` sample and its target from `targets.pt`.

    Image shape: [T, C, H, W], default [12, 13, 128, 128].
    Label shape: [H, W], labels 0-18, ignore -1.
    """

    _targets_cache = {}

    def __init__(
        self,
        to_float32: bool = True,
        verify_shape: bool = True,
        cache_targets: bool = True,
    ) -> None:
        self.to_float32 = to_float32
        self.verify_shape = verify_shape
        self.cache_targets = cache_targets

    def _load_tensor(self, path: str):
        obj = torch.load(path, map_location='cpu')
        if isinstance(obj, dict):
            # Be tolerant to common keys.
            for key in ('image', 'img', 's2', 's2_image', 'data', 'x'):
                if key in obj:
                    obj = obj[key]
                    break
        if isinstance(obj, np.ndarray):
            obj = torch.from_numpy(obj)
        if not torch.is_tensor(obj):
            raise TypeError(f'{path} must contain a Tensor or ndarray, got {type(obj)}')
        return obj

    def _load_targets(self, gt_path: str):
        if self.cache_targets and gt_path in self._targets_cache:
            return self._targets_cache[gt_path]

        targets = torch.load(gt_path, map_location='cpu')
        if isinstance(targets, np.ndarray):
            targets = torch.from_numpy(targets)
        if not torch.is_tensor(targets):
            raise TypeError(
                f'{gt_path} must contain a Tensor or ndarray, got {type(targets)}')
        if targets.ndim != 3:
            raise ValueError(
                f'{gt_path} must have shape [N, H, W], got {tuple(targets.shape)}')

        if self.cache_targets:
            self._targets_cache[gt_path] = targets
        return targets

    def __call__(self, results: Dict) -> Dict:
        img_path = results['img_path']
        gt_path = results['gt_path']
        target_index = int(results['target_index'])

        img = self._load_tensor(img_path)
        if self.to_float32:
            img = img.float()

        if img.ndim != 4:
            raise ValueError(
                f'Image must have shape [T, C, H, W], got {tuple(img.shape)} at {img_path}')

        expected_t = results.get('expected_time_steps', None)
        expected_c = results.get('expected_channels', None)
        expected_size = results.get('expected_size', None)

        t, c, h, w = img.shape
        if self.verify_shape:
            if expected_t is not None and t != expected_t:
                raise ValueError(f'Expected T={expected_t}, got T={t} at {img_path}')
            if expected_c is not None and c != expected_c:
                raise ValueError(f'Expected C={expected_c}, got C={c} at {img_path}')
            if expected_size is not None and (h != expected_size or w != expected_size):
                raise ValueError(
                    f'Expected H=W={expected_size}, got H={h}, W={w} at {img_path}')

        targets = self._load_targets(gt_path)
        gt = targets[target_index].long()
        if gt.ndim != 2:
            raise ValueError(
                f'Label must have shape [H, W], got {tuple(gt.shape)} for index {target_index}')
        if gt.shape[-2:] != img.shape[-2:]:
            raise ValueError(
                f'Image/label spatial mismatch: image {tuple(img.shape[-2:])}, '
                f'label {tuple(gt.shape[-2:])}, index {target_index}')

        results['img'] = img.contiguous()
        results['gt_seg_map'] = gt.contiguous()
        results['img_shape'] = (h, w)
        results['ori_shape'] = (h, w)
        results['pad_shape'] = (h, w)
        results['scale_factor'] = 1.0
        results['seg_fields'] = ['gt_seg_map']
        return results


@TRANSFORMS.register_module()
class PastisRandomFlip:
    """Random spatial flip for [T, C, H, W] image and [H, W] mask."""

    def __init__(self, prob: float = 0.5, direction: str = 'horizontal') -> None:
        if direction not in ('horizontal', 'vertical'):
            raise ValueError('direction must be "horizontal" or "vertical"')
        self.prob = prob
        self.direction = direction

    def __call__(self, results: Dict) -> Dict:
        if np.random.rand() >= self.prob:
            results['flip'] = False
            results['flip_direction'] = None
            return results

        img = results['img']
        gt = results['gt_seg_map']
        if self.direction == 'horizontal':
            img = torch.flip(img, dims=(-1,))
            gt = torch.flip(gt, dims=(-1,))
        else:
            img = torch.flip(img, dims=(-2,))
            gt = torch.flip(gt, dims=(-2,))

        results['img'] = img.contiguous()
        results['gt_seg_map'] = gt.contiguous()
        results['flip'] = True
        results['flip_direction'] = self.direction
        return results


@TRANSFORMS.register_module()
class PackPastisSegInputs:
    """Pack PASTIS tensors into MMSeg-style `inputs` and `SegDataSample`."""

    def __init__(self, meta_keys: Optional[tuple] = None) -> None:
        if meta_keys is None:
            meta_keys = (
                'img_path', 'seg_map_path', 'img_id', 'ori_shape', 'img_shape',
                'pad_shape', 'scale_factor', 'flip', 'flip_direction')
        self.meta_keys = meta_keys

    def __call__(self, results: Dict) -> Dict:
        img = results['img']
        gt = results['gt_seg_map']

        if not torch.is_tensor(img):
            img = torch.as_tensor(img)
        if not torch.is_tensor(gt):
            gt = torch.as_tensor(gt)

        img = img.contiguous()
        gt = gt.long().contiguous()

        data_sample = SegDataSample()
        data_sample.gt_sem_seg = PixelData(data=gt.unsqueeze(0))

        metainfo = {}
        for key in self.meta_keys:
            if key in results:
                metainfo[key] = results[key]
        data_sample.set_metainfo(metainfo)

        return dict(inputs=img, data_samples=data_sample)
