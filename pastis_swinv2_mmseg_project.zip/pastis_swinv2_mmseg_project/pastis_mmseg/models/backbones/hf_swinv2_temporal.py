from typing import List, Sequence, Tuple

import torch
import torch.nn as nn
from mmengine.model import BaseModule
from mmseg.registry import MODELS


class TemporalAttentionFusion(nn.Module):
    """Temporal attention pooling for one feature scale.

    Input:  [B, T, C, H, W]
    Output: [B, C, H, W]
    """

    def __init__(self, channels: int, hidden_ratio: float = 0.25) -> None:
        super().__init__()
        hidden = max(16, int(channels * hidden_ratio))
        self.score = nn.Sequential(
            nn.LayerNorm(channels),
            nn.Linear(channels, hidden),
            nn.GELU(),
            nn.Linear(hidden, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim != 5:
            raise ValueError(f'Expected [B, T, C, H, W], got {tuple(x.shape)}')
        context = x.mean(dim=(-2, -1))              # [B, T, C]
        weights = self.score(context)              # [B, T, 1]
        weights = torch.softmax(weights, dim=1)
        weights = weights[..., None, None]         # [B, T, 1, 1, 1]
        return (x * weights).sum(dim=1)


class TemporalMeanFusion(nn.Module):
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x.mean(dim=1)


class TemporalMaxFusion(nn.Module):
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x.max(dim=1).values


@MODELS.register_module()
class HFSwinV2TemporalBackbone(BaseModule):
    """HuggingFace SwinV2 spatial encoder + multi-scale temporal fusion.

    This backbone accepts [B, T, C, H, W].
    It flattens B*T, feeds each timestamp to HF `Swinv2Model`,
    reshapes every scale back to [B, T, C_i, H_i, W_i],
    then fuses along the temporal dimension.

    Args:
        hf_model_name_or_path: local HF model directory.
        num_channels: input channels, default 13.
        image_size: input image size, default 128.
        out_indices: output Swin stages.
        pretrained: load HF pretrained weights.
        ignore_mismatched_sizes: useful when loading 3-channel weights into 13-channel input.
        temporal_fusion: "attention", "mean", or "max".
        expected_embed_dim: optional config sanity check.
        gradient_checkpointing: enable HF gradient checkpointing to save memory.
    """

    def __init__(
        self,
        hf_model_name_or_path: str,
        num_channels: int = 13,
        image_size: int = 128,
        out_indices: Sequence[int] = (0, 1, 2, 3),
        pretrained: bool = True,
        ignore_mismatched_sizes: bool = True,
        temporal_fusion: str = 'attention',
        expected_embed_dim: int = None,
        gradient_checkpointing: bool = False,
        init_cfg=None,
    ) -> None:
        super().__init__(init_cfg=init_cfg)

        try:
            from transformers import Swinv2Config, Swinv2Model
        except ImportError as exc:
            raise ImportError(
                'HFSwinV2TemporalBackbone requires transformers. '
                'Install it with: pip install transformers safetensors'
            ) from exc

        self.hf_model_name_or_path = hf_model_name_or_path
        self.num_channels = num_channels
        self.image_size = image_size
        self.out_indices = tuple(out_indices)
        self.temporal_fusion = temporal_fusion
        self._spatial_frozen = False

        config = Swinv2Config.from_pretrained(hf_model_name_or_path)
        config.num_channels = num_channels
        config.image_size = image_size
        config.output_hidden_states = True
        config.return_dict = True

        if pretrained:
            self.swin = Swinv2Model.from_pretrained(
                hf_model_name_or_path,
                config=config,
                ignore_mismatched_sizes=ignore_mismatched_sizes,
            )
        else:
            self.swin = Swinv2Model(config)

        if gradient_checkpointing and hasattr(self.swin, 'gradient_checkpointing_enable'):
            self.swin.gradient_checkpointing_enable()

        self.embed_dim = self._get_embed_dim(config)
        if expected_embed_dim is not None and int(expected_embed_dim) != int(self.embed_dim):
            raise ValueError(
                f'Config expected_embed_dim={expected_embed_dim}, but HF config '
                f'embed_dim={self.embed_dim}. Set SWINV2_EMBED_DIMS correctly.')

        self.stage_channels = [self.embed_dim * (2 ** i) for i in range(4)]
        self.out_channels = tuple(self.stage_channels[i] for i in self.out_indices)

        fusion_modules = []
        for idx in self.out_indices:
            channels = self.stage_channels[idx]
            if temporal_fusion == 'attention':
                fusion_modules.append(TemporalAttentionFusion(channels))
            elif temporal_fusion == 'mean':
                fusion_modules.append(TemporalMeanFusion())
            elif temporal_fusion == 'max':
                fusion_modules.append(TemporalMaxFusion())
            else:
                raise ValueError(
                    f'Unsupported temporal_fusion={temporal_fusion}. '
                    'Choose from "attention", "mean", "max".')
        self.fusion_modules = nn.ModuleList(fusion_modules)

    @staticmethod
    def _get_embed_dim(config) -> int:
        if hasattr(config, 'embed_dim'):
            return int(config.embed_dim)
        if hasattr(config, 'hidden_sizes') and len(config.hidden_sizes) > 0:
            return int(config.hidden_sizes[0])
        raise AttributeError(
            'Cannot infer SwinV2 embed dimension from HF config. '
            'Expected config.embed_dim or config.hidden_sizes.')

    def _get_stage_features(
        self,
        outputs,
        batch_time: int,
        input_hw: Tuple[int, int],
    ) -> List[torch.Tensor]:
        """Return four BCHW stage features from HF outputs."""
        # Preferred path. HF Swin/SwinV2 exposes reshaped hidden states when
        # output_hidden_states=True. Usually:
        # [patch_embedding, stage1, stage2, stage3, stage4].
        reshaped = getattr(outputs, 'reshaped_hidden_states', None)
        if reshaped is not None:
            feats = list(reshaped)
            if len(feats) >= 5:
                feats = feats[1:5]
            elif len(feats) >= 4:
                feats = feats[:4]
            else:
                raise RuntimeError(
                    f'Expected at least 4 reshaped hidden states, got {len(feats)}.')

            normalized_feats = []
            for i, feat in enumerate(feats):
                # HF should return [N, C, H, W]. Be tolerant to NHWC.
                expected_c = self.stage_channels[i]
                if feat.ndim != 4:
                    raise RuntimeError(
                        f'Reshaped hidden state must be 4D, got {tuple(feat.shape)}')
                if feat.shape[1] != expected_c and feat.shape[-1] == expected_c:
                    feat = feat.permute(0, 3, 1, 2).contiguous()
                normalized_feats.append(feat)
            return normalized_feats

        # Fallback path: convert sequence hidden states [N, L, C] to BCHW.
        hidden_states = getattr(outputs, 'hidden_states', None)
        if hidden_states is None:
            raise RuntimeError(
                'HF SwinV2 output has neither reshaped_hidden_states nor hidden_states.')

        tokens = list(hidden_states)
        if len(tokens) >= 5:
            tokens = tokens[1:5]
        elif len(tokens) >= 4:
            tokens = tokens[:4]
        else:
            raise RuntimeError(f'Expected at least 4 hidden states, got {len(tokens)}.')

        h, w = input_hw
        feats = []
        for i, token in enumerate(tokens):
            if token.ndim != 3:
                raise RuntimeError(f'Hidden state must be [N, L, C], got {tuple(token.shape)}')
            stage_h = h // (4 * (2 ** i))
            stage_w = w // (4 * (2 ** i))
            n, length, channels = token.shape
            if length != stage_h * stage_w:
                # Last resort: infer square-ish shape.
                stage_h = int(length ** 0.5)
                stage_w = length // stage_h
            feat = token.transpose(1, 2).contiguous().view(n, channels, stage_h, stage_w)
            feats.append(feat)
        return feats

    def forward(self, x: torch.Tensor):
        if x.ndim != 5:
            raise ValueError(f'Expected input [B, T, C, H, W], got {tuple(x.shape)}')
        b, t, c, h, w = x.shape
        if c != self.num_channels:
            raise ValueError(f'Expected C={self.num_channels}, got C={c}')

        x = x.reshape(b * t, c, h, w)
        outputs = self.swin(
            pixel_values=x,
            output_hidden_states=True,
            return_dict=True,
        )
        stage_feats = self._get_stage_features(outputs, b * t, (h, w))

        outs = []
        for feat_idx, fusion in zip(self.out_indices, self.fusion_modules):
            feat = stage_feats[feat_idx]
            _, channels, feat_h, feat_w = feat.shape
            feat = feat.contiguous().view(b, t, channels, feat_h, feat_w)
            outs.append(fusion(feat))
        return tuple(outs)

    def set_spatial_encoder_trainable(self, trainable: bool = True) -> None:
        for param in self.swin.parameters():
            param.requires_grad = trainable
        self._spatial_frozen = not trainable
        if trainable:
            self.swin.train()
        else:
            self.swin.eval()

    def train(self, mode: bool = True):
        super().train(mode)
        if self._spatial_frozen:
            self.swin.eval()
        return self
