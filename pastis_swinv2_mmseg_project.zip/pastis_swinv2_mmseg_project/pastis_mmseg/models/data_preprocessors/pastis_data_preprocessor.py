from typing import Optional, Sequence

import torch
from mmengine.model import BaseDataPreprocessor
from mmseg.registry import MODELS


@MODELS.register_module()
class PastisSegDataPreProcessor(BaseDataPreprocessor):
    """Data preprocessor for PASTIS temporal tensors.

    Input:
        list[Tensor] of [T, C, H, W], or Tensor [B, T, C, H, W].

    Output:
        Tensor [B, T, C, H, W].
    """

    def __init__(
        self,
        mean: Optional[Sequence[float]] = None,
        std: Optional[Sequence[float]] = None,
        seg_pad_val: int = -1,
        non_blocking: bool = False,
    ) -> None:
        super().__init__(non_blocking=non_blocking)
        self.seg_pad_val = seg_pad_val

        if mean is None or std is None:
            self._enable_normalize = False
        else:
            if len(mean) != len(std):
                raise ValueError('mean and std must have the same length.')
            mean_tensor = torch.tensor(mean, dtype=torch.float32).view(1, 1, -1, 1, 1)
            std_tensor = torch.tensor(std, dtype=torch.float32).view(1, 1, -1, 1, 1)
            self.register_buffer('mean', mean_tensor, persistent=False)
            self.register_buffer('std', std_tensor, persistent=False)
            self._enable_normalize = True

    def forward(self, data: dict, training: bool = False) -> dict:
        data = self.cast_data(data)

        inputs = data['inputs']
        if isinstance(inputs, (list, tuple)):
            inputs = torch.stack(inputs, dim=0)
        elif torch.is_tensor(inputs) and inputs.ndim == 4:
            inputs = inputs.unsqueeze(0)

        if not torch.is_tensor(inputs):
            raise TypeError(f'inputs must be Tensor or list[Tensor], got {type(inputs)}')
        if inputs.ndim != 5:
            raise ValueError(
                f'inputs must have shape [B, T, C, H, W], got {tuple(inputs.shape)}')

        inputs = inputs.float()
        if self._enable_normalize:
            if inputs.shape[2] != self.mean.shape[2]:
                raise ValueError(
                    f'Input channel={inputs.shape[2]} but mean/std channel='
                    f'{self.mean.shape[2]}')
            inputs = (inputs - self.mean) / self.std.clamp_min(1e-6)

        return dict(inputs=inputs, data_samples=data.get('data_samples', None))
