import torch
import torch.nn as nn
from mmseg.models.decode_heads.decode_head import BaseDecodeHead
from mmseg.models.utils import resize
from mmseg.registry import MODELS


@MODELS.register_module()
class LinearProbeHead(BaseDecodeHead):
    """Simple linear segmentation head over concatenated multi-scale features.

    It upsamples all selected features to the resolution of the first selected
    feature, concatenates them, then applies one 1x1 classifier.

    This is intentionally minimal for probing representation quality.
    """

    def __init__(self, **kwargs) -> None:
        kwargs.setdefault('input_transform', 'multiple_select')
        super().__init__(**kwargs)

        if not isinstance(self.in_channels, (list, tuple)):
            raise TypeError('LinearProbeHead expects in_channels as list/tuple.')
        concat_channels = int(sum(self.in_channels))
        self.channels = concat_channels
        self.conv_seg = nn.Conv2d(concat_channels, self.num_classes, kernel_size=1)

    def forward(self, inputs):
        feats = self._transform_inputs(inputs)
        if not isinstance(feats, (list, tuple)):
            feats = [feats]

        target_size = feats[0].shape[2:]
        resized_feats = []
        for feat in feats:
            if feat.shape[2:] != target_size:
                feat = resize(
                    input=feat,
                    size=target_size,
                    mode='bilinear',
                    align_corners=self.align_corners)
            resized_feats.append(feat)

        x = torch.cat(resized_feats, dim=1)
        if self.dropout is not None:
            x = self.dropout(x)
        return self.cls_seg(x)
