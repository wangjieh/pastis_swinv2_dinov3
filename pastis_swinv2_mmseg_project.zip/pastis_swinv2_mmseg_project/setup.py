from setuptools import find_packages, setup

setup(
    name='pastis-mmseg-swinv2',
    version='0.1.0',
    description='PASTIS SwinV2 temporal semantic segmentation project for MMSegmentation 1.2.2.',
    packages=find_packages(),
    install_requires=[
        'transformers>=4.36.0',
        'safetensors>=0.4.0',
        'Pillow>=9.0.0',
        'tqdm>=4.60.0',
    ],
)
