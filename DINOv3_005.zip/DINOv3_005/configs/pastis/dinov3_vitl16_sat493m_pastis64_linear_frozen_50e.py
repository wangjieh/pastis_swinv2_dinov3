# 2. Fan-style four-layer patch-linear probe: DINOv3 backbone frozen for all 50 epochs.

custom_imports = dict(
    imports=['projects.DINOv3_PASTIS_4configs'],
    allow_failed_imports=False,
)

default_scope = 'mmseg'

# ===== User-editable paths and switches =====
data_root = 'data/pastis_dataset_64'
dinov3_repo_path = 'projects/DINOv3_PASTIS_4configs'
dinov3_weights_path = 'checkpoints/dinov3_vitl16_pretrain_sat493m-eadcf0ff.pth'
norm_param_path = 'projects/DINOv3_PASTIS_4configs/configs/norm_params/dinov3_sat493m_rgb.json'

# Default keeps the latest adaptive-RGB preprocessing from the supplied package.
# Set to False to return to the original clamp(x / 10000, 0, 1) baseline.
use_adaptive_rgb = True
low_percentile = 2.0
high_percentile = 98.0

# Temporal fusion interface: choose 'mean' or 'max'.
temporal_fusion = 'mean'

# Keep the original DINOv3_005 four-layer feature selection.
# These are ViT-L/16 transformer-block indices.
multilayer_out_indices = (4, 11, 17, 23)

# PASTIS processed images are [T, 13, 64, 64]. Sentinel-2 RGB = B4/B3/B2.
rgb_indices = (3, 2, 1)
num_classes = 19
ignore_index = 255
crop_size = (64, 64)

if use_adaptive_rgb:
    rgb_loader = dict(
        type='LoadPastisAdaptiveRGBFromPt',
        rgb_indices=rgb_indices,
        low_percentile=low_percentile,
        high_percentile=high_percentile,
        round_to_uint8=True,
        norm_param_path=norm_param_path,
    )
else:
    rgb_loader = dict(
        type='LoadPastisRGBFromPt',
        rgb_indices=rgb_indices,
        scale_factor=10000.0,
        clamp_range=(0.0, 1.0),
        norm_param_path=norm_param_path,
    )

# ===== Data pipeline =====
train_pipeline = [
    rgb_loader,
    dict(
        type='LoadPastisTargetFromPt',
        ignore_index=-1,
        target_ignore_index=ignore_index,
    ),
    dict(type='PackPastisSegInputs'),
]
test_pipeline = train_pipeline

train_dataloader = dict(
    batch_size=4,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=True),
    collate_fn=dict(type='pseudo_collate'),
    dataset=dict(
        type='PastisDataset',
        data_root=data_root,
        split='pastis_r_train',
        pipeline=train_pipeline,
    ),
)

val_dataloader = dict(
    batch_size=4,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=False),
    collate_fn=dict(type='pseudo_collate'),
    dataset=dict(
        type='PastisDataset',
        data_root=data_root,
        split='pastis_r_val',
        pipeline=test_pipeline,
        test_mode=True,
    ),
)

test_dataloader = dict(
    batch_size=4,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=False),
    collate_fn=dict(type='pseudo_collate'),
    dataset=dict(
        type='PastisDataset',
        data_root=data_root,
        split='pastis_r_test',
        pipeline=test_pipeline,
        test_mode=True,
    ),
)

val_evaluator = dict(type='IoUMetric', iou_metrics=['mIoU'], ignore_index=ignore_index)
test_evaluator = val_evaluator

train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=50, val_interval=1)
val_cfg = dict(type='ValLoop')
test_cfg = dict(type='TestLoop')

default_hooks = dict(
    timer=dict(type='IterTimerHook'),
    logger=dict(type='LoggerHook', interval=50, log_metric_by_epoch=True),
    param_scheduler=dict(type='ParamSchedulerHook'),
    checkpoint=dict(
        type='CheckpointHook',
        by_epoch=True,
        interval=1,
        max_keep_ckpts=3,
        save_best='mIoU',
    ),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    visualization=dict(type='SegVisualizationHook'),
)

log_processor = dict(type='LogProcessor', window_size=50, by_epoch=True)
log_level = 'INFO'
load_from = None
resume = False

vis_backends = [dict(type='LocalVisBackend')]
visualizer = dict(
    type='SegLocalVisualizer',
    vis_backends=vis_backends,
    name='visualizer',
)

# NCCL + one process per GPU supports torchrun multi-GPU training.
env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0),
    dist_cfg=dict(backend='nccl'),
)

randomness = dict(seed=0, deterministic=False)

# ===== Model: fan-style four-layer patch-linear probe =====
model = dict(
    type='EncoderDecoder',
    data_preprocessor=dict(type='PastisSegDataPreProcessor'),

    backbone=dict(
        type='TemporalDINOv3ViT',
        temporal_fusion=temporal_fusion,
        frame_backbone=dict(
            type='DINOv3ViT',
            model_name='dinov3_vitl16',
            repo_path=dinov3_repo_path,
            weights_path=dinov3_weights_path,
            weights_name='SAT493M',
            out_indices=multilayer_out_indices,
            patch_size=16,
            load_strict=True,
            freeze=True,
            norm=True,
        ),
    ),

    decode_head=dict(
        type='DINOv3FanStyleFourLayerLinearProbeHead',
        in_channels=[1024, 1024, 1024, 1024],
        channels=4096,
        in_index=(0, 1, 2, 3),
        patch_size=16,
        resize_inputs=True,
        output_size=crop_size,
        dropout_ratio=0.0,
        num_classes=num_classes,
        ignore_index=ignore_index,
        align_corners=False,
        loss_decode=dict(
            type='CrossEntropyLoss',
            use_sigmoid=False,
            loss_weight=1.0,
        ),
    ),
    train_cfg=dict(),
    test_cfg=dict(mode='whole'),
)

# ===== Optimization: decoder only; DINOv3 backbone frozen for all 50 epochs =====
optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(
        type='AdamW',
        lr=1e-3,
        betas=(0.9, 0.999),
        weight_decay=0.01,
    ),
    clip_grad=dict(max_norm=1.0, norm_type=2),
)

param_scheduler = [
    dict(type='LinearLR', start_factor=1e-3, by_epoch=False, begin=0, end=100),
    dict(type='PolyLR', eta_min=0.0, power=1.0, by_epoch=True, begin=0, end=50),
]
