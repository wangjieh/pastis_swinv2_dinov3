from pathlib import Path
from typing import Optional, Sequence

import torch
from mmengine.dataset import BaseDataset
from mmseg.registry import DATASETS


@DATASETS.register_module()
class PastisDataset(BaseDataset):
    """PASTIS-64 dataset stored as temporal ``.pt`` tensors.

    Expected split layout::

        pastis_dataset_64/
        ├── pastis_r_train/
        │   ├── s2_images/
        │   │   ├── 0.pt
        │   │   ├── 1.pt
        │   │   └── ...
        │   └── targets.pt       # [N, 64, 64]
        ├── pastis_r_val/
        └── pastis_r_test/

    Each image file is expected to contain a tensor with shape ``T x C x H x W``.
    For the current PASTIS preprocessing, ``T=12`` and ``C=13``.
    """

    METAINFO = dict(
        classes=tuple(f'class_{idx}' for idx in range(19)),
        palette=[
            [0, 0, 0],
            [128, 0, 0],
            [0, 128, 0],
            [128, 128, 0],
            [0, 0, 128],
            [128, 0, 128],
            [0, 128, 128],
            [128, 128, 128],
            [64, 0, 0],
            [192, 0, 0],
            [64, 128, 0],
            [192, 128, 0],
            [64, 0, 128],
            [192, 0, 128],
            [64, 128, 128],
            [192, 128, 128],
            [0, 64, 0],
            [128, 64, 0],
            [0, 192, 0],
        ],
    )

    def __init__(
        self,
        split: str,
        data_root: Optional[str] = None,
        image_dir_name: str = 's2_images',
        target_file_name: str = 'targets.pt',
        indices: Optional[Sequence[int]] = None,
        **kwargs,
    ) -> None:
        self.split = split
        self.image_dir_name = image_dir_name
        self.target_file_name = target_file_name
        super().__init__(
            data_root=data_root,
            indices=indices,
            **kwargs,
        )

    def load_data_list(self):
        if self.data_root is None:
            raise ValueError('`data_root` must be provided for PastisDataset.')

        split_dir = Path(self.data_root).expanduser() / self.split
        image_dir = split_dir / self.image_dir_name
        target_path = split_dir / self.target_file_name

        if not image_dir.is_dir():
            raise FileNotFoundError(f'PASTIS image directory not found: {image_dir}')
        if not target_path.is_file():
            raise FileNotFoundError(f'PASTIS target file not found: {target_path}')

        # Load only the target tensor metadata to determine sample count.  The
        # actual targets are cached per worker inside LoadPastisTargetFromPt.
        targets = torch.load(str(target_path), map_location='cpu')
        if not torch.is_tensor(targets) or targets.ndim != 3:
            raise ValueError(
                f'Expected targets.pt to be a [N, H, W] tensor, got '
                f'{type(targets)} with shape {getattr(targets, "shape", None)}.'
            )

        num_samples = int(targets.shape[0])
        data_list = []
        missing = []
        for idx in range(num_samples):
            img_path = image_dir / f'{idx}.pt'
            if not img_path.is_file():
                missing.append(str(img_path))
                continue
            data_list.append(
                dict(
                    img_path=str(img_path),
                    target_path=str(target_path),
                    target_index=idx,
                    seg_map_path=str(target_path),
                    sample_idx=idx,
                )
            )

        if missing:
            preview = '\n'.join(missing[:10])
            raise FileNotFoundError(
                f'{len(missing)} image files referenced by targets.pt are missing. '
                f'First missing files:\n{preview}'
            )

        return data_list
