import json
from pathlib import Path
from typing import Dict, Optional, Sequence, Tuple

import torch
from mmcv.transforms import BaseTransform
from mmengine.structures import PixelData
from mmseg.registry import TRANSFORMS
from mmseg.structures import SegDataSample


def _as_float_tuple(values, name: str) -> Tuple[float, ...]:
    if values is None:
        raise ValueError(f'Missing `{name}` in normalization parameter file.')
    return tuple(float(v) for v in values)


def _load_tensor_from_pt(path: str) -> torch.Tensor:
    data = torch.load(path, map_location='cpu')
    if isinstance(data, dict):
        for key in ('img', 'image', 's2', 'data'):
            if key in data:
                data = data[key]
                break
    if not torch.is_tensor(data):
        raise TypeError(f'Expected image file to contain a tensor: {path}')
    if data.ndim != 4:
        raise ValueError(
            f'Expected image tensor shape [T, C, H, W], got {tuple(data.shape)} '
            f'from {path}'
        )
    return data


class _DINOv3RGBNormMixin:
    _norm_cache: Dict[str, Tuple[Tuple[float, ...], Tuple[float, ...]]] = {}

    def _load_norm_params(self) -> Tuple[Tuple[float, ...], Tuple[float, ...]]:
        if self.norm_param_path is None:
            return self.mean, self.std

        path = str(Path(self.norm_param_path).expanduser())
        cache_key = f'{path}::{self.norm_key}'
        if cache_key in self._norm_cache:
            return self._norm_cache[cache_key]

        with open(path, 'r', encoding='utf-8') as f:
            params = json.load(f)

        if self.norm_key is not None:
            try:
                params = params[self.norm_key]
            except KeyError as exc:
                raise KeyError(
                    f'Normalization key `{self.norm_key}` was not found in {path}.'
                ) from exc

        mean = _as_float_tuple(params.get('mean'), 'mean')
        std = _as_float_tuple(params.get('std'), 'std')

        if len(mean) != 3 or len(std) != 3:
            raise ValueError(
                'DINOv3 RGB normalization parameters must have length 3. '
                f'Got mean={len(mean)}, std={len(std)} from {path}.'
            )

        self._norm_cache[cache_key] = (mean, std)
        return mean, std

    def _normalize(self, img: torch.Tensor) -> torch.Tensor:
        mean, std = self._load_norm_params()
        mean_tensor = img.new_tensor(mean).view(1, 3, 1, 1)
        std_tensor = img.new_tensor(std).view(1, 3, 1, 1)
        return (img - mean_tensor) / std_tensor


@TRANSFORMS.register_module()
class LoadPastisRGBFromPt(BaseTransform, _DINOv3RGBNormMixin):
    """Load PASTIS temporal RGB inputs using the original /10000 baseline.

    Pipeline:
        S2 RGB(B4/B3/B2) -> clamp(x / scale_factor, 0, 1)
        -> DINOv3 RGB normalize.
    """

    def __init__(
        self,
        rgb_indices: Sequence[int] = (3, 2, 1),
        scale_factor: float = 10000.0,
        clamp_range: Tuple[float, float] = (0.0, 1.0),
        norm_param_path: Optional[str] = None,
        norm_key: Optional[str] = None,
        mean: Sequence[float] = (0.430, 0.411, 0.296),
        std: Sequence[float] = (0.213, 0.156, 0.143),
        auto_10ch_rgb_indices: bool = True,
        dtype: str = 'float32',
    ) -> None:
        self.rgb_indices = tuple(int(i) for i in rgb_indices)
        self.scale_factor = float(scale_factor)
        self.clamp_range = tuple(float(v) for v in clamp_range)
        self.norm_param_path = norm_param_path
        self.norm_key = norm_key
        self.mean = tuple(float(v) for v in mean)
        self.std = tuple(float(v) for v in std)
        self.auto_10ch_rgb_indices = auto_10ch_rgb_indices
        self.dtype = dtype

    def transform(self, results: dict) -> dict:
        img_path = results['img_path']
        img = _load_tensor_from_pt(img_path)

        img = img.to(torch.float32) if self.dtype == 'float32' else img.float()

        num_channels = int(img.shape[1])
        rgb_indices = self.rgb_indices
        if num_channels == 10 and self.auto_10ch_rgb_indices:
            # Raw 10-channel PASTIS order is B2/B3/B4/...; RGB is B4/B3/B2.
            rgb_indices = (2, 1, 0)

        if max(rgb_indices) >= num_channels or min(rgb_indices) < 0:
            raise ValueError(
                f'Invalid rgb_indices={rgb_indices} for image with '
                f'{num_channels} channels: {img_path}'
            )

        img = img[:, list(rgb_indices), :, :]

        if self.scale_factor is not None and self.scale_factor > 0:
            img = img / self.scale_factor
        if self.clamp_range is not None:
            img = img.clamp(min=self.clamp_range[0], max=self.clamp_range[1])

        img = self._normalize(img)

        h, w = int(img.shape[-2]), int(img.shape[-1])
        results['img'] = img.contiguous()
        results['img_shape'] = (h, w)
        results['ori_shape'] = (h, w)
        results['pad_shape'] = (h, w)
        results['num_timesteps'] = int(img.shape[0])
        results['num_channels'] = 3
        return results


@TRANSFORMS.register_module()
class LoadPastisAdaptiveRGBFromPt(BaseTransform, _DINOv3RGBNormMixin):
    """Load PASTIS temporal RGB inputs using per-image adaptive stretching.

    This follows the same stretching idea as ``test/export_pastis_rgb_adaptive_png.py``.

    For every sample, every month, and every RGB channel independently:

        low_percentile  -> 0
        high_percentile -> 255

    Then the stretched 8-bit RGB value is divided by 255 to return to [0, 1],
    and finally DINOv3 SAT493M RGB normalization is applied.

    Input:
        .pt tensor with shape [T, C, H, W]

    Output:
        results['img'] with shape [T, 3, H, W], normalized for DINOv3.
    """

    def __init__(
        self,
        rgb_indices: Sequence[int] = (3, 2, 1),
        low_percentile: float = 2.0,
        high_percentile: float = 98.0,
        norm_param_path: Optional[str] = None,
        norm_key: Optional[str] = None,
        mean: Sequence[float] = (0.430, 0.411, 0.296),
        std: Sequence[float] = (0.213, 0.156, 0.143),
        auto_10ch_rgb_indices: bool = True,
        round_to_uint8: bool = True,
        eps: float = 1e-6,
        dtype: str = 'float32',
    ) -> None:
        if high_percentile <= low_percentile:
            raise ValueError('`high_percentile` must be larger than `low_percentile`.')
        if low_percentile < 0 or high_percentile > 100:
            raise ValueError('Percentiles must be within [0, 100].')

        self.rgb_indices = tuple(int(i) for i in rgb_indices)
        self.low_percentile = float(low_percentile)
        self.high_percentile = float(high_percentile)
        self.norm_param_path = norm_param_path
        self.norm_key = norm_key
        self.mean = tuple(float(v) for v in mean)
        self.std = tuple(float(v) for v in std)
        self.auto_10ch_rgb_indices = auto_10ch_rgb_indices
        self.round_to_uint8 = bool(round_to_uint8)
        self.eps = float(eps)
        self.dtype = dtype

    def _adaptive_stretch_to_01(self, img: torch.Tensor) -> torch.Tensor:
        """Stretch [T, 3, H, W] to [0, 1] using per-frame per-channel quantiles."""
        t, c, h, w = img.shape
        flat = img.reshape(t, c, -1)

        # torch.quantile expects q in [0, 1].
        q_low = self.low_percentile / 100.0
        q_high = self.high_percentile / 100.0
        lo = torch.quantile(flat, q_low, dim=-1, keepdim=True)
        hi = torch.quantile(flat, q_high, dim=-1, keepdim=True)

        valid = torch.isfinite(lo) & torch.isfinite(hi) & ((hi - lo) > self.eps)
        stretched = (flat - lo) / (hi - lo).clamp_min(self.eps)
        stretched = stretched.clamp(0.0, 1.0)
        stretched = torch.where(valid, stretched, torch.zeros_like(stretched))
        stretched = stretched.reshape(t, c, h, w)

        # Match the requested processing exactly:
        # stretch RGB to 0-255 8-bit, then divide by 255 before DINOv3 normalize.
        if self.round_to_uint8:
            stretched = (stretched * 255.0).round().clamp(0.0, 255.0) / 255.0

        return stretched

    def transform(self, results: dict) -> dict:
        img_path = results['img_path']
        img = _load_tensor_from_pt(img_path)

        img = img.to(torch.float32) if self.dtype == 'float32' else img.float()

        num_channels = int(img.shape[1])
        rgb_indices = self.rgb_indices
        if num_channels == 10 and self.auto_10ch_rgb_indices:
            # Raw 10-channel PASTIS order is B2/B3/B4/...; RGB is B4/B3/B2.
            rgb_indices = (2, 1, 0)

        if max(rgb_indices) >= num_channels or min(rgb_indices) < 0:
            raise ValueError(
                f'Invalid rgb_indices={rgb_indices} for image with '
                f'{num_channels} channels: {img_path}'
            )

        img = img[:, list(rgb_indices), :, :]
        img = self._adaptive_stretch_to_01(img)
        img = self._normalize(img)

        h, w = int(img.shape[-2]), int(img.shape[-1])
        results['img'] = img.contiguous()
        results['img_shape'] = (h, w)
        results['ori_shape'] = (h, w)
        results['pad_shape'] = (h, w)
        results['num_timesteps'] = int(img.shape[0])
        results['num_channels'] = 3
        return results


@TRANSFORMS.register_module()
class LoadPastisTargetFromPt(BaseTransform):
    """Load one target mask from split-level ``targets.pt``.

    Args:
        ignore_index: Label value in the original PASTIS target tensor.
        target_ignore_index: Label value exposed to MMSegmentation. Using 255
            keeps compatibility with common MMSeg losses and metrics.
    """

    _target_cache: Dict[str, torch.Tensor] = {}

    def __init__(self, ignore_index: int = -1, target_ignore_index: int = 255):
        self.ignore_index = int(ignore_index)
        self.target_ignore_index = int(target_ignore_index)

    def _load_targets(self, target_path: str) -> torch.Tensor:
        target_path = str(Path(target_path).expanduser())
        if target_path not in self._target_cache:
            targets = torch.load(target_path, map_location='cpu')
            if not torch.is_tensor(targets) or targets.ndim != 3:
                raise ValueError(
                    f'Expected targets.pt to be a [N, H, W] tensor, got '
                    f'{type(targets)} with shape {getattr(targets, "shape", None)}.'
                )
            self._target_cache[target_path] = targets
        return self._target_cache[target_path]

    def transform(self, results: dict) -> dict:
        targets = self._load_targets(results['target_path'])
        index = int(results['target_index'])
        if index < 0 or index >= int(targets.shape[0]):
            raise IndexError(
                f'target_index={index} is out of range for {results["target_path"]} '
                f'with {targets.shape[0]} targets.'
            )

        gt = targets[index].clone().long()
        gt[gt == self.ignore_index] = self.target_ignore_index
        results['gt_seg_map'] = gt.contiguous()
        results.setdefault('seg_fields', []).append('gt_seg_map')
        return results


@TRANSFORMS.register_module()
class PackPastisSegInputs(BaseTransform):
    """Pack PASTIS tensors into MMSegmentation model inputs."""

    def __init__(
        self,
        meta_keys: Sequence[str] = (
            'img_path',
            'seg_map_path',
            'ori_shape',
            'img_shape',
            'pad_shape',
            'sample_idx',
            'num_timesteps',
        ),
    ) -> None:
        self.meta_keys = tuple(meta_keys)

    def transform(self, results: dict) -> dict:
        packed_results = dict()
        packed_results['inputs'] = results['img']

        data_sample = SegDataSample()
        if 'gt_seg_map' in results:
            gt = results['gt_seg_map']
            if gt.ndim == 2:
                gt = gt.unsqueeze(0)
            data_sample.gt_sem_seg = PixelData(data=gt)

        metainfo = {
            key: results[key]
            for key in self.meta_keys
            if key in results
        }
        data_sample.set_metainfo(metainfo)
        packed_results['data_samples'] = data_sample
        return packed_results
