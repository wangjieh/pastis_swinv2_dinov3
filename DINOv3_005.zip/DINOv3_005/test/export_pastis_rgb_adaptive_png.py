#!/usr/bin/env python3
"""Export PASTIS RGB images as per-image adaptive-stretched 8-bit PNGs.

Input .pt shape: T x C x H x W.
13-band Sentinel-2 RGB: B4/B3/B2 = channel indices [3, 2, 1].
10-band fallback RGB:   B4/B3/B2 = channel indices [2, 1, 0].

For every sample and every month, each RGB channel is stretched independently:
  p_low -> 0
  p_high -> 255
Default is 2%-98%.
"""

import argparse
from pathlib import Path

import numpy as np
import torch
from PIL import Image


DEFAULT_SPLITS = ("pastis_r_train", "pastis_r_val", "pastis_r_test")


def sort_key(path: Path):
    return int(path.stem) if path.stem.isdigit() else path.stem


def load_rgb(pt_path: Path) -> np.ndarray:
    x = torch.load(str(pt_path), map_location="cpu")

    if isinstance(x, dict):
        for key in ("img", "image", "s2", "data"):
            if key in x:
                x = x[key]
                break

    if not torch.is_tensor(x) or x.ndim != 4:
        raise ValueError(
            f"{pt_path}: expected tensor T x C x H x W, "
            f"got {type(x)} {getattr(x, 'shape', None)}"
        )

    rgb_idx = (3, 2, 1) if x.shape[1] >= 13 else (2, 1, 0)
    return x[:, rgb_idx].float().numpy()  # T x 3 x H x W


def stretch_one_image(img_chw: np.ndarray, low: float, high: float) -> np.ndarray:
    """Convert one C x H x W RGB image to H x W x 3 uint8."""
    out = np.empty_like(img_chw, dtype=np.float32)

    for c in range(3):
        band = img_chw[c]
        lo = np.percentile(band, low)
        hi = np.percentile(band, high)

        if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
            out[c] = 0
        else:
            out[c] = np.clip((band - lo) / (hi - lo), 0.0, 1.0)

    out = (out * 255.0).round().astype(np.uint8)
    return np.transpose(out, (1, 2, 0))  # H x W x 3


def export_split(data_root: Path, out_root: Path, split: str, low: float, high: float, overwrite: bool):
    img_dir = data_root / split / "s2_images"
    if not img_dir.is_dir():
        print(f"Skip {split}: {img_dir} not found")
        return

    pt_files = sorted(img_dir.glob("*.pt"), key=sort_key)
    print(f"Exporting {split}: {len(pt_files)} samples")

    for pt_path in pt_files:
        rgb = load_rgb(pt_path)
        sample_dir = out_root / split / "rgb_adaptive_png" / pt_path.stem
        sample_dir.mkdir(parents=True, exist_ok=True)

        for month_id, img_chw in enumerate(rgb, start=1):
            out_path = sample_dir / f"month_{month_id:02d}.png"
            if out_path.exists() and not overwrite:
                continue

            img_hwc = stretch_one_image(img_chw, low=low, high=high)
            Image.fromarray(img_hwc).save(out_path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", required=True, help="Path to pastis_dataset_64.")
    parser.add_argument("--out-root", required=True, help="Output directory.")
    parser.add_argument("--splits", nargs="+", default=list(DEFAULT_SPLITS))
    parser.add_argument("--low-percentile", type=float, default=2.0)
    parser.add_argument("--high-percentile", type=float, default=98.0)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    if args.high_percentile <= args.low_percentile:
        raise ValueError("--high-percentile must be larger than --low-percentile")

    data_root = Path(args.data_root)
    out_root = Path(args.out_root)

    for split in args.splits:
        export_split(
            data_root=data_root,
            out_root=out_root,
            split=split,
            low=args.low_percentile,
            high=args.high_percentile,
            overwrite=args.overwrite,
        )


if __name__ == "__main__":
    main()
