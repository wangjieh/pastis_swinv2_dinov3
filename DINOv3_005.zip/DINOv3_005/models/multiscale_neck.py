"""Multi-scale neck for using DINOv3 ViT features with UPerNet."""

from typing import Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F
from mmengine.model import BaseModule
from mmseg.registry import MODELS


@MODELS.register_module()
class DINOv3MultiScaleNeck(BaseModule):
    """Convert four same-resolution ViT maps into a feature pyramid.

    DINOv3 ViT intermediate layers share the same patch-grid resolution.
    UPerNet is more naturally used with a pyramid, so this neck applies a
    learnable 1x1 lateral projection to each selected layer and rescales
    them independently.

    For PASTIS-64 and ViT-L/16, the backbone patch grid is 4x4.  With
    ``scale_factors=(4.0, 2.0, 1.0, 0.5)``, this neck returns:

        stage 0: 16x16  (stride 4)
        stage 1:  8x8  (stride 8)
        stage 2:  4x4  (stride 16)
        stage 3:  2x2  (stride 32)
    """

    def __init__(
        self,
        in_channels: Sequence[int],
        out_channels: int = 256,
        scale_factors: Sequence[float] = (4.0, 2.0, 1.0, 0.5),
        init_cfg=None,
    ) -> None:
        super().__init__(init_cfg=init_cfg)
        self.in_channels = tuple(int(c) for c in in_channels)
        self.out_channels = int(out_channels)
        self.scale_factors = tuple(float(s) for s in scale_factors)

        if len(self.in_channels) != len(self.scale_factors):
            raise ValueError(
                "`in_channels` and `scale_factors` must have the same "
                f"length, got {len(self.in_channels)} and "
                f"{len(self.scale_factors)}."
            )
        if len(self.in_channels) != 4:
            raise ValueError(
                "DINOv3MultiScaleNeck is configured for exactly four "
                f"feature maps, got {len(self.in_channels)}."
            )
        if any(scale <= 0 for scale in self.scale_factors):
            raise ValueError("All scale factors must be positive.")

        self.lateral_convs = nn.ModuleList(
            [
                nn.Conv2d(in_ch, self.out_channels, kernel_size=1)
                for in_ch in self.in_channels
            ]
        )

    def init_weights(self) -> None:
        for module in self.lateral_convs:
            nn.init.kaiming_normal_(
                module.weight,
                mode="fan_out",
                nonlinearity="relu",
            )
            if module.bias is not None:
                nn.init.constant_(module.bias, 0.0)

    @staticmethod
    def _target_size(
        x: torch.Tensor,
        scale_factor: float,
    ) -> tuple[int, int]:
        height, width = x.shape[-2:]
        return (
            max(int(round(height * scale_factor)), 1),
            max(int(round(width * scale_factor)), 1),
        )

    def forward(
        self,
        inputs: tuple[torch.Tensor, ...] | list[torch.Tensor],
    ) -> tuple[torch.Tensor, ...]:
        if len(inputs) != len(self.lateral_convs):
            raise ValueError(
                "Unexpected number of feature maps: expected "
                f"{len(self.lateral_convs)}, got {len(inputs)}."
            )

        outputs = []
        for x, lateral_conv, scale_factor in zip(
            inputs,
            self.lateral_convs,
            self.scale_factors,
        ):
            x = lateral_conv(x)
            target_size = self._target_size(x, scale_factor)
            if x.shape[-2:] != target_size:
                x = F.interpolate(
                    x,
                    size=target_size,
                    mode="bilinear",
                    align_corners=False,
                )
            outputs.append(x)
        return tuple(outputs)
