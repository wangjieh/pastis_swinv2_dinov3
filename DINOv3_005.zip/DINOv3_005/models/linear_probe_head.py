"""DINOv3 dense linear-probing decode heads for MMSegmentation.

The main head in this file follows the structure of the official
DINOv3 semantic-segmentation ``LinearHead``:

    selected intermediate features
    -> resize to a shared patch-grid size
    -> concatenate along channels
    -> Dropout2d
    -> SyncBatchNorm
    -> one 1x1 classification convolution

The DINOv3 backbone must remain frozen for a strict linear-probing
experiment.  The same head can also be used while fine-tuning the
backbone, but that experiment should be described as fine-tuning with a
linear segmentation head rather than strict probing.
"""

from typing import Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F
from mmseg.models.decode_heads.decode_head import BaseDecodeHead
from mmseg.registry import MODELS


@MODELS.register_module()
class DINOv3OfficialLinearProbeHead(BaseDecodeHead):
    """Four-layer dense linear head adapted from the official DINOv3 code.

    The selected ViT intermediate features are normally same-resolution
    patch grids.  Resizing is retained to match the official DINOv3
    implementation and to keep the head robust if the selected feature
    maps differ in spatial size.

    Args:
        resize_inputs: Resize selected features to the first feature-map
            size before concatenation.
        use_batchnorm: Apply ``SyncBatchNorm`` between dropout and the
            final 1x1 classifier, matching the official head.
        **kwargs: Standard MMSegmentation ``BaseDecodeHead`` arguments.

    Important:
        ``channels`` must equal ``sum(in_channels)``.  This guarantees
        that no hidden projection layer is inserted before the final
        classifier.
    """

    def __init__(
        self,
        resize_inputs: bool = True,
        use_batchnorm: bool = True,
        **kwargs,
    ) -> None:
        kwargs.setdefault("dropout_ratio", 0.1)
        super().__init__(input_transform="multiple_select", **kwargs)
        self.resize_inputs = bool(resize_inputs)
        self.use_batchnorm = bool(use_batchnorm)

        if not isinstance(self.in_channels, (list, tuple)):
            raise TypeError(
                "DINOv3OfficialLinearProbeHead expects `in_channels` "
                f"to be a list/tuple, got {type(self.in_channels)}."
            )

        expected_channels = int(sum(self.in_channels))
        if int(self.channels) != expected_channels:
            raise ValueError(
                "`channels` must equal sum(`in_channels`) for the "
                "official-style linear head. Got "
                f"channels={self.channels}, "
                f"sum(in_channels)={expected_channels}."
            )

        self.batchnorm_layer = (
            nn.SyncBatchNorm(self.channels)
            if self.use_batchnorm
            else nn.Identity()
        )

        # Match the explicit initialization used by the official head.
        nn.init.normal_(self.conv_seg.weight, mean=0.0, std=0.01)
        if self.conv_seg.bias is not None:
            nn.init.constant_(self.conv_seg.bias, 0.0)

    def _resize_to_first(
        self,
        inputs: Sequence[torch.Tensor],
    ) -> list[torch.Tensor]:
        if len(inputs) == 0:
            raise ValueError("No input features were selected by `in_index`.")

        target_size = inputs[0].shape[-2:]
        resized = []
        for x in inputs:
            if x.shape[-2:] != target_size:
                if not self.resize_inputs:
                    raise ValueError(
                        "Selected feature maps have different spatial "
                        f"sizes: {[tuple(t.shape[-2:]) for t in inputs]}. "
                        "Set `resize_inputs=True` to align them."
                    )
                x = F.interpolate(
                    x,
                    size=target_size,
                    mode="bilinear",
                    align_corners=self.align_corners,
                )
            resized.append(x)
        return resized

    def forward(
        self,
        inputs: torch.Tensor | tuple[torch.Tensor, ...] | list[torch.Tensor],
    ) -> torch.Tensor:
        selected = self._transform_inputs(inputs)
        if isinstance(selected, torch.Tensor):
            selected = [selected]
        selected = self._resize_to_first(selected)

        x = torch.cat(selected, dim=1)
        if self.dropout is not None:
            x = self.dropout(x)
        x = self.batchnorm_layer(x)
        return self.conv_seg(x)

@MODELS.register_module()
class DINOv3FanStyleFourLayerLinearProbeHead(BaseDecodeHead):
    """Fan-style patch-linear decoder using four DINOv3 feature maps.

    This head keeps the four-layer feature selection used by the original
    DINOv3_005 linear-probe configs, but changes the decoder idea to match
    ``dinov3_fan``:

        four patch-grid feature maps
        -> resize to a shared patch-grid size
        -> concatenate along channels
        -> per-patch ``nn.Linear`` classifier
        -> reshape patch logits back to dense segmentation logits

    For PASTIS-64 with ViT-L/16, four 4x4 feature maps are concatenated into
    a 4096-dimensional token at each patch.  The linear layer predicts
    ``num_classes * 16 * 16`` values per patch, which are rearranged into a
    dense 64x64 segmentation map.
    """

    def __init__(
        self,
        patch_size: int = 16,
        resize_inputs: bool = True,
        output_size=None,
        **kwargs,
    ) -> None:
        kwargs.setdefault("dropout_ratio", 0.0)
        super().__init__(input_transform="multiple_select", **kwargs)

        self.patch_size = int(patch_size)
        self.resize_inputs = bool(resize_inputs)

        if output_size is None:
            self.output_size = None
        elif isinstance(output_size, int):
            self.output_size = (int(output_size), int(output_size))
        else:
            if len(output_size) != 2:
                raise ValueError(
                    f"`output_size` must be None, int, or a 2-tuple, got {output_size}."
                )
            self.output_size = (int(output_size[0]), int(output_size[1]))

        if not isinstance(self.in_channels, (list, tuple)):
            raise TypeError(
                "DINOv3FanStyleFourLayerLinearProbeHead expects `in_channels` "
                f"to be a list/tuple, got {type(self.in_channels)}."
            )

        expected_channels = int(sum(self.in_channels))
        if int(self.channels) != expected_channels:
            raise ValueError(
                "`channels` must equal sum(`in_channels`) for the fan-style "
                "four-layer linear head. Got "
                f"channels={self.channels}, sum(in_channels)={expected_channels}."
            )

        # BaseDecodeHead creates conv_seg by default.  The fan-style linear
        # decoder uses a token-wise Linear projection instead, so conv_seg is
        # intentionally kept out of the forward path.
        self.conv_seg = nn.Identity()
        self.proj = nn.Linear(
            expected_channels,
            self.num_classes * self.patch_size * self.patch_size,
            bias=True,
        )

        nn.init.normal_(self.proj.weight, mean=0.0, std=0.01)
        if self.proj.bias is not None:
            nn.init.constant_(self.proj.bias, 0.0)

    def _resize_to_first(
        self,
        inputs: Sequence[torch.Tensor],
    ) -> list[torch.Tensor]:
        if len(inputs) == 0:
            raise ValueError("No input features were selected by `in_index`.")

        target_size = inputs[0].shape[-2:]
        resized = []
        for x in inputs:
            if x.shape[-2:] != target_size:
                if not self.resize_inputs:
                    raise ValueError(
                        "Selected feature maps have different spatial sizes: "
                        f"{[tuple(t.shape[-2:]) for t in inputs]}. "
                        "Set `resize_inputs=True` to align them."
                    )
                x = F.interpolate(
                    x,
                    size=target_size,
                    mode="bilinear",
                    align_corners=self.align_corners,
                )
            resized.append(x)
        return resized

    def forward(self, inputs):
        features = self._transform_inputs(inputs)
        features = self._resize_to_first(features)
        x = torch.cat(features, dim=1)

        batch_size, channels, height, width = x.shape
        if channels != self.channels:
            raise ValueError(
                f"Expected {self.channels} concatenated channels, got {channels}."
            )

        patch = self.patch_size

        # B,C,H,W -> B,H,W,C -> B,H,W,num_classes,patch,patch
        logits = self.proj(x.permute(0, 2, 3, 1).contiguous())
        logits = logits.view(
            batch_size,
            height,
            width,
            self.num_classes,
            patch,
            patch,
        )

        # B,H,W,K,p,p -> B,K,H,p,W,p -> B,K,H*p,W*p
        logits = logits.permute(0, 3, 1, 4, 2, 5).contiguous()
        logits = logits.view(
            batch_size,
            self.num_classes,
            height * patch,
            width * patch,
        )

        if self.output_size is not None and logits.shape[-2:] != self.output_size:
            logits = F.interpolate(
                logits,
                size=self.output_size,
                mode="bilinear",
                align_corners=self.align_corners,
            )
        return logits

