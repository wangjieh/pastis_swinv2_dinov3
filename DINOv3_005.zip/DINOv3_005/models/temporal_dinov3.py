from typing import Tuple

import torch
from mmengine.model import BaseModule
from mmseg.registry import MODELS


@MODELS.register_module()
class TemporalDINOv3ViT(BaseModule):
    """Apply DINOv3 to each temporal frame and fuse features over time.

    Input shape: ``B x T x 3 x H x W``.
    Output: tuple of fused feature maps. With ``out_indices=(23,)`` and
    ViT-L/16 on 64x64 inputs, the output is typically ``(B x 1024 x 4 x 4,)``.

    Args:
        frame_backbone: Config for the single-frame DINOv3 backbone. Usually
            ``dict(type='DINOv3ViT', model_name='dinov3_vitl16', ...)``.
        temporal_fusion: ``'mean'`` or ``'max'``.
    """

    def __init__(self, frame_backbone: dict, temporal_fusion: str = 'mean', init_cfg=None):
        super().__init__(init_cfg=init_cfg)
        if temporal_fusion not in ('mean', 'max'):
            raise ValueError(
                f"Unsupported temporal_fusion={temporal_fusion!r}. "
                "Use 'mean' or 'max'."
            )
        self.frame_backbone = MODELS.build(frame_backbone)
        self.temporal_fusion = temporal_fusion
        self.out_channels = getattr(self.frame_backbone, 'out_channels', None)
        self.num_features = getattr(self.frame_backbone, 'num_features', self.out_channels)

    @property
    def freeze(self) -> bool:
        return bool(getattr(self.frame_backbone, 'freeze', False))

    def unfreeze_backbone(self) -> None:
        """Unfreeze the wrapped DINOv3 frame backbone."""
        if hasattr(self.frame_backbone, 'freeze'):
            self.frame_backbone.freeze = False
        self.frame_backbone.train(True)
        for param in self.frame_backbone.parameters():
            param.requires_grad = True

    def freeze_backbone(self) -> None:
        """Freeze the wrapped DINOv3 frame backbone."""
        if hasattr(self.frame_backbone, 'freeze'):
            self.frame_backbone.freeze = True
        self.frame_backbone.eval()
        for param in self.frame_backbone.parameters():
            param.requires_grad = False

    def _fuse(self, feat: torch.Tensor, batch_size: int, timesteps: int) -> torch.Tensor:
        feat = feat.view(batch_size, timesteps, *feat.shape[1:])
        if self.temporal_fusion == 'mean':
            return feat.mean(dim=1)
        return feat.max(dim=1).values

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, ...]:
        if x.ndim != 5:
            raise ValueError(
                f'TemporalDINOv3ViT expects input shape [B,T,C,H,W], got {tuple(x.shape)}.'
            )
        batch_size, timesteps, channels, height, width = x.shape
        if channels != 3:
            raise ValueError(
                f'TemporalDINOv3ViT expects RGB inputs with 3 channels, got {channels}.'
            )

        x = x.reshape(batch_size * timesteps, channels, height, width)
        frame_outputs = self.frame_backbone(x)
        return tuple(self._fuse(feat, batch_size, timesteps) for feat in frame_outputs)
