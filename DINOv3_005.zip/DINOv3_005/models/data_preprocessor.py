from typing import Mapping, Sequence

import torch
from mmengine.model import BaseDataPreprocessor
from mmseg.registry import MODELS


@MODELS.register_module()
class PastisSegDataPreProcessor(BaseDataPreprocessor):
    """Data preprocessor for temporal PASTIS tensors.

    The custom dataset already performs RGB extraction, scaling, and
    normalization. This preprocessor only moves data to the target device and
    stacks a list of ``[T, C, H, W]`` tensors into ``[B, T, C, H, W]``.
    """

    def forward(self, data: Mapping, training: bool = False) -> Mapping:
        data = self.cast_data(data)
        inputs = data.get('inputs')

        if isinstance(inputs, torch.Tensor):
            # Accept either [B, T, C, H, W] or a single [T, C, H, W] tensor.
            if inputs.ndim == 4:
                inputs = inputs.unsqueeze(0)
            elif inputs.ndim != 5:
                raise ValueError(
                    f'PastisSegDataPreProcessor expects [T,C,H,W] or '
                    f'[B,T,C,H,W], got {tuple(inputs.shape)}.'
                )
        elif isinstance(inputs, Sequence):
            inputs = torch.stack(list(inputs), dim=0)
        else:
            raise TypeError(f'Unsupported inputs type: {type(inputs)}')

        data['inputs'] = inputs.contiguous()
        return data
