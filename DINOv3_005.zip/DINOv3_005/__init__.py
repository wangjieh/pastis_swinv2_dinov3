"""DINOv3 project extensions for MMSegmentation.

This package registers the PASTIS dataset, DINOv3 temporal backbone,
linear-probe decode head, data preprocessor, and training hooks.
"""

from . import datasets, hooks, models  # noqa: F401
