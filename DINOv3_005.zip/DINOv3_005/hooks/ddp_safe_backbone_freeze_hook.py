"""DDP-safe freeze-then-fine-tune schedule for the DINOv3 backbone."""

from __future__ import annotations

from mmengine.hooks import Hook
from mmengine.model import is_model_wrapper
from mmengine.registry import HOOKS


@HOOKS.register_module()
class DDPSafeBackboneFreezeHook(Hook):
    """Keep backbone weights fixed first, then enable full fine-tuning.

    Why this hook exists:
        For multi-GPU DDP runs, the set of trainable parameters should
        not be changed after DDP construction.  Therefore, the 10+40
        configs build the backbone with ``freeze=False`` so that all
        backbone parameters are present when DDP is created.  During
        the first ``unfreeze_epoch`` epochs this hook keeps the
        backbone optimizer-group learning rates at zero.  At the
        transition it restores the backbone LR and clears its AdamW
        state so backbone fine-tuning starts cleanly.

    The first phase still computes backbone gradients.  This costs more
    memory than a permanently frozen backbone, but it is robust for a
    single uninterrupted multi-GPU DDP run.

    Args:
        unfreeze_epoch: Zero-based first epoch of full fine-tuning.
            ``10`` means epochs 0-9 keep backbone weights fixed and
            epochs 10-49 update the complete model.
        backbone_lr_mult: Multiplier relative to the current non-backbone
            learning rate after the transition.
    """

    priority = "VERY_HIGH"

    def __init__(
        self,
        unfreeze_epoch: int = 10,
        backbone_lr_mult: float = 1.0,
    ) -> None:
        self.unfreeze_epoch = int(unfreeze_epoch)
        self.backbone_lr_mult = float(backbone_lr_mult)
        self._cleared_backbone_state = False
        self._logged_frozen = False
        self._logged_unfrozen = False

        if self.unfreeze_epoch < 0:
            raise ValueError("`unfreeze_epoch` must be non-negative.")
        if self.backbone_lr_mult < 0:
            raise ValueError("`backbone_lr_mult` must be non-negative.")

    @staticmethod
    def _unwrap_model(runner):
        return (
            runner.model.module
            if is_model_wrapper(runner.model)
            else runner.model
        )

    def _get_backbone(self, runner):
        model = self._unwrap_model(runner)
        backbone = getattr(model, "backbone", None)
        if backbone is None:
            raise AttributeError("Cannot find `model.backbone`.")
        return backbone

    def _split_optimizer_groups(self, runner):
        backbone = self._get_backbone(runner)
        backbone_param_ids = {id(param) for param in backbone.parameters()}
        optimizer = runner.optim_wrapper.optimizer

        backbone_groups = []
        non_backbone_groups = []
        for group in optimizer.param_groups:
            params = group.get("params", [])
            flags = [id(param) in backbone_param_ids for param in params]
            has_backbone = any(flags)
            has_non_backbone = any(not flag for flag in flags)

            if has_backbone and has_non_backbone:
                raise RuntimeError(
                    "A single optimizer param group mixes backbone and "
                    "non-backbone parameters. Keep the config's "
                    "`paramwise_cfg=dict(custom_keys={'backbone': "
                    "dict(lr_mult=1.0)})` so the DDP-safe schedule can "
                    "control backbone learning rates independently."
                )
            if has_backbone:
                backbone_groups.append(group)
            else:
                non_backbone_groups.append(group)

        if not backbone_groups:
            raise RuntimeError("No backbone optimizer parameter groups found.")
        if not non_backbone_groups:
            raise RuntimeError("No non-backbone optimizer parameter groups found.")

        return backbone, optimizer, backbone_groups, non_backbone_groups

    def _clear_backbone_optimizer_state(self, optimizer, backbone) -> None:
        for param in backbone.parameters():
            optimizer.state.pop(param, None)

    def before_train_epoch(self, runner) -> None:
        backbone = self._get_backbone(runner)
        if runner.epoch < self.unfreeze_epoch:
            # Prevent stochastic training-time behavior in the fixed phase.
            backbone.eval()
            if not self._logged_frozen:
                runner.logger.info(
                    "DDPSafeBackboneFreezeHook: backbone LR is locked to "
                    f"0 for epochs 0-{self.unfreeze_epoch - 1}."
                )
                self._logged_frozen = True
        else:
            backbone.train(True)
            if not self._logged_unfrozen:
                runner.logger.info(
                    "DDPSafeBackboneFreezeHook: enabling full-model "
                    f"fine-tuning from epoch {runner.epoch}."
                )
                self._logged_unfrozen = True

    def before_train_iter(self, runner, batch_idx: int, data_batch=None) -> None:
        (
            backbone,
            optimizer,
            backbone_groups,
            non_backbone_groups,
        ) = self._split_optimizer_groups(runner)

        if runner.epoch < self.unfreeze_epoch:
            for group in backbone_groups:
                group["lr"] = 0.0
            return

        if not self._cleared_backbone_state:
            self._clear_backbone_optimizer_state(optimizer, backbone)
            self._cleared_backbone_state = True

        # Param schedulers update all groups.  Use the current decoder /
        # neck LR as the schedule reference and restore the backbone LR
        # immediately before every optimizer step.
        reference_lr = float(non_backbone_groups[0]["lr"])
        backbone_lr = reference_lr * self.backbone_lr_mult
        for group in backbone_groups:
            group["lr"] = backbone_lr
