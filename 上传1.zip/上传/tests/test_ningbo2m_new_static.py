import ast
import importlib.util
import runpy
import sys
import types
import unittest
from pathlib import Path
from unittest import mock

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
MMSEG = ROOT / 'dinov3_mmseg'
CONFIGS = ROOT / 'configs' / 'Ningbo2m_new'

CONFIG_NAMES = (
    'dinov3_large_upernet_full_50e.py',
    'dinov3_large_upernet_frozen_50e.py',
    'dinov3_large_adapter_upernet_full_50e.py',
    'dinov3_large_adapter_upernet_frozen_50e.py',
    'swin_huge_fpn_upernet_full_50e.py',
    'swin_huge_fpn_upernet_frozen_50e.py',
)


def read(path):
    return path.read_text(encoding='utf-8-sig')


def load_config(name):
    return runpy.run_path(str(CONFIGS / name))


def has_register_decorator(class_node):
    return any(
        isinstance(dec, ast.Call)
        and isinstance(dec.func, ast.Attribute)
        and dec.func.attr == 'register_module'
        for dec in class_node.decorator_list)


def load_new_transforms_module_with_stubs():
    class BaseTransform:
        pass

    class Registry:
        def register_module(self):
            def decorator(cls):
                return cls
            return decorator

    mmcv_module = types.ModuleType('mmcv')
    mmcv_transforms = types.ModuleType('mmcv.transforms')
    mmcv_transforms.BaseTransform = BaseTransform
    mmcv_module.transforms = mmcv_transforms

    mmseg_module = types.ModuleType('mmseg')
    mmseg_registry = types.ModuleType('mmseg.registry')
    mmseg_registry.TRANSFORMS = Registry()
    mmseg_module.registry = mmseg_registry

    module_path = MMSEG / 'datasets' / 'ningbo2m_new_transforms.py'
    spec = importlib.util.spec_from_file_location(
        'ningbo2m_new_test_transforms', module_path)
    module = importlib.util.module_from_spec(spec)
    with mock.patch.dict(sys.modules, {
            'mmcv': mmcv_module,
            'mmcv.transforms': mmcv_transforms,
            'mmseg': mmseg_module,
            'mmseg.registry': mmseg_registry,
    }):
        spec.loader.exec_module(module)
    return module


class FakeRasterioDataset:

    def __init__(self, array):
        self.array = array

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        return False

    def read(self, index=None):
        return self.array


class FakeRasterio:

    def __init__(self, array):
        self.array = array

    def open(self, filename):
        return FakeRasterioDataset(self.array)


class Ningbo2mNewStaticTest(unittest.TestCase):

    def test_dataset_and_transforms_are_registered(self):
        dataset_path = MMSEG / 'datasets' / 'ningbo2m_new_dataset.py'
        transforms_path = MMSEG / 'datasets' / 'ningbo2m_new_transforms.py'
        init_path = MMSEG / 'datasets' / '__init__.py'

        dataset_tree = ast.parse(read(dataset_path))
        transform_tree = ast.parse(read(transforms_path))

        dataset_classes = {
            node.name: node for node in dataset_tree.body
            if isinstance(node, ast.ClassDef)
        }
        transform_classes = {
            node.name: node for node in transform_tree.body
            if isinstance(node, ast.ClassDef)
        }

        self.assertIn('Ningbo2mNewDataset', dataset_classes)
        self.assertTrue(has_register_decorator(dataset_classes['Ningbo2mNewDataset']))
        self.assertIn('LoadNingbo2mNewRasterioImageFromFile', transform_classes)
        self.assertIn('LoadNingbo2mNewRasterioAnnotations', transform_classes)
        self.assertTrue(has_register_decorator(
            transform_classes['LoadNingbo2mNewRasterioImageFromFile']))
        self.assertTrue(has_register_decorator(
            transform_classes['LoadNingbo2mNewRasterioAnnotations']))

        dataset_text = read(dataset_path)
        self.assertIn('背景', dataset_text)
        self.assertIn('住宅区', dataset_text)

        transforms_text = read(transforms_path)
        self.assertIn('import rasterio', transforms_text)
        self.assertIn('dataset.read()', transforms_text)
        self.assertIn('dataset.read(1)', transforms_text)
        self.assertNotIn('reproject(', transforms_text)
        self.assertNotIn('rasterio.warp', transforms_text)
        self.assertNotIn('transform=', transforms_text)
        self.assertIn('white_ignore_value', transforms_text)

        init_text = read(init_path)
        self.assertIn('Ningbo2mNewDataset', init_text)
        self.assertIn('LoadNingbo2mNewRasterioImageFromFile', init_text)
        self.assertIn('LoadNingbo2mNewRasterioAnnotations', init_text)

    def test_all_six_configs_match_new_dataset_requirements(self):
        self.assertEqual(len(tuple(CONFIGS.glob('*.py'))), 6)
        for name in CONFIG_NAMES:
            with self.subTest(config=name):
                path = CONFIGS / name
                text = read(path)
                self.assertTrue(path.is_file())
                self.assertNotIn('\nimport ', text)
                self.assertNotIn('\nfrom ', text)
                self.assertIn('evaluation = dict(tmpdir=', text)
                self.assertIn('find_unused_parameters = True', text)
                self.assertIn('model_wrapper_cfg', text)
                self.assertIn("'dinov3_mmseg.datasets.ningbo2m_new_dataset'", text)
                self.assertIn(
                    "'dinov3_mmseg.datasets.ningbo2m_new_transforms'", text)

                cfg = load_config(name)
                self.assertEqual(cfg['ignore_index'], 255)
                self.assertEqual(cfg['crop_size'], (512, 512))
                self.assertEqual(cfg['num_classes'], 8)
                self.assertEqual(cfg['all_label_ids'], tuple(range(8)))
                self.assertEqual(cfg['train_batch_size'], 8)
                self.assertEqual(cfg['max_epochs'], 50)
                self.assertEqual(cfg['base_learning_rate'], 5e-4)
                self.assertEqual(cfg['weight_decay'], 0.01)
                self.assertEqual(cfg['param_scheduler'][0]['type'], 'LinearLR')
                self.assertEqual(cfg['param_scheduler'][0]['end'], 1500)
                self.assertEqual(cfg['param_scheduler'][0]['start_factor'], 1e-6)
                self.assertEqual(cfg['param_scheduler'][1]['type'], 'PolyLR')
                self.assertEqual(cfg['train_cfg']['type'], 'EpochBasedTrainLoop')
                self.assertEqual(cfg['default_hooks']['checkpoint']['by_epoch'], True)
                self.assertEqual(cfg['default_hooks']['checkpoint']['interval'], 1)
                self.assertEqual(cfg['log_processor']['by_epoch'], True)
                self.assertEqual(
                    cfg['train_dataloader']['dataset']['type'],
                    'Ningbo2mNewDataset')
                self.assertEqual(
                    cfg['train_dataloader']['dataset']['data_prefix']['img_path'],
                    'train/images')
                self.assertEqual(
                    cfg['train_dataloader']['dataset']['data_prefix']
                    ['seg_map_path'],
                    'train/masks')
                self.assertEqual(len(cfg['train_classes']), 8)
                self.assertEqual(cfg['train_classes'][0], '背景')
                self.assertEqual(cfg['train_classes'][7], '住宅区')
                self.assertEqual(
                    cfg['train_pipeline'][0]['type'],
                    'LoadNingbo2mNewRasterioImageFromFile')
                self.assertEqual(
                    cfg['train_pipeline'][1]['type'],
                    'LoadNingbo2mNewRasterioAnnotations')
                self.assertEqual(cfg['train_pipeline'][1]['label_min'], 0)
                self.assertEqual(cfg['train_pipeline'][1]['label_max'], 7)
                self.assertEqual(
                    cfg['model']['decode_head']['num_classes'],
                    cfg['num_classes'])
                self.assertEqual(
                    cfg['model']['decode_head']['loss_decode']['type'],
                    'CrossEntropyLoss')

    def test_model_variants_and_backbone_lr_multiplier(self):
        full_names = (
            'dinov3_large_upernet_full_50e.py',
            'dinov3_large_adapter_upernet_full_50e.py',
            'swin_huge_fpn_upernet_full_50e.py',
        )
        frozen_names = (
            'dinov3_large_upernet_frozen_50e.py',
            'dinov3_large_adapter_upernet_frozen_50e.py',
            'swin_huge_fpn_upernet_frozen_50e.py',
        )
        for name in full_names:
            with self.subTest(config=name):
                cfg = load_config(name)
                self.assertEqual(
                    cfg['optim_wrapper']['paramwise_cfg']['custom_keys']
                    ['backbone']['lr_mult'],
                    0.1)
        for name in frozen_names:
            with self.subTest(config=name):
                cfg = load_config(name)
                self.assertNotIn('paramwise_cfg', cfg['optim_wrapper'])

        direct = load_config('dinov3_large_upernet_full_50e.py')
        direct_frozen = load_config('dinov3_large_upernet_frozen_50e.py')
        adapter = load_config('dinov3_large_adapter_upernet_full_50e.py')
        adapter_frozen = load_config('dinov3_large_adapter_upernet_frozen_50e.py')
        swin = load_config('swin_huge_fpn_upernet_full_50e.py')
        swin_frozen = load_config('swin_huge_fpn_upernet_frozen_50e.py')

        self.assertEqual(direct['model']['backbone']['type'], 'DINOv3ViT')
        self.assertEqual(direct_frozen['model']['backbone']['frozen_stages'], 24)
        self.assertEqual(adapter['model']['backbone']['type'], 'DINOv3ViTAdapter')
        self.assertFalse(adapter['model']['backbone']['frozen_backbone'])
        self.assertTrue(adapter_frozen['model']['backbone']['frozen_backbone'])
        self.assertEqual(swin['model']['backbone']['type'], 'SwinTransformer')
        self.assertEqual(swin['model']['neck']['type'], 'FPN')
        self.assertEqual(swin_frozen['model']['backbone']['frozen_stages'], 4)

    def test_rasterio_annotation_ignores_white_and_validates_new_labels(self):
        transforms_module = load_new_transforms_module_with_stubs()
        mask = np.array([[0, 1, 7, 255]], dtype=np.uint8)
        img = np.zeros((1, 4, 3), dtype=np.uint8)
        img[0, 1] = np.array([255, 255, 255], dtype=np.uint8)

        fake_rasterio = FakeRasterio(mask)
        loader = transforms_module.LoadNingbo2mNewRasterioAnnotations(
            ignore_index=255,
            no_train_labels=[],
            label_map={idx: idx for idx in range(8)},
            label_min=0,
            label_max=7)

        with mock.patch.dict(sys.modules, {'rasterio': fake_rasterio}):
            output = loader.transform({
                'seg_map_path': 'mask.tif',
                'img': img,
            })

        expected = np.array([[0, 255, 7, 255]], dtype=np.int64)
        np.testing.assert_array_equal(output['gt_seg_map'], expected)


if __name__ == '__main__':
    unittest.main()
