"""Ningbo-2m semantic segmentation dataset with 8 land-cover classes."""

from __future__ import annotations

from typing import Optional, Sequence

from mmseg.datasets import BaseSegDataset
from mmseg.registry import DATASETS


Ningbo2mNewClasses = (
    '背景',
    '草地',
    '裸地',
    '道路',
    '林地',
    '河流',
    '耕地',
    '住宅区',
)

Ningbo2mNewPalette = (
    [0, 0, 0],
    [80, 180, 80],
    [180, 150, 110],
    [128, 128, 128],
    [20, 120, 60],
    [40, 120, 220],
    [220, 210, 80],
    [220, 80, 80],
)


@DATASETS.register_module()
class Ningbo2mNewDataset(BaseSegDataset):
    """Ningbo-2m RGB tif segmentation dataset for labels 0-7.

    Expected layout:

    ``data_root/train/images``, ``data_root/train/masks``,
    ``data_root/val/images`` and ``data_root/val/masks``.
    """

    METAINFO = dict(
        classes=Ningbo2mNewClasses,
        palette=Ningbo2mNewPalette,
    )

    def __init__(
        self,
        classes: Optional[Sequence[str]] = None,
        palette: Optional[Sequence[Sequence[int]]] = None,
        img_suffix: str = '.tif',
        seg_map_suffix: str = '.tif',
        reduce_zero_label: bool = False,
        metainfo: Optional[dict] = None,
        **kwargs,
    ) -> None:
        metainfo = dict(metainfo or {})
        if classes is not None:
            metainfo['classes'] = tuple(classes)
        if palette is not None:
            metainfo['palette'] = [list(color) for color in palette]
        super().__init__(
            img_suffix=img_suffix,
            seg_map_suffix=seg_map_suffix,
            reduce_zero_label=reduce_zero_label,
            metainfo=metainfo or None,
            **kwargs)
