import ast
import runpy
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MMROTATE_MODELS = ROOT / 'dinov3_mmrotate' / 'models'
CONFIGS = ROOT / 'configs'

FROZEN_BASE = CONFIGS / 'dior_r_dinov3-vitl16_sat493m_fpn_oriented-rcnn_frozen_50e.py'
FINETUNE_BASE = (
    CONFIGS
    / 'dior_r_dinov3-vitl16_sat493m_fpn_oriented-rcnn_finetune_10frozen_40ft_50e.py'
)
FROZEN_NEW = (
    CONFIGS
    / 'dior_r_dinov3-vitl16_sat493m_multiblock-sfp_oriented-rcnn_frozen_12e.py'
)
FINETUNE_NEW = (
    CONFIGS
    / 'dior_r_dinov3-vitl16_sat493m_multiblock-sfp_oriented-rcnn_finetune_10frozen_2ft_12e.py'
)
FROZEN_ROTATED_FASTER = (
    CONFIGS
    / 'dior_r_dinov3-vitl16_sat493m_multiblock-sfp_rotated-faster-rcnn_frozen_12e.py'
)
FINETUNE_ROTATED_FASTER = (
    CONFIGS
    / 'dior_r_dinov3-vitl16_sat493m_multiblock-sfp_rotated-faster-rcnn_finetune_10frozen_2ft_12e.py'
)


def load_config(path):
    return runpy.run_path(str(path))


class DiorRMultiBlockSFPStaticTest(unittest.TestCase):

    def test_multiblock_neck_is_registered_and_uses_concat_fusion(self):
        source_path = MMROTATE_MODELS / 'simple_feature_pyramid.py'
        tree = ast.parse(source_path.read_text(encoding='utf-8'))
        class_names = {
            node.name for node in tree.body if isinstance(node, ast.ClassDef)
        }
        self.assertIn('DINOv3MultiBlockSimpleFeaturePyramid', class_names)

        cls = next(
            node for node in tree.body
            if isinstance(node, ast.ClassDef)
            and node.name == 'DINOv3MultiBlockSimpleFeaturePyramid')
        self.assertTrue(
            any(
                isinstance(dec, ast.Call)
                and isinstance(dec.func, ast.Attribute)
                and dec.func.attr == 'register_module'
                for dec in cls.decorator_list))

        source = ast.get_source_segment(
            source_path.read_text(encoding='utf-8'), cls)
        self.assertIn('torch.cat', source)
        self.assertIn('self.fusion_conv', source)
        self.assertIn('num_inputs', source)

        init_source = (MMROTATE_MODELS / '__init__.py').read_text(
            encoding='utf-8')
        self.assertIn('DINOv3MultiBlockSimpleFeaturePyramid', init_source)

    def test_new_configs_use_multiblock_backbone_outputs_and_neck(self):
        for config_path in (FROZEN_NEW, FINETUNE_NEW):
            with self.subTest(config=config_path.name):
                cfg = load_config(config_path)
                backbone = cfg['model']['backbone']
                neck = cfg['model']['neck']

                self.assertEqual(backbone['out_indices'], (5, 11, 17, 23))
                self.assertEqual(
                    neck['type'], 'DINOv3MultiBlockSimpleFeaturePyramid')
                self.assertEqual(neck['in_channels'], 1024)
                self.assertEqual(neck['fusion_channels'], 1024)
                self.assertEqual(neck['out_channels'], 256)
                self.assertEqual(neck['num_inputs'], 4)
                self.assertEqual(neck['num_outs'], 5)

    def test_new_configs_train_for_12_epochs(self):
        for config_path in (FROZEN_NEW, FINETUNE_NEW):
            with self.subTest(config=config_path.name):
                cfg = load_config(config_path)
                self.assertEqual(cfg['max_epochs'], 12)
                self.assertEqual(cfg['train_cfg']['max_epochs'], 12)
                self.assertEqual(cfg['param_scheduler'][1]['end'], 12)

    def test_new_configs_keep_original_training_strategy(self):
        comparisons = (
            (FROZEN_BASE, FROZEN_NEW),
            (FINETUNE_BASE, FINETUNE_NEW),
        )
        unchanged_top_level = [
            'angle_version',
            'num_classes',
            'image_size',
            'train_batch_size',
            'val_batch_size',
            'num_workers',
            'train_pipeline',
            'test_pipeline',
            'train_dataloader',
            'val_dataloader',
            'test_dataloader',
            'val_evaluator',
            'test_evaluator',
            'optim_wrapper',
            'custom_hooks',
            'val_cfg',
            'test_cfg',
            'default_hooks',
            'env_cfg',
            'visualizer',
            'log_processor',
            'log_level',
            'load_from',
            'resume',
        ]
        unchanged_model_keys = [
            'type',
            'data_preprocessor',
            'rpn_head',
            'roi_head',
            'train_cfg',
            'test_cfg',
        ]
        unchanged_backbone_keys = [
            'type',
            'arch',
            'img_size',
            'patch_size',
            'in_channels',
            'norm',
            'frozen',
            'frozen_stages',
            'norm_eval',
            'untie_global_and_local_cls_norm',
            'init_cfg',
        ]

        for base_path, new_path in comparisons:
            with self.subTest(config=new_path.name):
                base = load_config(base_path)
                new = load_config(new_path)
                for key in unchanged_top_level:
                    self.assertEqual(new[key], base[key], key)
                expected_scheduler = list(base['param_scheduler'])
                expected_scheduler[1] = dict(expected_scheduler[1])
                expected_scheduler[1]['end'] = 12
                self.assertEqual(new['param_scheduler'], expected_scheduler)
                for key in unchanged_model_keys:
                    self.assertEqual(new['model'][key], base['model'][key], key)
                for key in unchanged_backbone_keys:
                    self.assertEqual(
                        new['model']['backbone'][key],
                        base['model']['backbone'][key],
                        key)

    def test_rotated_faster_configs_replace_oriented_decoder(self):
        for config_path in (FROZEN_ROTATED_FASTER, FINETUNE_ROTATED_FASTER):
            with self.subTest(config=config_path.name):
                cfg = load_config(config_path)
                model = cfg['model']
                rpn_head = model['rpn_head']
                roi_head = model['roi_head']
                roi_extractor = roi_head['bbox_roi_extractor']
                bbox_head = roi_head['bbox_head']

                self.assertEqual(model['type'], 'mmdet.FasterRCNN')
                self.assertEqual(rpn_head['type'], 'mmdet.RPNHead')
                self.assertEqual(
                    rpn_head['bbox_coder']['type'], 'DeltaXYWHHBBoxCoder')
                self.assertEqual(
                    rpn_head['bbox_coder']['target_means'],
                    [0.0, 0.0, 0.0, 0.0])
                self.assertEqual(
                    rpn_head['bbox_coder']['target_stds'],
                    [1.0, 1.0, 1.0, 1.0])
                self.assertTrue(rpn_head['bbox_coder']['use_box_type'])

                self.assertEqual(
                    roi_extractor['type'], 'mmdet.SingleRoIExtractor')
                self.assertEqual(roi_extractor['roi_layer']['type'], 'RoIAlign')
                self.assertEqual(roi_extractor['roi_layer']['output_size'], 7)
                self.assertEqual(roi_extractor['roi_layer']['sampling_ratio'], 0)
                self.assertEqual(
                    bbox_head['bbox_coder']['type'], 'DeltaXYWHTHBBoxCoder')
                self.assertEqual(bbox_head['bbox_coder']['norm_factor'], 2)
                self.assertTrue(bbox_head['bbox_coder']['edge_swap'])

                self.assertEqual(
                    model['train_cfg']['rpn']['assigner']['iou_calculator']
                    ['type'],
                    'RBbox2HBboxOverlaps2D')
                self.assertEqual(
                    model['train_cfg']['rcnn']['assigner']['iou_calculator']
                    ['type'],
                    'RBbox2HBboxOverlaps2D')
                self.assertEqual(
                    model['train_cfg']['rpn_proposal']['nms']['iou_threshold'],
                    0.7)
                self.assertEqual(
                    model['test_cfg']['rpn']['nms']['iou_threshold'], 0.7)

    def test_rotated_faster_configs_keep_multiblock_and_training_settings(self):
        comparisons = (
            (FROZEN_NEW, FROZEN_ROTATED_FASTER),
            (FINETUNE_NEW, FINETUNE_ROTATED_FASTER),
        )
        unchanged_top_level = [
            'angle_version',
            'num_classes',
            'image_size',
            'max_epochs',
            'train_batch_size',
            'val_batch_size',
            'num_workers',
            'train_pipeline',
            'test_pipeline',
            'train_dataloader',
            'val_dataloader',
            'test_dataloader',
            'val_evaluator',
            'test_evaluator',
            'optim_wrapper',
            'param_scheduler',
            'custom_hooks',
            'train_cfg',
            'val_cfg',
            'test_cfg',
            'default_hooks',
            'env_cfg',
            'visualizer',
            'log_processor',
            'log_level',
            'load_from',
            'resume',
        ]
        unchanged_model_keys = [
            'type',
            'data_preprocessor',
            'backbone',
            'neck',
        ]

        for base_path, rotated_path in comparisons:
            with self.subTest(config=rotated_path.name):
                base = load_config(base_path)
                rotated = load_config(rotated_path)
                for key in unchanged_top_level:
                    self.assertEqual(rotated[key], base[key], key)
                for key in unchanged_model_keys:
                    self.assertEqual(
                        rotated['model'][key], base['model'][key], key)


if __name__ == '__main__':
    unittest.main()
