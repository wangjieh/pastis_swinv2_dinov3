"""DINOv3 ViT backbone wrapper for MMRotate.

The original DINOv3 source tree is kept under ``projects/DINOv3``.  This
module only adapts the DINOv3 ViT interface to the OpenMMLab ``MODELS``
registry used by MMRotate.  The backbone returns NCHW feature maps so it can be
plugged into rotated detectors and their necks.
"""

from __future__ import annotations

import sys
import types
import warnings
from pathlib import Path
from typing import Dict, Iterable, Optional, Sequence, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from mmengine.logging import MMLogger
from mmengine.model import BaseModule
from mmengine.runner.checkpoint import CheckpointLoader, load_state_dict
from mmrotate.registry import MODELS


def _ensure_dinov3_on_path() -> None:
    project_root = Path(__file__).resolve().parents[2]
    project_root_str = str(project_root)
    if project_root_str not in sys.path:
        sys.path.insert(0, project_root_str)

    # Some PyTorch builds used with OpenMMLab 2.x do not expose this helper.
    # DINOv3 imports it when defining its optional fp8 linear layer.
    if not hasattr(torch, 'compiler'):
        torch.compiler = types.SimpleNamespace()  # type: ignore[attr-defined]
    if not hasattr(torch.compiler, 'allow_in_graph'):
        torch.compiler.allow_in_graph = lambda obj: obj  # type: ignore[attr-defined]


_ensure_dinov3_on_path()

from dinov3.models.vision_transformer import DinoVisionTransformer  # noqa: E402


def _as_tuple(value: Union[int, Sequence[int]], depth: int) -> Tuple[int, ...]:
    if isinstance(value, int):
        value = (value, )
    indices = []
    for index in value:
        if index < 0:
            index = depth + index
        if index < 0 or index >= depth:
            raise ValueError(
                f'out_indices must be in [0, {depth - 1}], got {index}.')
        indices.append(index)
    return tuple(indices)


def _extract_state_dict(checkpoint: object) -> Dict[str, torch.Tensor]:
    if isinstance(checkpoint, dict):
        for key in ('state_dict', 'model', 'teacher', 'student', 'module'):
            value = checkpoint.get(key)
            if isinstance(value, dict):
                checkpoint = value
                break

    if not isinstance(checkpoint, dict):
        raise TypeError('Checkpoint must be a state_dict or contain one.')

    state_dict = dict(checkpoint)
    prefixes = (
        'teacher.backbone.',
        'student.backbone.',
        'module.',
        'model.',
        'backbone.',
        'teacher.',
        'student.',
    )
    changed = True
    while changed:
        changed = False
        for prefix in prefixes:
            if any(key.startswith(prefix) for key in state_dict):
                state_dict = {
                    key[len(prefix):] if key.startswith(prefix) else key: value
                    for key, value in state_dict.items()
                }
                changed = True
    return state_dict


@MODELS.register_module()
@MODELS.register_module(name='DINOv3VisionTransformer')
class DINOv3ViT(BaseModule):
    """DINOv3 Vision Transformer backbone for MMRotate.

    Args:
        arch: DINOv3 ViT architecture name or a dict overriding architecture
            settings. Supported names are ``vits16``, ``vits16plus``,
            ``vitb16``, ``vitl16``, ``vitl16plus``, ``vith16plus`` and
            ``vit7b16``.
        img_size: Image size used to initialize DINOv3 patch metadata.
        patch_size: Patch size. Official DINOv3 ViT checkpoints use 16.
        in_channels: Number of input channels.
        out_indices: Transformer block indices whose patch tokens are returned.
        norm: Whether to apply DINOv3's final norm to intermediate outputs.
        output_cls_token: Return ``[feature_map, cls_token]`` per level. Most
            detection necks should keep this ``False``.
        out_scales: Optional spatial scale factors applied to the last selected
            feature map. This is useful for FPN-style rotated detectors because
            plain ViT intermediate layers all have the same spatial stride. For
            example, ``out_indices=(-1,)`` and ``out_scales=(4, 2, 1, 0.5)``
            produce feature maps with approximate strides 4, 8, 16 and 32 when
            ``patch_size=16``.
        auto_pad: Pad feature inputs to a multiple of ``patch_size`` before the
            patch embedding. Prefer setting the detector data preprocessor's
            pad divisor to 16 so this is normally a no-op.
        frozen_stages: Freeze patch embedding/tokens when >= 0 and freeze the
            first N transformer blocks when > 0.
        norm_eval: Set normalization layers to eval mode during training.
        init_cfg: OpenMMLab init config. Use
            ``dict(type='Pretrained', checkpoint='path_or_url')`` to load DINOv3
            weights.
    """

    ARCH_SETTINGS = {
        'vits16': dict(
            embed_dim=384,
            depth=12,
            num_heads=6,
            ffn_ratio=4,
            qkv_bias=True,
            ffn_layer='mlp'),
        'vits16plus': dict(
            embed_dim=384,
            depth=12,
            num_heads=6,
            ffn_ratio=6,
            qkv_bias=True,
            ffn_layer='swiglu'),
        'vitb16': dict(
            embed_dim=768,
            depth=12,
            num_heads=12,
            ffn_ratio=4,
            qkv_bias=True,
            ffn_layer='mlp'),
        'vitl16': dict(
            embed_dim=1024,
            depth=24,
            num_heads=16,
            ffn_ratio=4,
            qkv_bias=True,
            ffn_layer='mlp'),
        'vitl16plus': dict(
            embed_dim=1024,
            depth=24,
            num_heads=16,
            ffn_ratio=6.0,
            qkv_bias=True,
            ffn_layer='swiglu'),
        'vith16plus': dict(
            embed_dim=1280,
            depth=32,
            num_heads=20,
            ffn_ratio=6.0,
            qkv_bias=True,
            ffn_layer='swiglu'),
        'vit7b16': dict(
            embed_dim=4096,
            depth=40,
            num_heads=32,
            ffn_ratio=3,
            qkv_bias=False,
            ffn_layer='swiglu64',
            untie_global_and_local_cls_norm=True),
    }

    BASE_KWARGS = dict(
        pos_embed_rope_base=100,
        pos_embed_rope_normalize_coords='separate',
        pos_embed_rope_rescale_coords=2,
        pos_embed_rope_dtype='fp32',
        drop_path_rate=0.0,
        layerscale_init=1.0e-5,
        norm_layer='layernormbf16',
        ffn_bias=True,
        proj_bias=True,
        n_storage_tokens=4,
        mask_k_bias=True,
    )

    def __init__(
        self,
        arch: Union[str, Dict] = 'vitb16',
        img_size: Union[int, Tuple[int, int]] = 224,
        patch_size: int = 16,
        in_channels: int = 3,
        out_indices: Union[int, Sequence[int]] = (2, 5, 8, 11),
        norm: bool = True,
        output_cls_token: bool = False,
        out_scales: Optional[Sequence[float]] = None,
        auto_pad: bool = True,
        frozen: bool = False,
        frozen_stages: int = -1,
        norm_eval: bool = False,
        pretrained: Optional[str] = None,
        init_cfg: Optional[dict] = None,
        **kwargs,
    ) -> None:
        if pretrained is not None:
            warnings.warn(
                '`pretrained` is deprecated. Use '
                '`init_cfg=dict(type="Pretrained", checkpoint=...)` instead.',
                DeprecationWarning)
            if init_cfg is not None:
                raise ValueError('`pretrained` and `init_cfg` cannot both be set.')
            init_cfg = dict(type='Pretrained', checkpoint=pretrained)

        super().__init__(init_cfg=init_cfg)

        arch_kwargs = self._resolve_arch(arch)
        arch_kwargs.update(kwargs)

        self.arch = arch
        self.patch_size = patch_size
        self.out_indices = _as_tuple(out_indices, arch_kwargs['depth'])
        self.norm = norm
        self.output_cls_token = output_cls_token
        self.out_scales = tuple(out_scales) if out_scales is not None else None
        self.auto_pad = auto_pad
        self.frozen = frozen
        self.frozen_stages = frozen_stages
        self.norm_eval = norm_eval
        self.embed_dims = arch_kwargs['embed_dim']
        self.num_layers = arch_kwargs['depth']
        num_outputs = len(self.out_scales or self.out_indices)
        self.out_channels = [self.embed_dims] * num_outputs

        if self.output_cls_token and self.out_scales is not None:
            raise ValueError('out_scales does not support output_cls_token=True.')

        model_kwargs = dict(self.BASE_KWARGS)
        model_kwargs.update(arch_kwargs)
        model_kwargs.update(
            img_size=img_size,
            patch_size=patch_size,
            in_chans=in_channels,
        )
        self.backbone = DinoVisionTransformer(**model_kwargs)
        if self.frozen:
            self._freeze_all()
        self._freeze_stages()

    @classmethod
    def _resolve_arch(cls, arch: Union[str, Dict]) -> Dict:
        if isinstance(arch, str):
            arch_key = arch.lower().replace('-', '').replace('_', '')
            aliases = {
                'small': 'vits16',
                'base': 'vitb16',
                'large': 'vitl16',
                'huge': 'vith16plus',
                '7b': 'vit7b16',
            }
            arch_key = aliases.get(arch_key, arch_key)
            if arch_key not in cls.ARCH_SETTINGS:
                raise KeyError(
                    f'Unsupported DINOv3 arch {arch!r}. Supported: '
                    f'{tuple(cls.ARCH_SETTINGS)}.')
            return dict(cls.ARCH_SETTINGS[arch_key])
        if isinstance(arch, dict):
            if 'embed_dim' not in arch or 'depth' not in arch or 'num_heads' not in arch:
                raise ValueError(
                    'Custom arch dict must contain embed_dim, depth and num_heads.')
            return dict(arch)
        raise TypeError('arch must be a string or a dict.')

    def init_weights(self) -> None:
        if isinstance(self.init_cfg, dict) and self.init_cfg.get('type') == 'Pretrained':
            logger = MMLogger.get_current_instance()
            checkpoint = CheckpointLoader.load_checkpoint(
                self.init_cfg['checkpoint'], logger=logger, map_location='cpu')
            state_dict = _extract_state_dict(checkpoint)
            load_state_dict(
                self.backbone,
                state_dict,
                strict=self.init_cfg.get('strict', False),
                logger=logger)
        elif self.init_cfg is not None:
            super().init_weights()
        else:
            self.backbone.init_weights()

    @staticmethod
    def _set_requires_grad(modules: Iterable[nn.Module], requires_grad: bool) -> None:
        for module in modules:
            module.eval()
            for param in module.parameters():
                param.requires_grad = requires_grad

    def _freeze_stages(self) -> None:
        if self.frozen_stages < 0:
            return
        self._set_requires_grad([self.backbone.patch_embed], False)
        for param in (self.backbone.cls_token, self.backbone.mask_token):
            param.requires_grad = False
        if self.backbone.n_storage_tokens > 0:
            self.backbone.storage_tokens.requires_grad = False
        for block in self.backbone.blocks[:self.frozen_stages]:
            self._set_requires_grad([block], False)

    def _freeze_all(self) -> None:
        self.backbone.eval()
        for param in self.backbone.parameters():
            param.requires_grad = False

    def set_frozen(self, frozen: bool = True) -> None:
        self.frozen = frozen
        for param in self.backbone.parameters():
            param.requires_grad = not frozen
        if frozen:
            self.backbone.eval()
        else:
            self.backbone.train(self.training)
            self._freeze_stages()

    def _maybe_pad(self, x: torch.Tensor) -> torch.Tensor:
        if not self.auto_pad:
            return x
        height, width = x.shape[-2:]
        pad_h = (self.patch_size - height % self.patch_size) % self.patch_size
        pad_w = (self.patch_size - width % self.patch_size) % self.patch_size
        if pad_h == 0 and pad_w == 0:
            return x
        return F.pad(x, (0, pad_w, 0, pad_h))

    def _build_scaled_outputs(self, feat: torch.Tensor) -> Tuple[torch.Tensor, ...]:
        outs = []
        assert self.out_scales is not None
        for scale in self.out_scales:
            if scale == 1 or scale == 1.0:
                outs.append(feat)
            else:
                outs.append(
                    F.interpolate(
                        feat,
                        scale_factor=scale,
                        mode='bilinear',
                        align_corners=False))
        return tuple(outs)

    def forward(self, x: torch.Tensor):
        x = self._maybe_pad(x)
        outs = self.backbone.get_intermediate_layers(
            x,
            n=self.out_indices,
            reshape=True,
            return_class_token=self.output_cls_token,
            norm=self.norm)
        if self.output_cls_token:
            return tuple([feat, cls_token] for feat, cls_token in outs)
        if self.out_scales is not None:
            return self._build_scaled_outputs(outs[-1])
        return outs

    def train(self, mode: bool = True):
        super().train(mode)
        if self.frozen:
            self._freeze_all()
        self._freeze_stages()
        if mode and self.norm_eval:
            for module in self.modules():
                if isinstance(module, (nn.LayerNorm, nn.BatchNorm2d)):
                    module.eval()
        return self
