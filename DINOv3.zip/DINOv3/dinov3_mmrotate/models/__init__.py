"""Model components registered by the DINOv3 MMRotate project."""

from .dinov3_vit import DINOv3ViT

__all__ = ['DINOv3ViT']
