"""Simple feature pyramid neck for DINOv3 ViT features in MMRotate."""

from __future__ import annotations

from typing import Sequence, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from mmengine.model import BaseModule
from mmrotate.registry import MODELS


class LayerNorm2d(nn.Module):
    """LayerNorm over channels for NCHW feature maps."""

    def __init__(self, num_channels: int, eps: float = 1e-6) -> None:
        super().__init__()
        self.norm = nn.LayerNorm(num_channels, eps=eps)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.permute(0, 2, 3, 1)
        x = self.norm(x)
        return x.permute(0, 3, 1, 2).contiguous()


def _build_norm(norm_cfg: dict | None, num_channels: int) -> nn.Module:
    if norm_cfg is None:
        return nn.Identity()

    norm_type = norm_cfg.get('type', 'LN2d')
    if norm_type in ('LN2d', 'LayerNorm2d'):
        return LayerNorm2d(num_channels, eps=norm_cfg.get('eps', 1e-6))
    if norm_type in ('BN', 'BatchNorm2d'):
        return nn.BatchNorm2d(num_channels)
    if norm_type in ('GN', 'GroupNorm'):
        return nn.GroupNorm(norm_cfg.get('num_groups', 32), num_channels)
    raise KeyError(f'Unsupported norm type: {norm_type}')


def _build_act(act_cfg: dict | None) -> nn.Module:
    if act_cfg is None:
        return nn.Identity()

    act_type = act_cfg.get('type', 'GELU')
    if act_type == 'GELU':
        return nn.GELU()
    if act_type == 'ReLU':
        return nn.ReLU(inplace=act_cfg.get('inplace', True))
    raise KeyError(f'Unsupported activation type: {act_type}')


def _conv_block(
    in_channels: int,
    out_channels: int,
    kernel_size: int,
    stride: int,
    padding: int,
    norm_cfg: dict | None,
    act_cfg: dict | None,
    transpose: bool = False,
) -> nn.Sequential:
    conv_cls = nn.ConvTranspose2d if transpose else nn.Conv2d
    conv = conv_cls(
        in_channels,
        out_channels,
        kernel_size=kernel_size,
        stride=stride,
        padding=padding)
    return nn.Sequential(conv, _build_norm(norm_cfg, out_channels),
                         _build_act(act_cfg))


@MODELS.register_module()
class DINOv3SimpleFeaturePyramid(BaseModule):
    """Build an FPN-like pyramid from one stride-16 DINOv3 ViT feature.

    DINOv3 ViT naturally emits one patch feature map. This neck follows the
    ViTDet/SimpleFeaturePyramid style and learns the up/down sampling branches
    instead of bilinearly resizing the backbone output before a normal FPN.

    For a 16x patch backbone and 800x800 input, the default outputs are:
    P2 200x200, P3 100x100, P4 50x50, P5 25x25, and P6 13x13.
    """

    def __init__(
        self,
        in_channels: int = 1024,
        out_channels: int = 256,
        num_outs: int = 5,
        input_index: int = 0,
        norm_cfg: dict | None = dict(type='LN2d', eps=1e-6),
        act_cfg: dict | None = dict(type='GELU'),
        init_cfg: dict | None = dict(
            type='Xavier', layer=['Conv2d', 'ConvTranspose2d'],
            distribution='uniform'),
    ) -> None:
        super().__init__(init_cfg=init_cfg)
        if num_outs < 4:
            raise ValueError('DINOv3SimpleFeaturePyramid requires num_outs >= 4.')

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_outs = num_outs
        self.input_index = input_index

        self.p2_branch = nn.Sequential(
            _conv_block(
                in_channels,
                out_channels,
                kernel_size=2,
                stride=2,
                padding=0,
                norm_cfg=norm_cfg,
                act_cfg=act_cfg,
                transpose=True),
            _conv_block(
                out_channels,
                out_channels,
                kernel_size=2,
                stride=2,
                padding=0,
                norm_cfg=norm_cfg,
                act_cfg=act_cfg,
                transpose=True),
        )
        self.p3_branch = _conv_block(
            in_channels,
            out_channels,
            kernel_size=2,
            stride=2,
            padding=0,
            norm_cfg=norm_cfg,
            act_cfg=act_cfg,
            transpose=True)
        self.p4_branch = _conv_block(
            in_channels,
            out_channels,
            kernel_size=1,
            stride=1,
            padding=0,
            norm_cfg=norm_cfg,
            act_cfg=act_cfg)
        self.p5_branch = _conv_block(
            in_channels,
            out_channels,
            kernel_size=2,
            stride=2,
            padding=0,
            norm_cfg=norm_cfg,
            act_cfg=act_cfg)

        self.output_convs = nn.ModuleList([
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1)
            for _ in range(num_outs)
        ])

    def forward(
        self,
        inputs: Union[torch.Tensor, Sequence[torch.Tensor]],
    ) -> Tuple[torch.Tensor, ...]:
        if isinstance(inputs, torch.Tensor):
            x = inputs
        else:
            if len(inputs) <= self.input_index:
                raise IndexError(
                    f'input_index={self.input_index} but got {len(inputs)} '
                    'input feature maps.')
            x = inputs[self.input_index]

        outs = [
            self.p2_branch(x),
            self.p3_branch(x),
            self.p4_branch(x),
            self.p5_branch(x),
        ]
        while len(outs) < self.num_outs:
            outs.append(F.max_pool2d(outs[-1], kernel_size=1, stride=2))

        outs = [
            output_conv(out)
            for output_conv, out in zip(self.output_convs, outs)
        ]
        return tuple(outs)
