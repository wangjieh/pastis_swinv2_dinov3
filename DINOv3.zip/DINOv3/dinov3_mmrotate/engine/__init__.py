"""Engine components registered by the DINOv3 MMRotate project."""

from .hooks import *  # noqa: F401,F403
