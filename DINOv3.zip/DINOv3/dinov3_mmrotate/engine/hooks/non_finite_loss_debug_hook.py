"""Debug hook for locating non-finite training losses."""

from __future__ import annotations

import math
from typing import Any, Dict, Iterable, List, Optional, Tuple

import torch
from mmengine.hooks import Hook
from mmrotate.registry import HOOKS


@HOOKS.register_module()
class NonFiniteLossDebugHook(Hook):
    """Print batch/model diagnostics when a loss becomes NaN or Inf."""

    priority = 'LOW'

    def __init__(
        self,
        max_samples: int = 4,
        max_boxes: int = 5,
        check_grads: bool = True,
        check_params: bool = True,
        stop_on_nan: bool = False,
    ) -> None:
        self.max_samples = max_samples
        self.max_boxes = max_boxes
        self.check_grads = check_grads
        self.check_params = check_params
        self.stop_on_nan = stop_on_nan
        self._reported_iters = set()

    def after_train_iter(
        self,
        runner,
        batch_idx: int,
        data_batch: Optional[dict] = None,
        outputs: Optional[dict] = None,
    ) -> None:
        non_finite_outputs = self._collect_non_finite(outputs)
        if not non_finite_outputs:
            return

        iter_key = getattr(runner, 'iter', batch_idx)
        if iter_key in self._reported_iters:
            return
        self._reported_iters.add(iter_key)

        model = self._unwrap_model(runner.model)
        lines = [
            '[NonFiniteLossDebugHook] non-finite loss detected',
            f'epoch={getattr(runner, "epoch", None)}, '
            f'iter={getattr(runner, "iter", None)}, batch_idx={batch_idx}',
            f'non_finite_outputs={non_finite_outputs}',
            self._format_outputs(outputs),
            self._format_data_batch(data_batch),
        ]
        if self.check_grads:
            lines.append(self._format_first_non_finite_tensor(model, kind='grad'))
        if self.check_params:
            lines.append(self._format_first_non_finite_tensor(model, kind='param'))

        message = '\n'.join(line for line in lines if line)
        runner.logger.error(message)
        if self.stop_on_nan:
            raise FloatingPointError(message)

    @staticmethod
    def _unwrap_model(model):
        return model.module if hasattr(model, 'module') else model

    def _collect_non_finite(self, value: Any, prefix: str = '') -> List[str]:
        found = []
        if value is None:
            return found
        if isinstance(value, dict):
            for key, item in value.items():
                child_prefix = f'{prefix}.{key}' if prefix else str(key)
                found.extend(self._collect_non_finite(item, child_prefix))
            return found
        if isinstance(value, (list, tuple)):
            for index, item in enumerate(value):
                child_prefix = f'{prefix}[{index}]'
                found.extend(self._collect_non_finite(item, child_prefix))
            return found
        if torch.is_tensor(value):
            if value.numel() > 0 and not torch.isfinite(value.detach()).all():
                found.append(prefix or '<tensor>')
            return found
        if isinstance(value, float) and not math.isfinite(value):
            found.append(prefix or '<float>')
        return found

    def _format_outputs(self, outputs: Optional[dict]) -> str:
        if outputs is None:
            return 'outputs=None'
        flat_items = []
        for name, value in self._iter_flat(outputs):
            flat_items.append(f'{name}={self._format_value(value)}')
        return 'outputs: ' + ', '.join(flat_items)

    def _iter_flat(self, value: Any, prefix: str = '') -> Iterable[Tuple[str, Any]]:
        if isinstance(value, dict):
            for key, item in value.items():
                child_prefix = f'{prefix}.{key}' if prefix else str(key)
                yield from self._iter_flat(item, child_prefix)
            return
        if isinstance(value, (list, tuple)):
            for index, item in enumerate(value):
                child_prefix = f'{prefix}[{index}]'
                yield from self._iter_flat(item, child_prefix)
            return
        yield prefix or '<value>', value

    def _format_value(self, value: Any) -> str:
        if torch.is_tensor(value):
            detached = value.detach()
            if detached.numel() == 1:
                return f'{float(detached.cpu()):.6g}'
            finite = torch.isfinite(detached)
            return (
                f'tensor(shape={tuple(detached.shape)}, '
                f'finite={bool(finite.all().item())})')
        if isinstance(value, float):
            return f'{value:.6g}'
        return repr(value)

    def _format_data_batch(self, data_batch: Optional[dict]) -> str:
        if not isinstance(data_batch, dict):
            return f'data_batch={type(data_batch).__name__}'

        data_samples = data_batch.get('data_samples')
        if data_samples is None:
            return f'data_batch_keys={list(data_batch.keys())}'

        summaries = []
        for index, sample in enumerate(list(data_samples)[:self.max_samples]):
            summaries.append(self._format_data_sample(index, sample))
        return 'data_samples:\n' + '\n'.join(summaries)

    def _format_data_sample(self, index: int, sample: Any) -> str:
        metainfo = getattr(sample, 'metainfo', {})
        img_id = metainfo.get('img_id')
        img_path = metainfo.get('img_path')
        img_shape = metainfo.get('img_shape')

        gt_instances = getattr(sample, 'gt_instances', None)
        if gt_instances is None:
            return (
                f'  sample[{index}]: img_id={img_id!r}, img_path={img_path!r}, '
                f'img_shape={img_shape!r}, gt_instances=None')

        bboxes = getattr(gt_instances, 'bboxes', None)
        labels = getattr(gt_instances, 'labels', None)
        bbox_tensor = self._bbox_to_tensor(bboxes)
        if bbox_tensor is None:
            bbox_summary = f'bboxes={type(bboxes).__name__}'
            preview = []
        else:
            bbox_cpu = bbox_tensor.detach().cpu()
            finite = bool(torch.isfinite(bbox_cpu).all().item()) if bbox_cpu.numel() else True
            bbox_summary = f'bboxes_shape={tuple(bbox_cpu.shape)}, finite={finite}'
            if bbox_cpu.ndim == 2 and bbox_cpu.shape[1] >= 5 and bbox_cpu.numel():
                widths = bbox_cpu[:, 2]
                heights = bbox_cpu[:, 3]
                angles = bbox_cpu[:, 4]
                bbox_summary += (
                    f', w_min={float(widths.min()):.6g}, '
                    f'h_min={float(heights.min()):.6g}, '
                    f'angle_min={float(angles.min()):.6g}, '
                    f'angle_max={float(angles.max()):.6g}')
            preview = bbox_cpu[:self.max_boxes].tolist()

        label_preview = None
        if labels is not None:
            label_preview = labels.detach().cpu()[:self.max_boxes].tolist()

        return (
            f'  sample[{index}]: img_id={img_id!r}, img_path={img_path!r}, '
            f'img_shape={img_shape!r}, {bbox_summary}, '
            f'labels={label_preview}, bbox_preview={preview}')

    @staticmethod
    def _bbox_to_tensor(bboxes: Any) -> Optional[torch.Tensor]:
        if bboxes is None:
            return None
        if hasattr(bboxes, 'tensor'):
            return bboxes.tensor
        if torch.is_tensor(bboxes):
            return bboxes
        return None

    def _format_first_non_finite_tensor(self, model, kind: str) -> str:
        for name, parameter in model.named_parameters():
            tensor = parameter.grad if kind == 'grad' else parameter.data
            if tensor is None:
                continue
            detached = tensor.detach()
            if detached.numel() == 0 or torch.isfinite(detached).all():
                continue
            mask = ~torch.isfinite(detached)
            first_index = mask.nonzero(as_tuple=False)[0].detach().cpu().tolist()
            first_value = detached[tuple(first_index)].detach().cpu().item()
            return (
                f'first_non_finite_{kind}: name={name}, '
                f'shape={tuple(detached.shape)}, index={first_index}, '
                f'value={first_value!r}')
        return f'first_non_finite_{kind}: none_found'
