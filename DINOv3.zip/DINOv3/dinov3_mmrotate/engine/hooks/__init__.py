"""Hook components registered by the DINOv3 MMRotate project."""

from .dinov3_backbone_freeze_hook import DINOv3BackboneFreezeHook
from .non_finite_loss_debug_hook import NonFiniteLossDebugHook

__all__ = ['DINOv3BackboneFreezeHook', 'NonFiniteLossDebugHook']
