"""Hook components registered by the DINOv3 MMRotate project."""

from .dinov3_backbone_freeze_hook import DINOv3BackboneFreezeHook

__all__ = ['DINOv3BackboneFreezeHook']
