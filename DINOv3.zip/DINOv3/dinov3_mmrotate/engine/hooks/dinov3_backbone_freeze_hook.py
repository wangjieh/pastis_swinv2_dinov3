"""Hooks for staged DINOv3 finetuning in MMRotate."""

from __future__ import annotations

from typing import Optional

from mmengine.hooks import Hook
from mmrotate.registry import HOOKS


@HOOKS.register_module()
class DINOv3BackboneFreezeHook(Hook):
    """Freeze a detector backbone, then optionally unfreeze it by epoch.

    This hook is intentionally detector-agnostic. It expects the model to expose
    ``model.backbone`` after unwrapping distributed/data-parallel wrappers.
    """

    priority = 'VERY_HIGH'

    def __init__(self, unfreeze_epoch: Optional[int] = None) -> None:
        self.unfreeze_epoch = unfreeze_epoch
        self._unfrozen = False

    def before_train(self, runner) -> None:
        model = self._unwrap_model(runner.model)
        self._set_backbone_frozen(model, True)
        if self.unfreeze_epoch is None:
            runner.logger.info('DINOv3 backbone is frozen for the whole training.')
        else:
            runner.logger.info(
                f'DINOv3 backbone is frozen until epoch {self.unfreeze_epoch}.')

    def before_train_epoch(self, runner) -> None:
        if self.unfreeze_epoch is None:
            model = self._unwrap_model(runner.model)
            self._set_backbone_frozen(model, True)
            return
        if self.unfreeze_epoch is None or self._unfrozen:
            return
        if runner.epoch < self.unfreeze_epoch:
            model = self._unwrap_model(runner.model)
            self._set_backbone_frozen(model, True)
            return

        model = self._unwrap_model(runner.model)
        self._set_backbone_frozen(model, False)
        runner.logger.info(
            f'Unfroze DINOv3 backbone at epoch {runner.epoch}.')
        self._unfrozen = True

    @staticmethod
    def _unwrap_model(model):
        return model.module if hasattr(model, 'module') else model

    @staticmethod
    def _set_backbone_frozen(model, frozen: bool) -> None:
        if not hasattr(model, 'backbone'):
            raise AttributeError(
                'DINOv3BackboneFreezeHook requires model.backbone.')
        backbone = model.backbone
        if hasattr(backbone, 'set_frozen'):
            backbone.set_frozen(frozen)
            return
        for parameter in backbone.parameters():
            parameter.requires_grad = not frozen
        if frozen:
            backbone.eval()
        else:
            backbone.train(model.training)
