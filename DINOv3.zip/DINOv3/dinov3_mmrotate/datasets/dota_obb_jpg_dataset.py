"""DIOR-R OBB dataset adapter for jpg image folders.

This dataset follows MMRotate 1.x's DOTA-style data-list format, but it lets
DIOR-R projects use folders such as ``trainval/images`` and
``trainval/labelTxt`` with jpg images directly.
"""

from __future__ import annotations

import glob
import os.path as osp
from typing import List, Optional, Sequence, Tuple, Union

import mmcv
from mmengine.dataset import BaseDataset
from mmengine.fileio import get
from mmrotate.registry import DATASETS


@DATASETS.register_module()
class DOTAOBBJPGDataset(BaseDataset):
    """DIOR-R oriented bounding box dataset with configurable image suffix.

    Expected annotation line format:
    ``x1 y1 x2 y2 x3 y3 x4 y4 class_name difficulty``.

    Args:
        img_suffix: Image suffix used to match annotation ids. Defaults to
            ``'.jpg'``. It can be a sequence only when ``ann_file=''``.
        img_shape: Optional fixed image shape in ``(height, width)``. If not
            provided, image shapes are read from image files while building the
            data list.
        diff_thr: Objects with difficulty larger than this threshold are marked
            ignored. Defaults to 100, following MMRotate's DOTA loader.
    """

    METAINFO = {
        'classes':
        ('airplane', 'airport', 'baseball-field', 'basketball-court',
         'bridge', 'chimney', 'dam', 'expressway-service-area',
         'expressway-toll-station', 'golf-field', 'ground-track-field',
         'harbor', 'overpass', 'ship', 'stadium', 'storage-tank',
         'tennis-court', 'train-station', 'vehicle', 'windmill'),
        'palette': [(165, 42, 42), (189, 183, 107), (0, 255, 0), (255, 0, 0),
                    (138, 43, 226), (255, 128, 0), (255, 0, 255),
                    (0, 255, 255), (255, 193, 193), (0, 51, 153),
                    (255, 250, 205), (0, 139, 139), (255, 255, 0),
                    (147, 116, 116), (0, 0, 255), (220, 20, 60),
                    (119, 11, 32), (0, 0, 142), (0, 60, 100),
                    (0, 80, 100)]
    }

    def __init__(
        self,
        img_suffix: Union[str, Sequence[str]] = '.jpg',
        img_shape: Optional[Tuple[int, int]] = None,
        diff_thr: int = 100,
        **kwargs,
    ) -> None:
        self.img_suffix = img_suffix
        self.img_shape = img_shape
        self.diff_thr = diff_thr
        super().__init__(**kwargs)

    def load_data_list(self) -> List[dict]:
        cls_map = {
            cat.lower(): i
            for i, cat in enumerate(self.metainfo['classes'])
        }
        if self.ann_file == '':
            return self._load_images_without_annotations()

        txt_files = sorted(glob.glob(osp.join(self.ann_file, '*.txt')))
        if len(txt_files) == 0:
            raise ValueError(f'There is no txt file in {self.ann_file}')

        data_list = []
        for txt_file in txt_files:
            img_id = osp.splitext(osp.basename(txt_file))[0]
            img_name = img_id + self._single_img_suffix()
            img_path = osp.join(self.data_prefix['img_path'], img_name)
            height, width = self._get_img_shape(img_path)

            instances = []
            with open(txt_file, encoding='utf-8') as file:
                for line in file:
                    instance = self._parse_line(line, cls_map, txt_file)
                    if instance is not None:
                        instances.append(instance)

            data_list.append(
                dict(
                    img_id=img_id,
                    file_name=img_name,
                    img_path=img_path,
                    height=height,
                    width=width,
                    instances=instances))
        return data_list

    def _load_images_without_annotations(self) -> List[dict]:
        img_files = []
        img_suffixes = self.img_suffix
        if isinstance(img_suffixes, str):
            img_suffixes = (img_suffixes, )
        for suffix in img_suffixes:
            img_files.extend(
                glob.glob(osp.join(self.data_prefix['img_path'], f'*{suffix}')))
        img_files = sorted(img_files)

        data_list = []
        for img_path in img_files:
            img_name = osp.basename(img_path)
            img_id = osp.splitext(img_name)[0]
            height, width = self._get_img_shape(img_path)
            data_list.append(
                dict(
                    img_id=img_id,
                    file_name=img_name,
                    img_path=img_path,
                    height=height,
                    width=width,
                    instances=[]))
        return data_list

    def _parse_line(self, line: str, cls_map: dict, txt_file: str) -> Optional[dict]:
        line = line.strip()
        if not line or line.startswith(('imagesource:', 'gsd:')):
            return None

        bbox_info = line.split()
        if len(bbox_info) < 10:
            return None

        cls_name = bbox_info[8].lower()
        if cls_name not in cls_map:
            raise KeyError(
                f'Class {cls_name!r} in {txt_file} is not in dataset metainfo.')

        difficulty = int(float(bbox_info[9]))
        return dict(
            bbox=[float(value) for value in bbox_info[:8]],
            bbox_label=cls_map[cls_name],
            ignore_flag=1 if difficulty > self.diff_thr else 0)

    def _single_img_suffix(self) -> str:
        if not isinstance(self.img_suffix, str):
            raise TypeError(
                'img_suffix must be a string when ann_file is a label folder.')
        return self.img_suffix

    def _get_img_shape(self, img_path: str) -> Tuple[int, int]:
        if self.img_shape is not None:
            return self.img_shape
        img_bytes = get(img_path)
        img = mmcv.imfrombytes(img_bytes, flag='color', backend='cv2')
        height, width = img.shape[:2]
        return height, width

    def filter_data(self) -> List[dict]:
        if self.test_mode:
            return self.data_list

        filter_empty_gt = False
        if self.filter_cfg is not None:
            filter_empty_gt = self.filter_cfg.get('filter_empty_gt', False)

        valid_data_infos = []
        for data_info in self.data_list:
            if filter_empty_gt and len(data_info['instances']) == 0:
                continue
            valid_data_infos.append(data_info)
        return valid_data_infos

    def get_cat_ids(self, idx: int) -> List[int]:
        instances = self.get_data_info(idx)['instances']
        return [instance['bbox_label'] for instance in instances]
