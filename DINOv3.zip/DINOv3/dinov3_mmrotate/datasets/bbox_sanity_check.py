"""Debug transforms for validating bounding boxes in MMRotate pipelines."""

from __future__ import annotations

import logging
import math
from typing import Any, Dict, List, Optional, Sequence

import numpy as np
from mmcv.transforms import BaseTransform
from mmengine.logging import print_log
from mmrotate.registry import TRANSFORMS


@TRANSFORMS.register_module()
class BBoxSanityCheck(BaseTransform):
    """Log abnormal bounding boxes during a data pipeline.

    This transform is intentionally non-mutating. It only reports suspicious
    boxes and returns ``results`` unchanged, so it can be inserted before
    ``PackDetInputs`` while debugging NaN losses.
    """

    _ANGLE_RANGES = {
        'oc': (-math.pi / 2, 0.0),
        'le90': (-math.pi / 2, math.pi / 2),
        'le135': (-math.pi / 4, math.pi * 3 / 4),
    }

    def __init__(
        self,
        bbox_key: str = 'gt_bboxes',
        label_key: str = 'gt_bboxes_labels',
        ignore_key: str = 'gt_ignore_flags',
        stage: str = 'pipeline',
        box_format: str = 'auto',
        min_size: float = 1e-3,
        angle_version: Optional[str] = None,
        angle_eps: float = 1e-4,
        max_report: int = 8,
        raise_on_error: bool = False,
    ) -> None:
        self.bbox_key = bbox_key
        self.label_key = label_key
        self.ignore_key = ignore_key
        self.stage = stage
        self.box_format = box_format
        self.min_size = min_size
        self.angle_version = angle_version
        self.angle_eps = angle_eps
        self.max_report = max_report
        self.raise_on_error = raise_on_error

        if angle_version is not None and angle_version not in self._ANGLE_RANGES:
            raise ValueError(
                f'Unsupported angle_version={angle_version!r}. Expected one of '
                f'{tuple(self._ANGLE_RANGES)}.')

    def transform(self, results: Dict[str, Any]) -> Dict[str, Any]:
        if self.bbox_key not in results:
            return results

        bboxes = results[self.bbox_key]
        bbox_array = self._to_numpy(bboxes)
        problems = self._find_problems(bbox_array)
        if problems:
            message = self._format_message(results, bboxes, bbox_array, problems)
            print_log(message, logger='current', level=logging.WARNING)
            if self.raise_on_error:
                raise ValueError(message)
        return results

    def _to_numpy(self, bboxes: Any) -> np.ndarray:
        if hasattr(bboxes, 'tensor'):
            bboxes = bboxes.tensor
        if hasattr(bboxes, 'detach'):
            bboxes = bboxes.detach()
        if hasattr(bboxes, 'cpu'):
            bboxes = bboxes.cpu()
        if hasattr(bboxes, 'numpy'):
            bboxes = bboxes.numpy()
        return np.asarray(bboxes)

    def _find_problems(self, bboxes: np.ndarray) -> List[Dict[str, Any]]:
        if bboxes.ndim != 2:
            return [dict(index=None, reasons=[f'invalid_ndim={bboxes.ndim}'])]
        if bboxes.size == 0:
            return []

        box_format = self._resolve_box_format(bboxes)
        problems = []
        for index, bbox in enumerate(bboxes):
            reasons = []
            if not np.all(np.isfinite(bbox)):
                reasons.append('nan_or_inf')

            if box_format == 'rbox':
                if bboxes.shape[1] < 5:
                    reasons.append(f'invalid_rbox_dim={bboxes.shape[1]}')
                else:
                    width = bbox[2]
                    height = bbox[3]
                    angle = bbox[4]
                    if width <= self.min_size or height <= self.min_size:
                        reasons.append(f'non_positive_or_tiny_wh=({width:.6g}, {height:.6g})')
                    if self.angle_version is not None and np.isfinite(angle):
                        min_angle, max_angle = self._ANGLE_RANGES[self.angle_version]
                        if angle < min_angle - self.angle_eps or angle >= max_angle + self.angle_eps:
                            reasons.append(
                                f'angle_out_of_{self.angle_version}_range={angle:.6g}')
            elif box_format == 'hbox':
                if bboxes.shape[1] < 4:
                    reasons.append(f'invalid_hbox_dim={bboxes.shape[1]}')
                else:
                    width = bbox[2] - bbox[0]
                    height = bbox[3] - bbox[1]
                    if width <= self.min_size or height <= self.min_size:
                        reasons.append(f'non_positive_or_tiny_wh=({width:.6g}, {height:.6g})')
            elif box_format == 'qbox':
                if bboxes.shape[1] < 8:
                    reasons.append(f'invalid_qbox_dim={bboxes.shape[1]}')
                else:
                    area = self._quad_area(bbox[:8])
                    if area <= self.min_size * self.min_size:
                        reasons.append(f'non_positive_or_tiny_quad_area={area:.6g}')

            if reasons:
                problems.append(dict(index=index, reasons=reasons))
        return problems

    def _resolve_box_format(self, bboxes: np.ndarray) -> str:
        if self.box_format != 'auto':
            return self.box_format
        if bboxes.shape[1] == 4:
            return 'hbox'
        if bboxes.shape[1] >= 8:
            return 'qbox'
        return 'rbox'

    def _quad_area(self, flat_quad: Sequence[float]) -> float:
        quad = np.asarray(flat_quad, dtype=np.float64).reshape(4, 2)
        x = quad[:, 0]
        y = quad[:, 1]
        return float(0.5 * abs(np.dot(x, np.roll(y, -1)) -
                               np.dot(y, np.roll(x, -1))))

    def _format_message(
        self,
        results: Dict[str, Any],
        bboxes: Any,
        bbox_array: np.ndarray,
        problems: List[Dict[str, Any]],
    ) -> str:
        labels = self._to_optional_numpy(results.get(self.label_key))
        ignore_flags = self._to_optional_numpy(results.get(self.ignore_key))
        reported = []
        for problem in problems[:self.max_report]:
            index = problem['index']
            item = dict(index=index, reasons=problem['reasons'])
            if index is not None and bbox_array.ndim == 2 and index < len(bbox_array):
                item['bbox'] = bbox_array[index].tolist()
            if labels is not None and index is not None and index < len(labels):
                item['label'] = int(labels[index])
            if ignore_flags is not None and index is not None and index < len(ignore_flags):
                item['ignore_flag'] = int(ignore_flags[index])
            reported.append(item)

        img_path = results.get('img_path') or results.get('file_name')
        img_id = results.get('img_id')
        bbox_type = type(bboxes).__name__
        return (
            f'[BBoxSanityCheck:{self.stage}] abnormal {self.bbox_key}: '
            f'img_id={img_id!r}, img_path={img_path!r}, '
            f'img_shape={results.get("img_shape")!r}, '
            f'ori_shape={results.get("ori_shape")!r}, '
            f'bbox_type={bbox_type}, tensor_shape={tuple(bbox_array.shape)}, '
            f'num_bad={len(problems)}, reported={reported}')

    def _to_optional_numpy(self, value: Any) -> Optional[np.ndarray]:
        if value is None:
            return None
        return self._to_numpy(value)
