"""Dataset components registered by the DINOv3 MMRotate project."""

from .bbox_sanity_check import BBoxSanityCheck
from .dota_obb_jpg_dataset import DOTAOBBJPGDataset

__all__ = ['DOTAOBBJPGDataset', 'BBoxSanityCheck']
