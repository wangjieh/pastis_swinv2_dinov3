"""Dataset components registered by the DINOv3 MMRotate project."""

from .dota_obb_jpg_dataset import DOTAOBBJPGDataset

__all__ = ['DOTAOBBJPGDataset']
