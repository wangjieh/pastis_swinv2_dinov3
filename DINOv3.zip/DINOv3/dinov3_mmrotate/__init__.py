"""DINOv3 components for MMRotate projects."""

from mmdet.utils import register_all_modules as register_mmdet_modules
from mmrotate.utils import register_all_modules as register_mmrotate_modules

register_mmdet_modules(init_default_scope=False)
register_mmrotate_modules(init_default_scope=False)

from .datasets import *  # noqa: F401,F403,E402
from .engine import *  # noqa: F401,F403,E402
from .models import *  # noqa: F401,F403,E402
