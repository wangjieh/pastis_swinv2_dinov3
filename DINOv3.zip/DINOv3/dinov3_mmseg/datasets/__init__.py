"""Dataset components registered by the DINOv3 MMSeg project."""

from .generic_seg_dataset import DINOv3SegDataset
from .pastis_pt_dataset import PASTISPtDataset

__all__ = ['DINOv3SegDataset', 'PASTISPtDataset']
