"""Generic semantic segmentation dataset for DINOv3 MMSeg configs."""

from __future__ import annotations

from typing import Optional, Sequence

from mmseg.datasets import BaseSegDataset
from mmseg.registry import DATASETS


@DATASETS.register_module()
class DINOv3SegDataset(BaseSegDataset):
    """A configurable segmentation dataset registered for this project.

    It follows the standard MMSeg directory convention and lets configs provide
    dataset classes, palette, image suffix and mask suffix without editing the
    core MMSeg package.
    """

    METAINFO = dict(
        classes=('background', 'foreground'),
        palette=[[0, 0, 0], [255, 255, 255]],
    )

    def __init__(
        self,
        classes: Optional[Sequence[str]] = None,
        palette: Optional[Sequence[Sequence[int]]] = None,
        img_suffix: str = '.jpg',
        seg_map_suffix: str = '.png',
        reduce_zero_label: bool = False,
        metainfo: Optional[dict] = None,
        **kwargs,
    ) -> None:
        metainfo = dict(metainfo or {})
        if classes is not None:
            metainfo['classes'] = tuple(classes)
        if palette is not None:
            metainfo['palette'] = [list(color) for color in palette]
        super().__init__(
            img_suffix=img_suffix,
            seg_map_suffix=seg_map_suffix,
            reduce_zero_label=reduce_zero_label,
            metainfo=metainfo or None,
            **kwargs)

