"""Hooks registered by the DINOv3 MMSeg project."""

from .pastis_unfreeze_hook import PASTISBackboneUnfreezeHook

__all__ = ['PASTISBackboneUnfreezeHook']
