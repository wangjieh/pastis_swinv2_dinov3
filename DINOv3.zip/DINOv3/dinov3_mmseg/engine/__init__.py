"""Engine extensions for DINOv3 MMSeg projects."""

from .hooks import *  # noqa: F401,F403
