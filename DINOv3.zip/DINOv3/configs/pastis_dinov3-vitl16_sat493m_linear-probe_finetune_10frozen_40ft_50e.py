import sys
import os
from pathlib import Path

project_root = Path(__file__).resolve().parents[2]
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

custom_imports = dict(imports=['dinov3_mmseg'], allow_failed_imports=False)

default_scope = 'mmseg'

data_root = os.getenv('PASTIS_DATA_ROOT', '')
dinov3_pretrained = os.getenv('DINOV3_PRETRAINED', '')
work_dir = './work_dirs/pastis_dinov3-vitl16_sat493m_linear-probe_finetune_10frozen_40ft_50e'

num_classes = 19
ignore_index = -1
image_size = 256
max_epochs = 50
train_batch_size = 1
val_batch_size = 1
num_workers = 2
backbone_frame_batch_size = 2

dataset_cfg = dict(
    type='PASTISPtDataset',
    data_root=data_root,
    image_size=image_size,
    rgb_indices=(3, 2, 1),
    ignore_index=ignore_index)

model = dict(
    type='PASTISDINOv3Segmentor',
    data_preprocessor=dict(type='PASTISDataPreProcessor'),
    ignore_index=ignore_index,
    frozen_backbone=False,
    backbone_frame_batch_size=backbone_frame_batch_size,
    backbone=dict(
        type='DINOv3ViT',
        arch='vitl16',
        img_size=image_size,
        patch_size=16,
        in_channels=3,
        out_indices=(23, ),
        norm=True,
        frozen_stages=-1,
        norm_eval=False,
        untie_global_and_local_cls_norm=True,
        init_cfg=dict(
            type='Pretrained',
            checkpoint=dinov3_pretrained,
            strict=True) if dinov3_pretrained else None),
    decode_head=dict(
        type='PASTISLinearProbeHead',
        in_channels=1024,
        num_classes=num_classes,
        patch_size=16))

train_dataloader = dict(
    batch_size=train_batch_size,
    num_workers=num_workers,
    persistent_workers=num_workers > 0,
    collate_fn=dict(type='pseudo_collate'),
    sampler=dict(type='DefaultSampler', shuffle=True),
    dataset=dict(**dataset_cfg, split='train'))

val_dataloader = dict(
    batch_size=val_batch_size,
    num_workers=num_workers,
    persistent_workers=num_workers > 0,
    collate_fn=dict(type='pseudo_collate'),
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(**dataset_cfg, split='valid'))

test_dataloader = dict(
    batch_size=val_batch_size,
    num_workers=num_workers,
    persistent_workers=num_workers > 0,
    collate_fn=dict(type='pseudo_collate'),
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(**dataset_cfg, split='test'))

val_evaluator = dict(type='IoUMetric', iou_metrics=['mIoU'], ignore_index=ignore_index)
test_evaluator = val_evaluator

optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(type='AdamW', lr=1e-4, weight_decay=0.01),
    clip_grad=dict(max_norm=1.0, norm_type=2),
    paramwise_cfg=dict(
        custom_keys={
            'cls_token': dict(decay_mult=0.0),
            'storage_tokens': dict(decay_mult=0.0),
            'mask_token': dict(decay_mult=0.0),
            'rope_embed': dict(decay_mult=0.0),
            'norm': dict(decay_mult=0.0),
            'bias': dict(decay_mult=0.0),
        }))

param_scheduler = [
    dict(
        type='ReduceOnPlateauLR',
        monitor='mIoU',
        rule='greater',
        factor=0.2,
        patience=2,
        cooldown=10,
        min_value=0.0,
        by_epoch=True)
]

custom_hooks = [
    dict(type='PASTISBackboneUnfreezeHook', unfreeze_epoch=10, lr_mult=0.1)
]

train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=max_epochs, val_interval=1)
val_cfg = dict(type='ValLoop')
test_cfg = dict(type='TestLoop')

default_hooks = dict(
    timer=dict(type='IterTimerHook'),
    logger=dict(type='LoggerHook', interval=50, log_metric_by_epoch=True),
    param_scheduler=dict(type='ParamSchedulerHook'),
    checkpoint=dict(
        type='CheckpointHook',
        by_epoch=True,
        interval=1,
        save_best='mIoU',
        rule='greater',
        max_keep_ckpts=3),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    visualization=dict(type='SegVisualizationHook'))

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method='spawn', opencv_num_threads=0),
    dist_cfg=dict(backend='nccl'))

vis_backends = [dict(type='LocalVisBackend')]
visualizer = dict(type='SegLocalVisualizer', vis_backends=vis_backends, name='visualizer')
log_processor = dict(by_epoch=True)
log_level = 'INFO'
load_from = None
resume = False
